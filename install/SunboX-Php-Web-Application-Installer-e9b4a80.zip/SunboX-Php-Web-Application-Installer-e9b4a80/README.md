Php Web Application Installer
===

My first try to build a universal web application installer.

I will try to build it as generic and simple as possible.
So it will hopefully fit every ones needs.

For testing purpose and as inspiration i will take the SilverStripe CMS install script.
If you think i missed something or do it wrong send me a message!


License
---

See [license](master/license) file.
