<?php

class CreateAdminAccount implements IWebApplicationInstaller_Script
{
    /**
     * @see IWebApplicationInstaller_Script::run()
     */
    public function run()
    {
        return true; // no error
    }

    /**
     * @see IWebApplicationInstaller_Script::getErrorMsg()
     */
    public function getErrorMsg()
    {
        //TODO Auto generated method stub
    }
}

?>