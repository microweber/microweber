/* Microweber database backup exported on: Friday 26th of April 2013 02:27:45 PM */ 
/* MW_TABLE_PREFIX: default_content */ 


DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */cart; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `is_active` char(1) DEFAULT 'y',
  `rel_id` int(11) DEFAULT NULL,
  `rel` varchar(350) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `price` float DEFAULT NULL,
  `currency` varchar(33) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `other_info` text,
  `order_completed` char(1) DEFAULT 'n',
  `order_id` varchar(255) DEFAULT NULL,
  `skip_promo_code` char(1) DEFAULT 'n',
  `created_by` int(11) DEFAULT NULL,
  `custom_fields_data` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(333)),
  KEY `rel_id` (`rel_id`),
  KEY `session_id` (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */cart_orders; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */cart_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `promo_code` text,
  `amount` float DEFAULT NULL,
  `transaction_id` text,
  `shipping_service` text,
  `shipping` float DEFAULT NULL,
  `currency` varchar(33) DEFAULT NULL,
  `currency_code` varchar(33) DEFAULT NULL,
  `first_name` text,
  `last_name` text,
  `email` text,
  `city` text,
  `state` text,
  `zip` text,
  `address` text,
  `address2` text,
  `phone` text,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `order_completed` char(1) DEFAULT 'n',
  `is_paid` char(1) DEFAULT 'n',
  `url` text,
  `user_ip` varchar(255) DEFAULT NULL,
  `items_count` int(11) DEFAULT NULL,
  `payment_gw` text,
  `payment_verify_token` text,
  `payment_amount` float DEFAULT NULL,
  `payment_currency` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `payment_email` text,
  `payment_receiver_email` text,
  `payment_name` text,
  `payment_country` text,
  `payment_address` text,
  `payment_city` text,
  `payment_state` text,
  `payment_zip` text,
  `payer_id` text,
  `payer_status` text,
  `payment_type` text,
  `order_status` varchar(255) DEFAULT 'pending',
  `payment_shipping` float DEFAULT NULL,
  `is_active` char(1) DEFAULT 'y',
  `rel_id` int(11) DEFAULT NULL,
  `rel` varchar(350) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `other_info` text,
  `order_id` varchar(255) DEFAULT NULL,
  `skip_promo_code` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(333)),
  KEY `rel_id` (`rel_id`),
  KEY `session_id` (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */cart_shipping; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */cart_shipping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `is_active` char(1) DEFAULT 'y',
  `shiping_cost` float DEFAULT NULL,
  `shiping_cost_max` float DEFAULT NULL,
  `shiping_cost_above` float DEFAULT NULL,
  `shiping_country` text,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */categories; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `data_type` text,
  `title` longtext,
  `parent_id` int(11) DEFAULT NULL,
  `description` text,
  `content` text,
  `content_type` text,
  `rel` text,
  `rel_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `is_deleted` char(1) DEFAULT 'n',
  `users_can_create_subcategories` char(1) DEFAULT 'n',
  `users_can_create_content` char(1) DEFAULT 'n',
  `users_can_create_content_allowed_usergroups` text,
  `categories_content_type` text,
  `categories_silo_keywords` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("1","","","","","category","online shop","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("2","","","","","category","admin","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("3","","","","","category","other","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("4","","","","","category","media","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("5","","","","","category","navigation","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("6","","","","","category","content","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("7","","","","","category","forms","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("8","","","","","category","recommended","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("9","","","","","category","social networks","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("10","","","","","category","help","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("11","","","","","category","advanced","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("12","","","","","category","menus","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("13","","","","","category","users","0","","","","modules","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("14","","","","","category","portfolio","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("15","","","","","category","online shop","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("16","","","","","category","gallery","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("17","","","","","category","recommended","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("18","","","","","category","blog","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("19","","","","","category","custom","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("20","","","","","category","recomended","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("21","","","","","category","table","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("22","","","","","category","tabs","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("23","","","","","category","simple","0","","","","elements","","999","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("24","2013-04-24 15:48:49","2013-04-24 15:48:49","1","1","category","Blog","0","","","","content","4","","n","n","n","","",""); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */categories_items; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */categories_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `rel` text,
  `rel_id` int(11) DEFAULT NULL,
  `content_type` text,
  `data_type` text,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("1","0","modules","1","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("2","0","modules","2","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("3","2","modules","3","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("4","0","modules","4","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("5","0","modules","5","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("6","3","modules","6","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("7","0","modules","7","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("8","0","modules","8","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("9","0","modules","9","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("10","6","modules","10","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("11","6","modules","11","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("12","3","modules","13","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("13","6","modules","13","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("14","0","modules","14","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("15","4","modules","15","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("16","3","modules","16","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("17","0","modules","17","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("18","3","modules","18","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("19","0","modules","19","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("20","6","modules","20","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("21","5","modules","21","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("22","0","modules","22","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("23","4","modules","23","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("24","6","modules","23","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("25","4","modules","24","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("26","6","modules","25","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("27","6","modules","26","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("28","2","modules","27","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("29","1","modules","28","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("30","1","modules","29","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("31","1","modules","30","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("32","1","modules","31","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("33","1","modules","32","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("34","1","modules","33","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("35","1","modules","34","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("36","1","modules","35","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("37","6","modules","37","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("38","8","modules","37","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("39","6","modules","38","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("40","8","modules","38","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("41","0","modules","40","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("42","13","modules","41","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("43","13","modules","42","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("44","4","modules","43","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("45","0","elements","1","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("46","0","elements","1","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("47","0","elements","1","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("48","0","elements","1","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("49","16","elements","2","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("50","15","elements","2","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("51","14","elements","2","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("52","16","elements","3","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("53","15","elements","3","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("54","17","elements","3","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("55","0","elements","4","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("56","0","elements","4","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("57","19","elements","5","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("58","18","elements","5","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("59","19","elements","6","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("60","18","elements","6","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("61","19","elements","7","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("62","19","elements","8","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("63","15","elements","9","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("64","14","elements","9","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("65","0","elements","10","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("66","0","elements","11","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("67","22","elements","12","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("68","17","elements","13","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("69","23","elements","14","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("70","17","elements","14","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("71","23","elements","15","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("72","17","elements","15","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("73","23","elements","16","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("74","17","elements","16","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("75","15","elements","17","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("76","17","elements","18","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("77","14","elements","18","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("78","16","elements","18","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("79","15","elements","18","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("80","17","elements","19","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("81","14","elements","20","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("82","14","elements","21","","category_item"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("83","14","elements","22","","category_item"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */comments; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel` text,
  `rel_id` text,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `comment_name` text,
  `comment_body` text,
  `comment_email` text,
  `comment_website` text,
  `is_moderated` char(1) DEFAULT 'n',
  `from_url` text,
  `comment_subject` text,
  `is_new` char(1) DEFAULT 'y',
  `for_newsletter` char(1) DEFAULT 'n',
  `session_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */content; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `expires_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `content_type` text,
  `url` longtext,
  `content_filename` text,
  `title` longtext,
  `parent` int(11) DEFAULT NULL,
  `description` text,
  `content_meta_title` text,
  `content_meta_keywords` text,
  `position` int(11) DEFAULT '1',
  `content` text,
  `is_active` char(1) DEFAULT 'y',
  `is_home` char(1) DEFAULT 'n',
  `is_pinged` char(1) DEFAULT 'n',
  `is_shop` char(1) DEFAULT 'n',
  `is_deleted` char(1) DEFAULT 'n',
  `draft_of` int(11) DEFAULT NULL,
  `require_login` char(1) DEFAULT 'n',
  `subtype` text,
  `subtype_value` text,
  `original_link` text,
  `layout_file` text,
  `layout_name` text,
  `layout_style` text,
  `active_site_template` text,
  `session_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`(255)),
  KEY `title` (`title`(255))
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("1","2013-04-24 15:43:24","2013-04-24 15:43:24","","1","1","page","home","","Home","0","","","","1","","y","y","n","n","n","","n","static","","","","","","default","u6gh90c5m6inugedrn20asaeg5"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("2","2013-04-24 15:43:50","2013-04-24 15:43:50","","1","1","page","shop","","Shop","0","","","","1","","y","n","n","y","n","","n","dynamic","","","layouts\\shop.php","","","default","u6gh90c5m6inugedrn20asaeg5"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("3","2013-04-24 15:43:58","2013-04-24 15:43:58","","1","1","post","my-product","","My product","2","","","","2","","y","n","n","n","y","","n","product","","","","","","","u6gh90c5m6inugedrn20asaeg5"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("4","2013-04-24 15:48:49","2013-04-24 15:48:48","","1","1","page","blog","","Blog","0","","","","3","","y","n","n","n","n","","n","dynamic","","","layouts\\blog.php","","","default","u6gh90c5m6inugedrn20asaeg5"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("5","2013-04-26 11:48:51","2013-04-24 16:00:29","","1","1","post","ready-for-a-travel","","Ready for a travel","4","","","","4","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module class=&quot; module module-pictures &quot; data-mw-title=&quot;Picture Gallery&quot; id=&quot;module-pictures-1742833173&quot; data-type=&quot;pictures&quot; data-template=&quot;slider&quot; data-content-id=&quot;0&quot; contenteditable=&quot;false&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;br&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;&lt;/div&gt;&lt;/div&gt;\n			","y","n","n","n","n","","n","post","","","","","","","767mavjv4rcccqfibt4ofmbsg5"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("6","2013-04-26 14:23:41","2013-04-26 14:23:41","","1","1","post","product-name","","Product Name","2","","","","5","\n          &lt;div class=&quot;row&quot;&gt;\n            &lt;div class=&quot;span5&quot;&gt;\n              &lt;module class=&quot; module module-pictures &quot; data-mw-title=&quot;Picture Gallery&quot; data-content-id=&quot;0&quot; template=&quot;product_gallery&quot; id=&quot;test1&quot; data-type=&quot;pictures&quot; contenteditable=&quot;false&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n            &lt;div class=&quot;span4 product-description&quot;&gt;\n              &lt;p class=&quot;p0 element&quot;&gt;This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp;amp; &lt;strong style=&quot;font-weight: 600&quot;&gt;Make Web&lt;/strong&gt;.&lt;/p&gt;\n            &lt;/div&gt;\n            &lt;p class=&quot;element&quot;&gt; &lt;/p&gt;\n            &lt;module class=&quot; module module-shop-cart-add &quot; id=&quot;module-shop-cart-add--1139965054&quot; data-mw-title=&quot;Add to cart&quot; data-content-id=&quot;0&quot; data-type=&quot;shop/cart_add&quot; contenteditable=&quot;false&quot;&gt;&lt;/module&gt;&lt;p class=&quot;element&quot;&gt; &lt;/p&gt;\n            &lt;p class=&quot;element&quot;&gt; &lt;/p&gt;\n          &lt;/div&gt;\n        ","y","n","n","n","y","","n","product","","","","","","","767mavjv4rcccqfibt4ofmbsg5"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("7","2013-04-26 14:26:05","2013-04-26 14:24:41","","1","1","post","fff","","fff","2","","","","6","\n          &lt;div class=&quot;row&quot;&gt;\n            &lt;div class=&quot;span5&quot;&gt;\n              &lt;module class=&quot; module module-pictures &quot; data-mw-title=&quot;Picture Gallery&quot; data-content-id=&quot;7&quot; template=&quot;product_gallery&quot; id=&quot;test1&quot; data-type=&quot;pictures&quot; contenteditable=&quot;false&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n            &lt;div class=&quot;span4 product-description&quot;&gt;\n              &lt;p class=&quot;p0 element&quot;&gt;This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp;amp; &lt;strong style=&quot;font-weight: 600&quot;&gt;Make Web&lt;/strong&gt;.&lt;/p&gt;\n              &lt;module class=&quot; module module-shop-cart-add &quot; id=&quot;module-shop-cart-add-fff1241020966&quot; data-mw-title=&quot;Add to cart&quot; data-content-id=&quot;7&quot; data-type=&quot;shop/cart_add&quot; contenteditable=&quot;false&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n            &lt;p class=&quot;element&quot;&gt; &lt;/p&gt;\n            \n            &lt;p class=&quot;element&quot;&gt; &lt;/p&gt;\n            &lt;p class=&quot;element&quot;&gt; &lt;/p&gt;\n          &lt;/div&gt;\n        ","y","n","n","n","n","","n","product","","","","","","","767mavjv4rcccqfibt4ofmbsg5"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */content_fields; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */content_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `rel` text,
  `rel_id` text,
  `field` longtext,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(255)),
  KEY `field` (`field`(55))
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */content_fields_drafts; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */content_fields_drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `rel` text,
  `rel_id` text,
  `field` longtext,
  `value` text,
  `session_id` varchar(50) DEFAULT NULL,
  `is_temp` char(1) DEFAULT 'y',
  `url` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(255)),
  KEY `field` (`field`(55))
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("1","2013-04-26 11:50:24","2013-04-26 11:50:24","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module class=&quot;module module module-pictures&quot; data-mw-title=&quot;Picture Gallery&quot; data-content-id=&quot;0&quot; data-template=&quot;slider&quot; data-type=&quot;pictures&quot; id=&quot;module-pictures-1742833173&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("2","2013-04-26 11:50:30","2013-04-26 11:50:30","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module class=&quot;module module module-pictures&quot; data-mw-title=&quot;Picture Gallery&quot; id=&quot;module-pictures-1742833173&quot; data-type=&quot;pictures&quot; data-template=&quot;slider&quot; data-content-id=&quot;0&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("3","2013-04-26 11:50:33","2013-04-26 11:50:33","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module class=&quot;module module module-pictures&quot; data-mw-title=&quot;Picture Gallery&quot; data-content-id=&quot;0&quot; data-template=&quot;slider&quot; data-type=&quot;pictures&quot; id=&quot;module-pictures-1742833173&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("4","2013-04-26 11:50:42","2013-04-26 11:50:42","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module style=&quot;padding-bottom: 130px;&quot; class=&quot;module module module-pictures&quot; data-mw-title=&quot;Picture Gallery&quot; id=&quot;module-pictures-1742833173&quot; data-type=&quot;pictures&quot; data-template=&quot;slider&quot; data-content-id=&quot;0&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("5","2013-04-26 12:03:23","2013-04-26 12:03:23","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module style=&quot;padding-bottom: 130px;&quot; class=&quot;module module-pictures&quot; data-mw-title=&quot;Picture Gallery&quot; id=&quot;module-pictures-1742833173&quot; data-type=&quot;pictures&quot; data-template=&quot;slider&quot; data-content-id=&quot;0&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div id=&quot;row_1366977788606&quot; class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("6","2013-04-26 12:14:18","2013-04-26 12:14:18","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module style=&quot;padding-bottom: 130px;&quot; class=&quot; module module-pictures &quot; data-mw-title=&quot;Picture Gallery&quot; id=&quot;module-pictures-1742833173&quot; data-type=&quot;pictures&quot; data-template=&quot;slider&quot; data-content-id=&quot;0&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div id=&quot;row_1366978429649&quot; class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("7","2013-04-26 12:14:21","2013-04-26 12:14:21","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module style=&quot;padding-bottom: 130px;&quot; class=&quot; module module-pictures &quot; data-mw-title=&quot;Picture Gallery&quot; id=&quot;module-pictures-1742833173&quot; data-type=&quot;pictures&quot; data-template=&quot;slider&quot; data-content-id=&quot;0&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div id=&quot;row_1366978429649&quot; class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;f&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("8","2013-04-26 12:14:39","2013-04-26 12:14:39","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module class=&quot; module module-pictures &quot; data-mw-title=&quot;Picture Gallery&quot; style=&quot;padding-bottom: 130px;&quot; id=&quot;module-pictures-1742833173&quot; data-type=&quot;pictures&quot; data-template=&quot;slider&quot; data-content-id=&quot;0&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div id=&quot;row_1366978429649&quot; class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea whereu I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts VALUES("9","2013-04-26 12:14:42","2013-04-26 12:14:42","1","1","content","5","content","\n				&lt;div class=&quot;clearfix post-comments&quot;&gt;\n		            &lt;module class=&quot; module module-pictures &quot; data-mw-title=&quot;Picture Gallery&quot; style=&quot;padding-bottom: 130px;&quot; id=&quot;module-pictures-1742833173&quot; data-type=&quot;pictures&quot; data-template=&quot;slider&quot; data-content-id=&quot;0&quot;&gt;&lt;/module&gt;\n&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div id=&quot;row_1366978429649&quot; class=&quot;element&quot; style=&quot;width:95%&quot;&gt;\n					&lt;p class=&quot;element&quot; id=&quot;row_1364475814481&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;b class=&quot;&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Yes! Finaly I am on my vacation.&lt;/b&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814200&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;Have no idea where I will go but I am planing this to be my best vacantion Ever!&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;See the pictures I\'ve made :)&lt;/p&gt;\n&lt;p class=&quot;element&quot; id=&quot;row_1364475814167&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;To be continued... &lt;/p&gt;\n&lt;p id=&quot;row_1366978429939&quot; class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;p class=&quot;element&quot; style=&quot;margin: 0px 0px 10px; padding: 0px; position: relative; display: block; max-width: 100%; clear: both !important; transition: none !important; -webkit-transition: none !important; -webkit-transform-origin: 50% 50%; color: rgb(105, 105, 105); font-family: \'Open Sans\', Arial, sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 24px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(243, 243, 243);&quot;&gt;&lt;br class=&quot;&quot;&gt;&lt;/p&gt;\n				&lt;/div&gt;&lt;/div&gt;\n				&lt;div class=&quot;mw-col-container&quot;&gt;&lt;div class=&quot;element&quot;&gt;\n&lt;p class=&quot;element&quot;&gt;&lt;/p&gt;\n&lt;hr class=&quot;visible-desktop column-hr&quot;&gt;\n&lt;p class=&quot;&quot;&gt;&lt;/p&gt;\n&lt;/div&gt;&lt;/div&gt;\n			","767mavjv4rcccqfibt4ofmbsg5","y","ready-for-a-travel"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */countries; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */countries` (
  `id` int(11) NOT NULL,
  `code` text NOT NULL,
  `name` text NOT NULL,
  `continent` longtext NOT NULL,
  `surfacearea` float NOT NULL,
  `population` int(11) NOT NULL,
  `localname` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("1","AFG","Afghanistan","Asia","652090","22720000","Afganistan/Afqanestan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("2","NLD","Netherlands","Europe","41526","15864000","Nederland"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("3","ANT","Netherlands Antilles","North America","800","217000","Nederlandse Antillen"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("4","ALB","Albania","Europe","28748","3401200","ShqipÃ«ria"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("5","DZA","Algeria","Africa","2381740","31471000","Al-Jazaâ€™ir/AlgÃ©rie"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("6","ASM","American Samoa","Oceania","199","68000","Amerika Samoa"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("7","AND","Andorra","Europe","468","78000","Andorra"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("8","AGO","Angola","Africa","1246700","12878000","Angola"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("9","AIA","Anguilla","North America","96","8000","Anguilla"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("10","ATG","Antigua and Barbuda","North America","442","68000","Antigua and Barbuda"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("11","ARE","United Arab Emirates","Asia","83600","2441000","Al-Imarat al-Â´Arabiya al-Muttahida"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("12","ARG","Argentina","South America","2780400","37032000","Argentina"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("13","ARM","Armenia","Asia","29800","3520000","Hajastan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("14","ABW","Aruba","North America","193","103000","Aruba"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("15","AUS","Australia","Oceania","7741220","18886000","Australia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("16","AZE","Azerbaijan","Asia","86600","7734000","AzÃ¤rbaycan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("17","BHS","Bahamas","North America","13878","307000","The Bahamas"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("18","BHR","Bahrain","Asia","694","617000","Al-Bahrayn"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("19","BGD","Bangladesh","Asia","143998","129155000","Bangladesh"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("20","BRB","Barbados","North America","430","270000","Barbados"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("21","BEL","Belgium","Europe","30518","10239000","BelgiÃ«/Belgique"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("22","BLZ","Belize","North America","22696","241000","Belize"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("23","BEN","Benin","Africa","112622","6097000","BÃ©nin"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("24","BMU","Bermuda","North America","53","65000","Bermuda"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("25","BTN","Bhutan","Asia","47000","2124000","Druk-Yul"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("26","BOL","Bolivia","South America","1098580","8329000","Bolivia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("27","BIH","Bosnia and Herzegovina","Europe","51197","3972000","Bosna i Hercegovina"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("28","BWA","Botswana","Africa","581730","1622000","Botswana"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("29","BRA","Brazil","South America","8547400","170115000","Brasil"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("30","GBR","United Kingdom","Europe","242900","59623400","United Kingdom"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("31","VGB","Virgin Islands, British","North America","151","21000","British Virgin Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("32","BRN","Brunei","Asia","5765","328000","Brunei Darussalam"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("33","BGR","Bulgaria","Europe","110994","8190900","Balgarija"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("34","BFA","Burkina Faso","Africa","274000","11937000","Burkina Faso"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("35","BDI","Burundi","Africa","27834","6695000","Burundi/Uburundi"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("36","CYM","Cayman Islands","North America","264","38000","Cayman Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("37","CHL","Chile","South America","756626","15211000","Chile"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("38","COK","Cook Islands","Oceania","236","20000","The Cook Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("39","CRI","Costa Rica","North America","51100","4023000","Costa Rica"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("40","DJI","Djibouti","Africa","23200","638000","Djibouti/Jibuti"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("41","DMA","Dominica","North America","751","71000","Dominica"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("42","DOM","Dominican Republic","North America","48511","8495000","RepÃºblica Dominicana"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("43","ECU","Ecuador","South America","283561","12646000","Ecuador"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("44","EGY","Egypt","Africa","1001450","68470000","Misr"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("45","SLV","El Salvador","North America","21041","6276000","El Salvador"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("46","ERI","Eritrea","Africa","117600","3850000","Ertra"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("47","ESP","Spain","Europe","505992","39441700","EspaÃ±a"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("48","ZAF","South Africa","Africa","1221040","40377000","South Africa"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("49","ETH","Ethiopia","Africa","1104300","62565000","YeItyopÂ´iya"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("50","FLK","Falkland Islands","South America","12173","2000","Falkland Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("51","FJI","Fiji Islands","Oceania","18274","817000","Fiji Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("52","PHL","Philippines","Asia","300000","75967000","Pilipinas"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("53","FRO","Faroe Islands","Europe","1399","43000","FÃ¸royar"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("54","GAB","Gabon","Africa","267668","1226000","Le Gabon"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("55","GMB","Gambia","Africa","11295","1305000","The Gambia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("56","GEO","Georgia","Asia","69700","4968000","Sakartvelo"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("57","GHA","Ghana","Africa","238533","20212000","Ghana"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("58","GIB","Gibraltar","Europe","6","25000","Gibraltar"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("59","GRD","Grenada","North America","344","94000","Grenada"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("60","GRL","Greenland","North America","2166090","56000","Kalaallit Nunaat/GrÃ¸nland"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("61","GLP","Guadeloupe","North America","1705","456000","Guadeloupe"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("62","GUM","Guam","Oceania","549","168000","Guam"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("63","GTM","Guatemala","North America","108889","11385000","Guatemala"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("64","GIN","Guinea","Africa","245857","7430000","GuinÃ©e"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("65","GNB","Guinea-Bissau","Africa","36125","1213000","GuinÃ©-Bissau"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("66","GUY","Guyana","South America","214969","861000","Guyana"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("67","HTI","Haiti","North America","27750","8222000","HaÃ¯ti/Dayti"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("68","HND","Honduras","North America","112088","6485000","Honduras"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("69","HKG","Hong Kong","Asia","1075","6782000","Xianggang/Hong Kong"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("70","SJM","Svalbard and Jan Mayen","Europe","62422","3200","Svalbard og Jan Mayen"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("71","IDN","Indonesia","Asia","1904570","212107000","Indonesia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("72","IND","India","Asia","3287260","1013662000","Bharat/India"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("73","IRQ","Iraq","Asia","438317","23115000","Al-Â´Iraq"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("74","IRN","Iran","Asia","1648200","67702000","Iran"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("75","IRL","Ireland","Europe","70273","3775100","Ireland/Ã‰ire"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("76","ISL","Iceland","Europe","103000","279000","Ãsland"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("77","ISR","Israel","Asia","21056","6217000","Yisraâ€™el/Israâ€™il"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("78","ITA","Italy","Europe","301316","57680000","Italia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("79","TMP","East Timor","Asia","14874","885000","Timor Timur"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("80","AUT","Austria","Europe","83859","8091800","Ã–sterreich"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("81","JAM","Jamaica","North America","10990","2583000","Jamaica"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("82","JPN","Japan","Asia","377829","126714000","Nihon/Nippon"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("83","YEM","Yemen","Asia","527968","18112000","Al-Yaman"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("84","JOR","Jordan","Asia","88946","5083000","Al-Urdunn"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("85","CXR","Christmas Island","Oceania","135","2500","Christmas Island"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("86","YUG","Yugoslavia","Europe","102173","10640000","Jugoslavija"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("87","KHM","Cambodia","Asia","181035","11168000","KÃ¢mpuchÃ©a"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("88","CMR","Cameroon","Africa","475442","15085000","Cameroun/Cameroon"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("89","CAN","Canada","North America","9970610","31147000","Canada"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("90","CPV","Cape Verde","Africa","4033","428000","Cabo Verde"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("91","KAZ","Kazakstan","Asia","2724900","16223000","Qazaqstan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("92","KEN","Kenya","Africa","580367","30080000","Kenya"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("93","CAF","Central African Republic","Africa","622984","3615000","Centrafrique/BÃª-AfrÃ®ka"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("94","CHN","China","Asia","9572900","1277558000","Zhongquo"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("95","KGZ","Kyrgyzstan","Asia","199900","4699000","Kyrgyzstan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("96","KIR","Kiribati","Oceania","726","83000","Kiribati"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("97","COL","Colombia","South America","1138910","42321000","Colombia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("98","COM","Comoros","Africa","1862","578000","Komori/Comores"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("99","COG","Congo","Africa","342000","2943000","Congo"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("100","COD","Congo, The Democratic Republic of the","Africa","2344860","51654000","RÃ©publique DÃ©mocratique du Congo"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("101","CCK","Cocos (Keeling) Islands","Oceania","14","600","Cocos (Keeling) Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("102","PRK","North Korea","Asia","120538","24039000","Choson Minjujuui InÂ´min Konghwaguk (Bukhan)"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("103","KOR","South Korea","Asia","99434","46844000","Taehan Minâ€™guk (Namhan)"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("104","GRC","Greece","Europe","131626","10545700","EllÃ¡da"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("105","HRV","Croatia","Europe","56538","4473000","Hrvatska"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("106","CUB","Cuba","North America","110861","11201000","Cuba"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("107","KWT","Kuwait","Asia","17818","1972000","Al-Kuwayt"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("108","CYP","Cyprus","Asia","9251","754700","KÃ½pros/Kibris"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("109","LAO","Laos","Asia","236800","5433000","Lao"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("110","LVA","Latvia","Europe","64589","2424200","Latvija"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("111","LSO","Lesotho","Africa","30355","2153000","Lesotho"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("112","LBN","Lebanon","Asia","10400","3282000","Lubnan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("113","LBR","Liberia","Africa","111369","3154000","Liberia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("114","LBY","Libyan Arab Jamahiriya","Africa","1759540","5605000","Libiya"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("115","LIE","Liechtenstein","Europe","160","32300","Liechtenstein"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("116","LTU","Lithuania","Europe","65301","3698500","Lietuva"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("117","LUX","Luxembourg","Europe","2586","435700","Luxembourg/LÃ«tzebuerg"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("118","ESH","Western Sahara","Africa","266000","293000","As-Sahrawiya"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("119","MAC","Macao","Asia","18","473000","Macau/Aomen"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("120","MDG","Madagascar","Africa","587041","15942000","Madagasikara/Madagascar"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("121","MKD","Macedonia","Europe","25713","2024000","Makedonija"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("122","MWI","Malawi","Africa","118484","10925000","Malawi"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("123","MDV","Maldives","Asia","298","286000","Dhivehi Raajje/Maldives"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("124","MYS","Malaysia","Asia","329758","22244000","Malaysia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("125","MLI","Mali","Africa","1240190","11234000","Mali"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("126","MLT","Malta","Europe","316","380200","Malta"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("127","MAR","Morocco","Africa","446550","28351000","Al-Maghrib"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("128","MHL","Marshall Islands","Oceania","181","64000","Marshall Islands/Majol"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("129","MTQ","Martinique","North America","1102","395000","Martinique"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("130","MRT","Mauritania","Africa","1025520","2670000","Muritaniya/Mauritanie"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("131","MUS","Mauritius","Africa","2040","1158000","Mauritius"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("132","MYT","Mayotte","Africa","373","149000","Mayotte"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("133","MEX","Mexico","North America","1958200","98881000","MÃ©xico"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("134","FSM","Micronesia, Federated States of","Oceania","702","119000","Micronesia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("135","MDA","Moldova","Europe","33851","4380000","Moldova"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("136","MCO","Monaco","Europe","1.5","34000","Monaco"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("137","MNG","Mongolia","Asia","1566500","2662000","Mongol Uls"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("138","MSR","Montserrat","North America","102","11000","Montserrat"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("139","MOZ","Mozambique","Africa","801590","19680000","MoÃ§ambique"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("140","MMR","Myanmar","Asia","676578","45611000","Myanma Pye"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("141","NAM","Namibia","Africa","824292","1726000","Namibia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("142","NRU","Nauru","Oceania","21","12000","Naoero/Nauru"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("143","NPL","Nepal","Asia","147181","23930000","Nepal"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("144","NIC","Nicaragua","North America","130000","5074000","Nicaragua"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("145","NER","Niger","Africa","1267000","10730000","Niger"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("146","NGA","Nigeria","Africa","923768","111506000","Nigeria"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("147","NIU","Niue","Oceania","260","2000","Niue"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("148","NFK","Norfolk Island","Oceania","36","2000","Norfolk Island"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("149","NOR","Norway","Europe","323877","4478500","Norge"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("150","CIV","CÃ´te dâ€™Ivoire","Africa","322463","14786000","CÃ´te dâ€™Ivoire"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("151","OMN","Oman","Asia","309500","2542000","Â´Uman"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("152","PAK","Pakistan","Asia","796095","156483000","Pakistan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("153","PLW","Palau","Oceania","459","19000","Belau/Palau"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("154","PAN","Panama","North America","75517","2856000","PanamÃ¡"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("155","PNG","Papua New Guinea","Oceania","462840","4807000","Papua New Guinea/Papua Niugini"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("156","PRY","Paraguay","South America","406752","5496000","Paraguay"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("157","PER","Peru","South America","1285220","25662000","PerÃº/Piruw"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("158","PCN","Pitcairn","Oceania","49","50","Pitcairn"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("159","MNP","Northern Mariana Islands","Oceania","464","78000","Northern Mariana Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("160","PRT","Portugal","Europe","91982","9997600","Portugal"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("161","PRI","Puerto Rico","North America","8875","3869000","Puerto Rico"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("162","POL","Poland","Europe","323250","38653600","Polska"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("163","GNQ","Equatorial Guinea","Africa","28051","453000","Guinea Ecuatorial"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("164","QAT","Qatar","Asia","11000","599000","Qatar"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("165","FRA","France","Europe","551500","59225700","France"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("166","GUF","French Guiana","South America","90000","181000","Guyane franÃ§aise"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("167","PYF","French Polynesia","Oceania","4000","235000","PolynÃ©sie franÃ§aise"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("168","REU","RÃ©union","Africa","2510","699000","RÃ©union"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("169","ROM","Romania","Europe","238391","22455500","RomÃ¢nia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("170","RWA","Rwanda","Africa","26338","7733000","Rwanda/Urwanda"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("171","SWE","Sweden","Europe","449964","8861400","Sverige"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("172","SHN","Saint Helena","Africa","314","6000","Saint Helena"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("173","KNA","Saint Kitts and Nevis","North America","261","38000","Saint Kitts and Nevis"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("174","LCA","Saint Lucia","North America","622","154000","Saint Lucia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("175","VCT","Saint Vincent and the Grenadines","North America","388","114000","Saint Vincent and the Grenadines"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("176","SPM","Saint Pierre and Miquelon","North America","242","7000","Saint-Pierre-et-Miquelon"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("177","DEU","Germany","Europe","357022","82164700","Deutschland"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("178","SLB","Solomon Islands","Oceania","28896","444000","Solomon Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("179","ZMB","Zambia","Africa","752618","9169000","Zambia"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("180","WSM","Samoa","Oceania","2831","180000","Samoa"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("181","SMR","San Marino","Europe","61","27000","San Marino"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("182","STP","Sao Tome and Principe","Africa","964","147000","SÃ£o TomÃ© e PrÃ­ncipe"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("183","SAU","Saudi Arabia","Asia","2149690","21607000","Al-Â´Arabiya as-SaÂ´udiya"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("184","SEN","Senegal","Africa","196722","9481000","SÃ©nÃ©gal/Sounougal"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("185","SYC","Seychelles","Africa","455","77000","Sesel/Seychelles"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("186","SLE","Sierra Leone","Africa","71740","4854000","Sierra Leone"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("187","SGP","Singapore","Asia","618","3567000","Singapore/Singapura/Xinjiapo/Singapur"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("188","SVK","Slovakia","Europe","49012","5398700","Slovensko"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("189","SVN","Slovenia","Europe","20256","1987800","Slovenija"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("190","SOM","Somalia","Africa","637657","10097000","Soomaaliya"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("191","LKA","Sri Lanka","Asia","65610","18827000","Sri Lanka/Ilankai"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("192","SDN","Sudan","Africa","2505810","29490000","As-Sudan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("193","FIN","Finland","Europe","338145","5171300","Suomi"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("194","SUR","Suriname","South America","163265","417000","Suriname"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("195","SWZ","Swaziland","Africa","17364","1008000","kaNgwane"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("196","CHE","Switzerland","Europe","41284","7160400","Schweiz/Suisse/Svizzera/Svizra"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("197","SYR","Syria","Asia","185180","16125000","Suriya"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("198","TJK","Tajikistan","Asia","143100","6188000","ToÃ§ikiston"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("199","TWN","Taiwan","Asia","36188","22256000","Tâ€™ai-wan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("200","TZA","Tanzania","Africa","883749","33517000","Tanzania"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("201","DNK","Denmark","Europe","43094","5330000","Danmark"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("202","THA","Thailand","Asia","513115","61399000","Prathet Thai"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("203","TGO","Togo","Africa","56785","4629000","Togo"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("204","TKL","Tokelau","Oceania","12","2000","Tokelau"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("205","TON","Tonga","Oceania","650","99000","Tonga"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("206","TTO","Trinidad and Tobago","North America","5130","1295000","Trinidad and Tobago"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("207","TCD","Chad","Africa","1284000","7651000","Tchad/Tshad"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("208","CZE","Czech Republic","Europe","78866","10278100","Â¸esko"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("209","TUN","Tunisia","Africa","163610","9586000","Tunis/Tunisie"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("210","TUR","Turkey","Asia","774815","66591000","TÃ¼rkiye"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("211","TKM","Turkmenistan","Asia","488100","4459000","TÃ¼rkmenostan"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("212","TCA","Turks and Caicos Islands","North America","430","17000","The Turks and Caicos Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("213","TUV","Tuvalu","Oceania","26","12000","Tuvalu"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("214","UGA","Uganda","Africa","241038","21778000","Uganda"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("215","UKR","Ukraine","Europe","603700","50456000","Ukrajina"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("216","HUN","Hungary","Europe","93030","10043200","MagyarorszÃ¡g"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("217","URY","Uruguay","South America","175016","3337000","Uruguay"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("218","NCL","New Caledonia","Oceania","18575","214000","Nouvelle-CalÃ©donie"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("219","NZL","New Zealand","Oceania","270534","3862000","New Zealand/Aotearoa"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("220","UZB","Uzbekistan","Asia","447400","24318000","Uzbekiston"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("221","BLR","Belarus","Europe","207600","10236000","Belarus"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("222","WLF","Wallis and Futuna","Oceania","200","15000","Wallis-et-Futuna"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("223","VUT","Vanuatu","Oceania","12189","190000","Vanuatu"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("224","VAT","Holy See (Vatican City State)","Europe","0.4","1000","Santa Sede/CittÃ  del Vaticano"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("225","VEN","Venezuela","South America","912050","24170000","Venezuela"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("226","RUS","Russian Federation","Europe","17075400","146934000","Rossija"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("227","VNM","Vietnam","Asia","331689","79832000","ViÃªt Nam"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("228","EST","Estonia","Europe","45227","1439200","Eesti"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("229","USA","United States","North America","9363520","278357000","United States"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("230","VIR","Virgin Islands, U.S.","North America","347","93000","Virgin Islands of the United States"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("231","ZWE","Zimbabwe","Africa","390757","11669000","Zimbabwe"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("232","PSE","Palestine","Asia","6257","3101000","Filastin"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("233","ATA","Antarctica","Antarctica","13120000","0","â€“"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("234","BVT","Bouvet Island","Antarctica","59","0","BouvetÃ¸ya"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("235","IOT","British Indian Ocean Territory","Africa","78","0","British Indian Ocean Territory"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("236","SGS","South Georgia and the South Sandwich Islands","Antarctica","3903","0","South Georgia and the South Sandwich Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("237","HMD","Heard Island and McDonald Islands","Antarctica","359","0","Heard and McDonald Islands"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("238","ATF","French Southern territories","Antarctica","7780","0","Terres australes franÃ§aises"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */countries VALUES("239","UMI","United States Minor Outlying Islands","Oceania","16","0","United States Minor Outlying Islands"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */custom_fields; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel` text,
  `rel_id` text,
  `session_id` varchar(50) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `custom_field_name` text,
  `custom_field_name_plain` longtext,
  `custom_field_value` text,
  `custom_field_type` text,
  `custom_field_values` longtext,
  `custom_field_values_plain` longtext,
  `field_for` text,
  `custom_field_field_for` text,
  `custom_field_help_text` text,
  `options` text,
  `custom_field_is_active` char(1) DEFAULT 'y',
  `custom_field_required` char(1) DEFAULT 'n',
  `copy_of_field` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(55)),
  KEY `custom_field_type` (`custom_field_type`(55))
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("1","content","6","767mavjv4rcccqfibt4ofmbsg5","0","2013-04-26 14:23:14","2013-04-26 14:23:14","1","1","Price","price","","price","","","","","","","y","n",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("2","content","7","767mavjv4rcccqfibt4ofmbsg5","0","2013-04-26 14:24:39","2013-04-26 14:24:39","1","1","Price","price","","price","","","","","","","y","n",""); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */elements; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `expires_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `name` text,
  `parent_id` int(11) DEFAULT NULL,
  `module_id` text,
  `module` text,
  `description` text,
  `icon` text,
  `author` text,
  `website` text,
  `help` text,
  `installed` int(11) DEFAULT NULL,
  `ui` int(11) DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `as_element` int(11) DEFAULT '0',
  `ui_admin` int(11) DEFAULT '0',
  `version` varchar(11) DEFAULT NULL,
  `notifications` int(11) DEFAULT '0',
  `layout_type` varchar(110) DEFAULT 'static',
  PRIMARY KEY (`id`),
  KEY `module` (`module`(255)),
  KEY `module_id` (`module_id`(255))
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("1","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","4 Pictures","0","","4pics","4 pictures in 2 columns","{SITE_URL}userfiles/elements/4pics.png","Microweber","http://microweber.com","","","0","8","1","0","0.01","0","dynamic"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("2","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","4 Pictures","0","","4pics_with_text","4 pictures in 2 columns","{SITE_URL}userfiles/elements/4pics_with_text.png","Microweber","http://microweber.com","","","0","1","1","0","0.2","0","dynamic"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("3","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Double - floated image with paragraph","0","","floatet_image_paragraph_2x","Two elements with floated image(on the left) and a paragraph (on the right)","{SITE_URL}userfiles/elements/floatet_image_paragraph_2x.png","Microweber","http://microweber.com","","","0","9","1","0","0.1","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("4","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Image, text, categories and banners.","0","","header_imgcategories_text_multiple_baners","Header Image with categories text and banners.","{SITE_URL}userfiles/elements/header_imgcategories_text_multiple_baners.png","Microweber","http://microweber.com","","","0","5","1","0","0.7","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("5","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Image Categories Text","0","","image_cats_left_text","Widescreen image with categories on the bottom left and text.","{SITE_URL}userfiles/elements/image_cats_left_text.png","Microweber","http://microweber.com","","","0","1","1","0","0.5","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("6","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Image Categories Text","0","","image_cats_right_text","Widescreen image with categories on the bottom right and text on the bottom left side.","{SITE_URL}userfiles/elements/image_cats_right_text.png","Microweber","http://microweber.com","","","0","10","1","0","0.1","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("7","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Header Image text, newsletter, banners and categories.","0","","image_text_subscribe_banners_cats_left","Header Image with text, newsletter, banners and categories.","{SITE_URL}userfiles/elements/image_text_subscribe_banners_cats_left.png","Microweber","http://microweber.com","","","0","3","1","0","0.2","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("8","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Header Image text, newsletter, banners and categories.","0","","image_text_subscribe_banners_cats_right","Header Image with text, newsletter, banners and categories.","{SITE_URL}userfiles/elements/image_text_subscribe_banners_cats_right.png","Microweber","http://microweber.com","","","0","4","1","0","0.1","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("9","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Last articles","0","","last_articles","Last articles","{SITE_URL}userfiles/elements/last_articles.png","Microweber","http://microweber.com","","","0","6","1","0","1.4","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("10","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Table","0","","tables/default_table","Simple table","{SITE_URL}userfiles/elements/tables/default_table.png","Microweber","http://microweber.com","","","0","10","1","0","0.2","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("11","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Accordion","0","","tabs/accordion","Simple Tabs","{SITE_URL}userfiles/elements/tabs/accordion.png","Microweber","http://microweber.com","","","0","12","1","0","0.2","0","dynamic"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("12","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Tabs","0","","tabs/tabs","Simple Tabs","{SITE_URL}userfiles/elements/tabs/tabs.png","Microweber","http://microweber.com","","","0","10","1","0","0.2","0","dynamic"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("13","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Simple Text","0","","text only/01_text_only","Text 1 column full width","{SITE_URL}userfiles/elements/text only/01_text_only.png","Microweber","http://microweber.com","","","0","1","1","0","0.41","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("14","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Text 2 columns","0","","text only/02_text_2_columns","Text 2 columns","{SITE_URL}userfiles/elements/text only/02_text_2_columns.png","Microweber","http://microweber.com","","","0","2","1","0","0.2","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("15","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Three Coloms","0","","text only/03_text_3_columns","Text 3 columns","{SITE_URL}userfiles/elements/text only/03_text_3_columns.png","Microweber","http://microweber.com","","","0","3","1","0","0.2","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("16","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Text with picture","0","","text with picture/01_text_with_pic","Text with picture","{SITE_URL}userfiles/elements/text with picture/01_text_with_pic.png","Microweber","http://microweber.com","","","0","4","1","0","0.1","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("17","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Two Coloms with Pictures","0","","text with picture/02_text_2_column","2 columns with text and picture","{SITE_URL}userfiles/elements/text with picture/02_text_2_column.png","Microweber","http://microweber.com","","","0","4","1","0","0.1","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("18","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Three Columns with Pictures","0","","text with picture/03_text_3_column","Text and pictures 3 column","{SITE_URL}userfiles/elements/text with picture/03_text_3_column.png","Microweber","http://microweber.com","","","0","1","1","0","0.2","0","dynamic"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("19","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Text with Picture","0","","text with picture/04_text_column","Text with wide picture on the top.","{SITE_URL}userfiles/elements/text with picture/04_text_column.png","Microweber","http://microweber.com","","","0","7","1","0","0.4","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("20","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Two Coloms &amp; Picture","0","","text with picture/05_text_column","Text (2 columns) and wide picture","{SITE_URL}userfiles/elements/text with picture/05_text_column.png","Microweber","http://microweber.com","","","0","5","1","0","0.2","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("21","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Text (3 columns) and wide picture","0","","text with picture/06_text_column","Text (3 columns) and wide picture","{SITE_URL}userfiles/elements/text with picture/06_text_column.png","Microweber","http://microweber.com","","","0","6","1","0","0.2","0","static"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */elements VALUES("22","2013-04-24 15:43:18","2013-04-24 15:43:18","","0","0","Team","0","","text with picture/team","Team","{SITE_URL}userfiles/elements/text with picture/team.png","Microweber","http://microweber.com","","","0","7","1","0","1","0","static"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */forms_data; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */forms_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `rel` text,
  `rel_id` text,
  `list_id` int(11) DEFAULT '0',
  `form_values` text,
  `module_name` text,
  `url` text,
  `user_ip` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(255)),
  KEY `list_id` (`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */forms_lists; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */forms_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `title` longtext,
  `description` text,
  `custom_data` text,
  `module_name` text,
  `last_export` datetime DEFAULT NULL,
  `last_sent` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`(55))
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */ip2country; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */ip2country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` text,
  `ip_long` text,
  `country_code` text,
  `country_name` text,
  `region` text,
  `city` text,
  `latitude` text,
  `longitude` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */ip2country VALUES("1","192.168.56.1","","","Unknown","","","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */ip2country VALUES("2","192.168.56.1","","","Unknown","","","",""); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */log; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `rel` text,
  `rel_id` text,
  `position` int(11) DEFAULT NULL,
  `field` longtext,
  `value` text,
  `module` longtext,
  `data_type` text,
  `title` longtext,
  `description` text,
  `content` text,
  `user_ip` text,
  `session_id` longtext,
  `is_system` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("1","2013-04-26 14:26:45","2013-04-26 14:26:45","1","1","backup","","","action","Creating full backup","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("2","2013-04-26 14:26:45","2013-04-26 14:26:45","1","1","backup","","","action","Adding userfiles to zip","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("3","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Starting database backup","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("4","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcart","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("5","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcart_orders","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("6","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcart_shipping","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("7","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcategories","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("8","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcategories_items","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("9","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcomments","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("10","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcontent","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("11","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcontent_fields","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("12","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcontent_fields_drafts","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("13","2013-04-26 14:27:43","2013-04-26 14:27:43","1","1","backup","","","action","Backing up database table default_contentcountries","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("14","2013-04-26 14:27:44","2013-04-26 14:27:44","1","1","backup","","","action","Backing up database table default_contentcustom_fields","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("15","2013-04-26 14:27:44","2013-04-26 14:27:44","1","1","backup","","","action","Backing up database table default_contentelements","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("16","2013-04-26 14:27:44","2013-04-26 14:27:44","1","1","backup","","","action","Backing up database table default_contentforms_data","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("17","2013-04-26 14:27:44","2013-04-26 14:27:44","1","1","backup","","","action","Backing up database table default_contentforms_lists","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("18","2013-04-26 14:27:45","2013-04-26 14:27:45","1","1","backup","","","action","Backing up database table default_contentip2country","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */log VALUES("19","2013-04-26 14:27:45","2013-04-26 14:27:45","1","1","backup","","","action","Backing up database table default_contentlog","","","","","","192.168.56.1","767mavjv4rcccqfibt4ofmbsg5","y"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */media; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `session_id` varchar(50) DEFAULT NULL,
  `rel` text,
  `rel_id` text,
  `media_type` text,
  `position` int(11) DEFAULT NULL,
  `title` longtext,
  `description` text,
  `embed_code` text,
  `filename` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(255)),
  KEY `media_type` (`media_type`(55))
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("3","2013-04-26 11:48:46","2013-04-26 11:48:46","1","1","767mavjv4rcccqfibt4ofmbsg5","content","5","picture","1","","","","{SITE_URL}userfiles/media/content/3.jpg"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("2","2013-04-26 11:48:40","2013-04-26 11:48:40","1","1","767mavjv4rcccqfibt4ofmbsg5","content","5","picture","2","","","","{SITE_URL}userfiles/media/content/2.jpg"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("1","2013-04-26 11:48:32","2013-04-26 11:48:32","1","1","767mavjv4rcccqfibt4ofmbsg5","content","5","picture","0","","","","{SITE_URL}userfiles/media/content/post1.jpg"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */menus; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `item_type` varchar(33) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `categories_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `is_active` char(1) DEFAULT 'y',
  `description` text,
  `url` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("1","header_menu","menu","","","","","2013-04-24 15:43:46","2013-04-24 15:43:46","y","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("2","footer_menu","menu","","","","","2013-04-24 15:43:47","2013-04-24 15:43:47","y","",""); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("3","","menu_item","1","4","","","2013-04-24 15:48:49","2013-04-24 15:48:49","y","",""); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */module_templates; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */module_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `module_id` text,
  `name` text,
  `module` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */modules; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `expires_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `name` text,
  `parent_id` int(11) DEFAULT NULL,
  `module_id` text,
  `module` text,
  `description` text,
  `icon` text,
  `author` text,
  `website` text,
  `help` text,
  `installed` int(11) DEFAULT NULL,
  `ui` int(11) DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `as_element` int(11) DEFAULT '0',
  `ui_admin` int(11) DEFAULT '0',
  `version` varchar(11) DEFAULT NULL,
  `notifications` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `module` (`module`(255)),
  KEY `module_id` (`module_id`(255))
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("1","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Accounting","0","","accounting","Online Accounting Software that records and processes small business accounting transactions within functional modules such as accounts payable, accounts receivable, trial balance etc. It functions as an accounting information system. ","{SITE_URL}userfiles/modules/accounting/accounting.png","Microweber/Numia","http://numia.biz/","http://microweber.info/modules/accounting","","1","9","0","1","0.3","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("2","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Backup","0","","admin/backup","","{SITE_URL}userfiles/modules/admin/backup/backup.png","Microweber","","","","0","50","0","1","0.1","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("3","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Console","0","","admin/console","","{SITE_URL}userfiles/modules/admin/console/console.png","Microweber","","","","0","35","0","1","1.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("4","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Ants","0","","ants","Ferocious ants for your website!","{SITE_URL}userfiles/modules/ants/ants.png","Tom Oram","","","","1","60","0","0","0.1","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("5","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Audio","0","","audio","Microweber","{SITE_URL}userfiles/modules/audio/audio.png","Microweber","http://microweber.com/","http://microweber.info/modules/audio","","1","9","0","0","0.29","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("6","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Button","0","","btn","","{SITE_URL}userfiles/modules/btn/btn.png","Microweber","","","","1","7","0","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("7","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Categories","0","","categories","","{SITE_URL}userfiles/modules/categories/categories.png","Microweber","","","","1","5","0","0","0.1","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("8","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Comments","0","","comments","","{SITE_URL}userfiles/modules/comments/comments.png","Microweber","","","","1","5","0","1","0.33","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("9","2013-04-24 15:43:15","2013-04-24 15:43:15","","0","0","Contact form","0","","contact_form","","{SITE_URL}userfiles/modules/contact_form/contact_form.png","Microweber","","","","1","4","0","1","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("10","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Empty Element","0","","content/empty_element","Microweber","{SITE_URL}userfiles/modules/content/empty_element.png","Microweber","http://microweber.com/","http://microweber.info/modules/title","","1","20","1","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("11","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Multiple Columns","0","","content/multiple_columns","Microweber","{SITE_URL}userfiles/modules/content/multiple_columns.png","Microweber","http://microweber.com/","http://microweber.info/modules/title","","1","3","1","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("12","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Custom fields","0","","custom_fields","","{SITE_URL}userfiles/modules/custom_fields/custom_fields.png","Microweber","","","","0","15","0","0","","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("13","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Embed Code","0","","embed","","{SITE_URL}userfiles/modules/embed/embed.png","Microweber","","","","1","15","0","0","0.4","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("14","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Facebook Like","0","","facebook_like","","{SITE_URL}userfiles/modules/facebook_like/facebook_like.png","Microweber","","","","1","10","0","0","0.06","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("15","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Files","0","","files","","{SITE_URL}userfiles/modules/default.png","Microweber","","","","1","20","0","1","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("16","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Google Maps","0","","google_maps","","{SITE_URL}userfiles/modules/google_maps/google_maps.png","Microweber","","","","1","10","0","0","0.3","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("17","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Help","0","","help","","{SITE_URL}userfiles/modules/default.png","Microweber","","","","0","80","0","1","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("18","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Highlight Code","0","","highlight_code","","{SITE_URL}userfiles/modules/highlight_code/highlight_code.png","Microweber test ","","","","1","31","0","0","0.05","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("19","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Ip2Country","0","","ip2country","","{SITE_URL}userfiles/modules/ip2country/ip2country.png","Microweber","","","","0","60","0","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("20","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Dynamic Layout","0","","layout","","{SITE_URL}userfiles/modules/layout/layout.png","Microweber","","","","1","35","0","0","1.22","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("21","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Menu","0","","menu","Navigation Menu","{SITE_URL}userfiles/modules/menu/menu.png","Microweber","","","","1","6","0","1","0.3","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("22","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Pages Menu","0","","pages","","{SITE_URL}userfiles/modules/pages/pages.png","Microweber","","","","1","5","0","0","1.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("23","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Picture","0","","picture","Simple picture","{SITE_URL}userfiles/modules/picture/picture.png","Microweber","","","","1","3","1","0","0.21","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("24","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Picture Gallery","0","","pictures","","{SITE_URL}userfiles/modules/pictures/pictures.png","Microweber","","","","1","4","0","0","0.1","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("25","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Posts List","0","","posts","","{SITE_URL}userfiles/modules/posts/posts.png","Microweber","","","","1","4","0","0","0.1","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("26","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Search","0","","search","Module to search for content","{SITE_URL}userfiles/modules/search/search.png","Microweber","http://microweber.com/","http://microweber.info/modules/search","","1","100","0","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("27","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Settings","0","","settings","","{SITE_URL}userfiles/modules/default.png","Microweber","","","","0","4","0","1","0.3","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("28","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Online shop","0","","shop","","{SITE_URL}userfiles/modules/default.png","Microweber","","","","0","2","0","1","0.3","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("29","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Shopping Cart","0","","shop/cart","","{SITE_URL}userfiles/modules/shop/cart/cart.png","Microweber","","","","1","5","0","0","0.24","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("30","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Add to cart","0","","shop/cart_add","","{SITE_URL}userfiles/modules/default.png","Microweber","","","","1","5","0","0","0.26","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("31","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Checkout","0","","shop/checkout","","{SITE_URL}userfiles/modules/shop/checkout/checkout.png","Microweber","","","","1","5","0","0","0.3","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("32","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Paypal Express payment gateway","0","","shop/payments/gateways/paypal","","{SITE_URL}userfiles/modules/shop/payments/gateways/paypal.png","Microweber","","","","0","10","0","0","","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("33","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Paypal Pro payment gateway","0","","shop/payments/gateways/paypal_pro","","{SITE_URL}userfiles/modules/shop/payments/gateways/paypal_pro.png","Microweber","","","","0","11","0","0","","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("34","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Products","0","","shop/products","","{SITE_URL}userfiles/modules/shop/products/products.png","Microweber","","","","1","4","0","0","0.41","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("35","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Shipping to country module","0","","shop/shipping/gateways/country","","{SITE_URL}userfiles/modules/default.png","Microweber","","","","0","100","0","0","","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("36","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Site stats","0","","site_stats","","{SITE_URL}userfiles/modules/default.png","Microweber","","","","0","30","0","1","0.3","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("37","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Text","0","","text","Simple text","{SITE_URL}userfiles/modules/text/text.png","Microweber","","","","1","2","1","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("38","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Title","0","","title","Microweber","{SITE_URL}userfiles/modules/title/title.png","Microweber","http://microweber.com/","http://microweber.info/modules/title","","1","1","1","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("39","2013-04-24 15:43:16","2013-04-24 15:43:16","","0","0","Users","0","","users","","{SITE_URL}userfiles/modules/users/users.png","Microweber","","","","0","9","0","1","0.3","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("40","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Forgot password","0","","users/forgot_password","Microweber","{SITE_URL}userfiles/modules/users/forgot_password/forgot_password.png","Microweber","http://microweber.com/","http://microweber.info/modules/users/registration","","1","100","0","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("41","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Login","0","","users/login","","{SITE_URL}userfiles/modules/users/login/login.png","Microweber","","","","1","9","0","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("42","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Registration","0","","users/register","Microweber","{SITE_URL}userfiles/modules/users/register/register.png","Microweber","http://microweber.com/","http://microweber.info/modules/users/registration","","1","10","0","0","0.2","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */modules VALUES("43","2013-04-24 15:43:17","2013-04-24 15:43:17","","0","0","Video","0","","video","","{SITE_URL}userfiles/modules/video/video.png","Microweber","","","","1","3","0","0","0.1","0"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */notifications; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `data_type` text,
  `title` longtext,
  `description` text,
  `content` text,
  `module` text,
  `rel` text,
  `rel_id` text,
  `notif_count` int(11) DEFAULT '1',
  `is_read` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(55))
) ENGINE=MyISAM DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */options; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `option_key` text,
  `option_value` longtext,
  `option_key2` text,
  `option_value2` longtext,
  `position` int(11) DEFAULT NULL,
  `option_group` text,
  `name` text,
  `help` text,
  `field_type` text,
  `field_values` text,
  `module` text,
  `is_system` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("1","2013-04-24 15:42:21","2013-04-24 15:42:21","website_title","Microweber","","","1","website","Website name","This is very important for the search engines. Your website will be categorized by many criterias and the name is one of it.","text","","","1"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("2","2013-04-24 15:42:21","2013-04-24 15:42:21","website_description","My website\'s description","","","2","website","Website description","Create Free Online Shop, Free Website and Free Blog with Microweber (MW)","textarea","","","1"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("3","2013-04-24 15:42:21","2013-04-24 15:42:21","website_keywords","free website, free shop, free blog, make web, mw, microweber","","","3","website","Website keywords","Write keywords for your site.","textarea","","","1"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("4","2013-04-24 15:42:21","2013-04-24 15:42:21","curent_template","default","","","5","template","Website template","This is your current template. You can easy change it anytime.","website_template","","","1"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("5","2013-04-24 15:42:21","2013-04-24 15:42:21","items_per_page","30","","","6","website","Items per page","Select how many items you want to have per page? example 10,25,50...","dropdown","YTo1OntpOjEwO3M6MjoiMTAiO2k6MzA7czoyOiIzMCI7aTo1MDtzOjI6IjUwIjtpOjEwMDtzOjM6IjEwMCI7aToyMDA7czozOiIyMDAiO30=","","1"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("6","2013-04-24 15:42:21","2013-04-24 15:42:21","enable_user_registration","y","","","10","users","Enable user registration","You can enable or disable the registration for new users","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","","1"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("7","2013-04-24 15:42:21","2013-04-24 15:42:21","currency","USD","","","1","payments","Currency","The website currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("8","2013-04-24 15:42:21","2013-04-24 15:42:21","payment_currency","USD","","","2","payments","Payment currency","Payment process in currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("9","2013-04-24 15:42:21","2013-04-24 15:42:21","payment_currency_rate","1.2","","","3","payments","Payment currency rate","Payment currency convert rate to site currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("10","2013-04-24 15:56:04","2013-04-24 15:56:04","data-page-id","4","","","","module-posts-blog-135566484","","","","","posts/admin","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("11","2013-04-26 11:50:22","2013-04-26 11:50:22","data-use-from-post","y","","","","module-pictures-1742833173","","","","","pictures/admin","0"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("12","2013-04-26 11:50:40","2013-04-26 11:50:40","data-template","inner.php","","","","module-pictures-1742833173","","","","","","0"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */stats_users_online; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */stats_users_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` int(11) DEFAULT NULL,
  `view_count` int(11) DEFAULT '1',
  `user_ip` varchar(33) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_time` time DEFAULT NULL,
  `last_page` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online VALUES("1","1","21","192.168.56.1","2013-04-24","17:29:42","/Microweber/index.php"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online VALUES("2","0","10","192.168.56.1","2013-04-25","11:26:30","{SITE_URL}admin/view:content"); /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online VALUES("3","1","18","192.168.56.1","2013-04-26","14:26:07","{SITE_URL}admin/view:content"); /* MW_QUERY_SEPERATOR */





DROP TABLE IF EXISTS /* MW_PREFIX_PLACEHOLDER */users; /* MW_QUERY_SEPERATOR */




CREATE TABLE `/* MW_PREFIX_PLACEHOLDER */users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `expires_on` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` text,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `username` text,
  `password` text,
  `email` text,
  `is_active` char(1) DEFAULT 'n',
  `is_admin` char(1) DEFAULT 'n',
  `is_verified` char(1) DEFAULT 'n',
  `is_public` char(1) DEFAULT 'y',
  `basic_mode` char(1) DEFAULT 'n',
  `first_name` text,
  `last_name` text,
  `thumbnail` text,
  `parent_id` int(11) DEFAULT NULL,
  `api_key` text,
  `user_information` text,
  `subscr_id` text,
  `role` text,
  `medium` text,
  `oauth_uid` text,
  `oauth_provider` text,
  `oauth_token` text,
  `oauth_token_secret` text,
  `profile_url` text,
  `website_url` text,
  `password_reset_hash` text,
  PRIMARY KEY (`id`),
  KEY `username` (`username`(255)),
  KEY `email` (`email`(255))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


INSERT INTO /* MW_PREFIX_PLACEHOLDER */users VALUES("1","2013-04-26 11:47:39","2013-04-24 15:42:26","","2013-04-26 11:47:39","192.168.56.1","0","1","boris","e10adc3949ba59abbe56e057f20f883e","boksiora@gmail.com","y","y","n","y","n","","","","","","","","","","","","","","","",""); /* MW_QUERY_SEPERATOR */





