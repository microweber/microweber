<?php

$config = array();
$config['name'] = "White label";
$config['author'] = "Microweber";
$config['categories'] = "advanced";
$config['position'] = "500";
$config['version'] = 0.2;



