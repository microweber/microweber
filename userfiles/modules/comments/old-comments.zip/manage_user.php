<div class="comment-actions" style="float: right;">
	<a href="javascript:edit_comment_user(<?php echo $params['comment_id']; ?>);" class="mw-ui-btn mw-ui-btn-outline mw-ui-btn-small mw-ui-btn-info"><?php _e("Edit"); ?></a>
	<a href="javascript:delete_comment_user(<?php echo $params['comment_id']; ?>);" class="mw-ui-btn mw-ui-btn-outline mw-ui-btn-small mw-ui-btn-important"><?php _e("Delete"); ?></a>
</div>