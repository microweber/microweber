<?php

$config = array();
$config['name'] = "Icons";
$config['author'] = "Microweber";
$config['description'] = "Microweber";
$config['website'] = "http://microweber.com/";
$config['version'] = 0.19;
$config['ui'] = false;

$config['position'] = 180;


$config['categories'] = "advanced";


