<?php




namespace MicroweberPackages\Shop\Shipping\Gateways\Express;

use Illuminate\Foundation\Support\Providers\EventServiceProvider;



class ShippingExpressEventServiceProvider extends EventServiceProvider
{
    protected $listen = [

    ];
}