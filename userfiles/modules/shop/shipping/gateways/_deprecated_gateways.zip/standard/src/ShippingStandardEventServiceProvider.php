<?php




namespace MicroweberPackages\Shop\Shipping\Gateways\Standard;

use Illuminate\Foundation\Support\Providers\EventServiceProvider;



class ShippingStandardEventServiceProvider extends EventServiceProvider
{
    protected $listen = [

    ];
}