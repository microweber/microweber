<?php

/*

type: layout

name: Default

description: Default

*/
?>

<?php  if($shipping_collection_instructions){ ?>
<?php

print $shipping_collection_instructions;
?>

<?php } ?>
