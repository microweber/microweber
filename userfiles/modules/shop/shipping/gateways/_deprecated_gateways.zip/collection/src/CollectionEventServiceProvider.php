<?php




namespace MicroweberPackages\Shop\Shipping\Gateways\Collection;

use Illuminate\Foundation\Support\Providers\EventServiceProvider;



class CollectionEventServiceProvider extends EventServiceProvider
{
    protected $listen = [

    ];
}