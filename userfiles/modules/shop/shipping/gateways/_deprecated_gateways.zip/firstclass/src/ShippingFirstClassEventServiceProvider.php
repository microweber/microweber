<?php




namespace MicroweberPackages\Shop\Shipping\Gateways\FirstClass;

use Illuminate\Foundation\Support\Providers\EventServiceProvider;



class ShippingFirstClassEventServiceProvider extends EventServiceProvider
{
    protected $listen = [

    ];
}