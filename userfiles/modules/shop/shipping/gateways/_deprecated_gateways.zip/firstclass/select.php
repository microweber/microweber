<module type="shop/shipping/gateways/firstclass" template="select" />
