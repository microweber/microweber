/* Microweber database backup exported on: Monday 18th of December 2017 10:15:13 AM */ 
/* get_table_prefix(): dream_temp_ */ 




CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */modules" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "expires_on" datetime null, "created_by" integer null, "edited_by" integer null, "name" text null, "parent_id" integer null, "module_id" text null, "module" text null, "description" text null, "icon" text null, "author" text null, "website" text null, "help" text null, "type" text null, "installed" integer null, "ui" integer null, "position" integer null, "as_element" integer null, "ui_admin" integer null, "ui_admin_iframe" integer null, "is_system" integer null, "version" varchar null, "notifications" integer null, "settings" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('1','2017-11-28 08:38:28','2017-11-28 08:38:28','','','','Content Revisions','0','','editor/content_revisions','','{SITE_URL}userfiles/modules/default.png','','','','','1','0','28','','0','','0','0.05','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('2','2017-11-28 08:38:37','2017-11-28 08:38:37','','','','Ants','0','','ants','Ferocious ants for your website!','{SITE_URL}userfiles/modules/ants/ants.png','Tom Oram','','','','1','1','28','','0','','0','0.05','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('3','2017-11-28 08:38:37','2017-11-28 08:38:37','','','','Menu','0','','menu','Navigation menu for pages and links.','{SITE_URL}userfiles/modules/menu/menu.png','Microweber','','','','1','1','15','','1','','0','0.5','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('4','2017-11-28 08:38:37','2017-11-28 08:38:37','','','','Google Maps','0','','google_maps','','{SITE_URL}userfiles/modules/google_maps/google_maps.png','Microweber','','','','1','1','24','','0','','0','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('5','2017-11-28 08:38:38','2017-11-28 08:38:38','','','','Magic Slider','0','','magicslider','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','0','13','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('6','2017-11-28 08:38:38','2017-11-28 08:38:38','','','','Calendar','0','','calendar','','{SITE_URL}userfiles/modules/calendar/calendar.png','nick@easy-host.uk','','','','1','1','99','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('7','2017-11-28 08:38:40','2017-11-28 08:38:40','','','','FAQ','0','','faq','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','57','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('8','2017-11-28 08:38:40','2017-11-28 08:38:40','','','','Text','0','','text','Simple text','{SITE_URL}userfiles/modules/text/text.png','Microweber','','','','1','1','2','1','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('9','2017-11-28 08:38:41','2017-11-28 08:38:41','','','','Empty Element','0','','text/empty_element','Microweber','{SITE_URL}userfiles/modules/text/empty_element.png','Microweber','http://microweber.com/','http://microweber.info/modules/title','','1','1','8','1','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('10','2017-11-28 08:38:41','2017-11-28 08:38:41','','','','Multiple Columns','0','','text/multiple_columns','Microweber','{SITE_URL}userfiles/modules/text/multiple_columns.png','Microweber','http://microweber.com/','http://microweber.info/modules/title','','1','1','3','1','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('11','2017-11-28 08:38:41','2017-11-28 08:38:41','','','','Carousel Grid','0','','carousel_grid','Microweber Carousel Grid','{SITE_URL}userfiles/modules/default.png','Microweber','http://microweber.com/','','','1','1','100','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('12','2017-11-28 08:38:42','2017-11-28 08:38:42','','','','Facebook Like','0','','facebook_like','','{SITE_URL}userfiles/modules/facebook_like/facebook_like.png','Microweber','','','','1','1','25','','0','','0','0.06','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('13','2017-11-28 08:38:42','2017-11-28 08:38:42','','','','Before/After','0','','beforeafter','','{SITE_URL}userfiles/modules/beforeafter/beforeafter.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('14','2017-11-28 08:38:42','2017-11-28 08:38:42','','','','Pages Menu','0','','pages','','{SITE_URL}userfiles/modules/pages/pages.png','Microweber','','','','1','1','15','','0','','1','1.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('15','2017-11-28 08:38:43','2017-11-28 08:38:43','','','','Layouts','0','','layouts','','{SITE_URL}userfiles/modules/layouts/layouts.png','Microweber','','','','1','1','99','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('16','2017-11-28 08:38:43','2017-11-28 08:38:43','','','','Files','0','','files','','{SITE_URL}userfiles/modules/files/files.png','Microweber','','','','1','0','20','','1','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('17','2017-11-28 08:38:43','2017-11-28 08:38:43','','','','Newsletter','0','','newsletter','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','55','','1','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('18','2017-11-28 08:38:48','2017-11-28 08:38:48','','','','Contact form','0','','contact_form','','{SITE_URL}userfiles/modules/contact_form/contact_form.png','Microweber','','','','1','1','9','','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('19','2017-11-28 08:38:49','2017-11-28 08:38:49','','','','Include','0','','include','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','50','','0','','0','0.12','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('20','2017-11-28 08:38:49','2017-11-28 08:38:49','','','','Accordion','0','','accordion','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','52','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('21','2017-11-28 08:38:49','2017-11-28 08:38:49','','','','Social Links','0','','social_links','','{SITE_URL}userfiles/modules/social_links/social_links.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('22','2017-11-28 08:38:49','2017-11-28 08:38:49','','','','Button','0','','btn','','{SITE_URL}userfiles/modules/btn/btn.png','Microweber','','','','1','1','7','','0','','0','0.9','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('23','2017-11-28 08:38:50','2017-11-28 08:38:50','','','','Hello REST','0','','hello_rest','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','24','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('24','2017-11-28 08:38:50','2017-11-28 08:38:50','','','','Video','0','','video','','{SITE_URL}userfiles/modules/video/video.png','Microweber','','','','1','1','5','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('25','2017-11-28 08:38:50','2017-11-28 08:38:50','','','','highlight_code','0','','highlight_code','','{SITE_URL}userfiles/modules/highlight_code/highlight_code.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('26','2017-11-28 08:38:50','2017-11-28 08:38:50','','','','Categories','0','','categories','','{SITE_URL}userfiles/modules/categories/categories.png','Microweber','','','','1','1','16','','0','','1','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('27','2017-11-28 08:38:51','2017-11-28 08:38:51','','','','Categories Images','0','','categories/category_images','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','51','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('28','2017-11-28 08:38:51','2017-11-28 08:38:51','','','','Title','0','','title','Microweber','{SITE_URL}userfiles/modules/title/title.png','Microweber','http://microweber.com/','http://microweber.info/modules/title','','1','1','1','1','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('29','2017-11-28 08:38:51','2017-11-28 08:38:51','','','','Tabs','0','','tabs','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','52','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('30','2017-11-28 08:38:51','2017-11-28 08:38:51','','','','White label','0','','white_label','','{SITE_URL}userfiles/modules/white_label/white_label.png','Microweber','','','','1','0','500','','1','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('31','2017-11-28 08:38:52','2017-11-28 08:38:52','','','','Posts List','0','','posts','','{SITE_URL}userfiles/modules/posts/posts.png','Microweber','','','','1','1','11','','0','','1','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('32','2017-11-28 08:38:52','2017-11-28 08:38:52','','','','Testimonials','0','','testimonials','','{SITE_URL}userfiles/modules/testimonials/testimonials.png','Microweber','','','','1','1','99','','1','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('33','2017-11-28 08:38:55','2017-11-28 08:38:55','','','','Picture Gallery','0','','pictures','','{SITE_URL}userfiles/modules/pictures/pictures.png','Microweber','','','','1','1','6','','0','','1','1.11','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('34','2017-11-28 08:38:55','2017-11-28 08:38:55','','','','PDF','0','','testov','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('35','2017-11-28 08:38:55','2017-11-28 08:38:55','','','','bxSlider','0','','bxslider','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','12','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('36','2017-11-28 08:38:56','2017-11-28 08:38:56','','','','Rating','0','','rating','Microweber','{SITE_URL}userfiles/modules/rating/rating.png','Microweber','http://microweber.com/','http://microweber.com','','1','0','100','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('37','2017-11-28 08:39:01','2017-11-28 08:39:01','','','','Twitter feed','0','','twitter_feed','Feed of tweets','{SITE_URL}userfiles/modules/default.png','Peter Ivanov','','','','1','1','120','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('38','2017-11-28 08:39:02','2017-11-28 08:39:02','','','','Tweet Embed','0','','tweet_embed','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('39','2017-11-28 08:39:02','2017-11-28 08:39:02','','','','Picture','0','','picture','Picture','{SITE_URL}userfiles/modules/picture/picture.png','Microweber','','','','1','1','4','1','0','','0','0.24','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('40','2017-11-28 08:39:02','2017-11-28 08:39:02','','','','Help','0','','help','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','0','80','','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('41','2017-11-28 08:39:02','2017-11-28 08:39:02','','','','Search','0','','search','Module to search for content','{SITE_URL}userfiles/modules/search/search.png','Microweber','http://microweber.com/','http://microweber.info/modules/search','','1','1','20','','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('42','2017-11-28 08:39:03','2017-11-28 08:39:03','','','','Facebook page','0','','facebook_page','Facebook page integration for your website!','{SITE_URL}userfiles/modules/facebook_page/facebook_page.png','','','','','1','1','100','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('43','2017-11-28 08:39:03','2017-11-28 08:39:03','','','','Notifications','0','','admin/notifications','','{SITE_URL}userfiles/modules/admin/notifications/notifications.png','Microweber','','','','1','0','50','','0','','1','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('44','2017-11-28 08:39:03','2017-11-28 08:39:03','','','','Backup','0','','admin/backup','','{SITE_URL}userfiles/modules/admin/backup/backup.png','Microweber','','','','1','0','50','','1','','0','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('45','2017-11-28 08:39:03','2017-11-28 08:39:03','','','','Import','0','','admin/import','','{SITE_URL}userfiles/modules/admin/import/import.png','Microweber','','','','1','0','99','','1','','0','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('46','2017-11-28 08:39:04','2017-11-28 08:39:04','','','','Site stats','0','','site_stats','','{SITE_URL}userfiles/modules/default.png','Microweber','','','stats','1','0','30','','0','','0','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('47','2017-11-28 08:39:12','2017-11-28 08:39:12','','','','Users','0','','users','','{SITE_URL}userfiles/modules/users/users.png','Microweber','','','','1','0','9','','1','','1','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('48','2017-11-28 08:39:12','2017-11-28 08:39:12','','','','Registration','0','','users/register','Microweber','{SITE_URL}userfiles/modules/users/register/register.png','Microweber','http://microweber.com/','http://microweber.info/modules/users/registration','','1','1','21','','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('49','2017-11-28 08:39:13','2017-11-28 08:39:13','','','','Forgot password','0','','users/forgot_password','Microweber','{SITE_URL}userfiles/modules/users/forgot_password/forgot_password.png','Microweber','http://microweber.com/','http://microweber.info/modules/users/registration','','1','1','23','','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('50','2017-11-28 08:39:13','2017-11-28 08:39:13','','','','Login','0','','users/login','','{SITE_URL}userfiles/modules/users/login/login.png','Microweber','','','','1','1','22','','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('51','2017-11-28 08:39:13','2017-11-28 08:39:13','','','','Sharer','0','','sharer','','{SITE_URL}userfiles/modules/sharer/sharer.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('52','2017-11-28 08:39:13','2017-11-28 08:39:13','','','','Breadbrumb','0','','breadcrumb','Breadbrumb navigation','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','54','','0','','0','0.2','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('53','2017-11-28 08:39:14','2017-11-28 08:39:14','','','','Logo','0','','logo','','{SITE_URL}userfiles/modules/logo/logo.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('54','2017-11-28 08:39:14','2017-11-28 08:39:14','','','','Skills','0','','skills','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('55','2017-11-28 08:39:14','2017-11-28 08:39:14','','','','Settings','0','','settings','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','0','4','','0','','1','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('56','2017-11-28 08:39:15','2017-11-28 08:39:15','','','','Pricing Table','0','','pricing_table','Free pricing table module for your website!','{SITE_URL}userfiles/modules/pricing_table/pricing_table.png','Petko Yovchevski','','','','1','1','100','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('57','2017-11-28 08:39:15','2017-11-28 08:39:15','','','','Slick Slider','0','','slickslider','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','13','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('58','2017-11-28 08:39:15','2017-11-28 08:39:15','','','','Custom fields','0','','custom_fields','','{SITE_URL}userfiles/modules/custom_fields/custom_fields.png','Microweber','','','','1','0','15','','0','','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('59','2017-11-28 08:39:15','2017-11-28 08:39:15','','','','Team Card','0','','teamcard','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','57','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('60','2017-11-28 08:39:16','2017-11-28 08:39:16','','','','Audio','0','','audio','Microweber','{SITE_URL}userfiles/modules/audio/audio.png','Microweber','http://microweber.com/','http://microweber.info/modules/audio','','1','1','18','','0','','0','0.19','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('61','2017-11-28 08:39:16','2017-11-28 08:39:16','','','','Backers List','0','','backers_list','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','99','','1','','0','0.131','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('62','2017-11-28 08:39:18','2017-11-28 08:39:18','','','','Captcha','0','','captcha','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','0','99','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('63','2017-11-28 08:39:18','2017-11-28 08:39:18','','','','Content','0','','content','Shows dynamic content','{SITE_URL}userfiles/modules/content/content.png','Microweber','','','','1','1','10','','0','','0','0.1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('64','2017-11-28 08:39:18','2017-11-28 08:39:18','','','','Online shop','0','','shop','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','0','2','','0','','0','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('65','2017-11-28 08:39:18','2017-11-28 08:39:18','','','','Shopping Cart','0','','shop/cart','','{SITE_URL}userfiles/modules/shop/cart/cart.png','Microweber','','','','1','1','14','','0','','0','0.24','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('66','2017-11-28 08:39:19','2017-11-28 08:39:19','','','','Payza payment','0','','shop/payments/gateways/payza','','{SITE_URL}userfiles/modules/shop/payments/gateways/payza/payza.png','Microweber','','','payment_gateway','1','0','159','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('67','2017-11-28 08:39:19','2017-11-28 08:39:19','','','','Przelewy24','0','','shop/payments/gateways/omnipay_przelewy24','','{SITE_URL}userfiles/modules/shop/payments/gateways/omnipay_przelewy24/omnipay_przelewy24.png','Microweber','','','payment_gateway','1','0','136','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('68','2017-11-28 08:39:19','2017-11-28 08:39:19','','','','Paypal Express','0','','shop/payments/gateways/paypal','','{SITE_URL}userfiles/modules/shop/payments/gateways/paypal/paypal.png','Microweber','','','payment_gateway','1','0','110','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('69','2017-11-28 08:39:19','2017-11-28 08:39:19','','','','Pay on delivery','0','','shop/payments/gateways/pay_on_delivery','','{SITE_URL}userfiles/modules/shop/payments/gateways/pay_on_delivery/pay_on_delivery.png','D.Velev (colocation.bg)','','','payment_gateway','1','0','130','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('70','2017-11-28 08:39:20','2017-11-28 08:39:20','','','','VoguePay payment','0','','shop/payments/gateways/voguepay','','{SITE_URL}userfiles/modules/shop/payments/gateways/voguepay/voguepay.png','Microweber','','','payment_gateway','1','0','139','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('71','2017-11-28 08:39:20','2017-11-28 08:39:20','','','','Paypal Pro','0','','shop/payments/gateways/paypal_pro','','{SITE_URL}userfiles/modules/shop/payments/gateways/paypal_pro/paypal_pro.png','Microweber','','','payment_gateway','1','0','111','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('72','2017-11-28 08:39:20','2017-11-28 08:39:20','','','','Authorize.Net','0','','shop/payments/gateways/omnipay_authorize_aim','','{SITE_URL}userfiles/modules/shop/payments/gateways/omnipay_authorize_aim/omnipay_authorize_aim.png','Microweber','','','payment_gateway','1','0','132','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('73','2017-11-28 08:39:20','2017-11-28 08:39:20','','','','Mollie payment','0','','shop/payments/gateways/omnipay_mollie','','{SITE_URL}userfiles/modules/shop/payments/gateways/omnipay_mollie/omnipay_mollie.png','Microweber','','','payment_gateway','1','0','136','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('74','2017-11-28 08:39:21','2017-11-28 08:39:21','','','','Stripe payment','0','','shop/payments/gateways/omnipay_stripe','','{SITE_URL}userfiles/modules/shop/payments/gateways/omnipay_stripe/omnipay_stripe.png','Microweber','','','payment_gateway','1','0','132','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('75','2017-11-28 08:39:21','2017-11-28 08:39:21','','','','Products','0','','shop/products','','{SITE_URL}userfiles/modules/shop/products/products.png','Microweber','','','','1','1','12','','0','','0','0.41','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('76','2017-11-28 08:39:21','2017-11-28 08:39:21','','','','Shipping to country','0','','shop/shipping/gateways/country','','{SITE_URL}userfiles/modules/default.png','Microweber','','','shipping_gateway','1','0','100','','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('77','2017-11-28 08:39:21','2017-11-28 08:39:21','','','','Add to cart','0','','shop/cart_add','','{SITE_URL}userfiles/modules/shop/cart_add/cart_add.png','Microweber','','','','1','1','14','','0','','0','0.26','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('78','2017-11-28 08:39:22','2017-11-28 08:39:22','','','','Checkout','0','','shop/checkout','','{SITE_URL}userfiles/modules/shop/checkout/checkout.png','Microweber','','','','1','1','13','','0','','0','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('79','2017-11-28 08:39:22','2017-11-28 08:39:22','','','','Discounts','0','','shop/discounts','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','14','','0','','0','0.24','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('80','2017-11-28 08:39:22','2017-11-28 08:39:22','','','','Comments','0','','comments','','{SITE_URL}userfiles/modules/comments/comments.png','Microweber','','','','1','1','10','','1','1','0','0.33','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('81','2017-11-28 08:39:23','2017-11-28 08:39:23','','','','Table Manager','0','','tablemanager','','{SITE_URL}userfiles/modules/default.png','Microweber','','','','1','1','99','','0','','0','1.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('82','2017-11-28 08:39:23','2017-11-28 08:39:23','','','','Parallax','0','','parallax','Free parallax module for your website!','{SITE_URL}userfiles/modules/parallax/parallax.png','Petko Yovchevski','','','','1','1','100','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('83','2017-11-28 08:39:23','2017-11-28 08:39:23','','','','Updates','0','','updates','','{SITE_URL}userfiles/modules/updates/updates.png','Microweber','','','','1','0','50','','1','','1','0.3','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('84','2017-11-28 08:39:23','2017-11-28 08:39:23','','','','Embed Code','0','','embed','','{SITE_URL}userfiles/modules/embed/embed.png','Microweber','','','','1','1','26','','0','','0','0.5','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('85','2017-11-28 08:39:24','2017-11-28 08:39:24','','','','Tags','0','','tags','Tags module for your posts!','{SITE_URL}userfiles/modules/default.png','','','','','1','1','100','','0','','0','0.01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */modules (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings) VALUES('86','2017-11-28 08:39:24','2017-11-28 08:39:24','','','','PDF','0','','pdf','','{SITE_URL}userfiles/modules/pdf/pdf.png','Microweber','','','','1','1','7','','0','','0','1','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */elements" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "expires_on" datetime null, "created_by" integer null, "edited_by" integer null, "name" text null, "parent_id" integer null, "module_id" text null, "module" text null, "description" text null, "icon" text null, "author" text null, "website" text null, "help" text null, "type" text null, "installed" integer null, "ui" integer null, "position" integer null, "as_element" integer null, "ui_admin" integer null, "ui_admin_iframe" integer null, "is_system" integer null, "version" varchar null, "notifications" integer null, "settings" text null, "layout_type" varchar null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('1','2017-11-28 13:44:54','2017-11-28 13:44:54','','1','1','4 Pictures','0','','4pics','4 pictures in 2 columns','{SITE_URL}userfiles/elements/4pics.png','Microweber','http://microweber.com','','','','0','10','1','0','','0','0.01','','','dynamic'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('2','2017-11-28 13:44:54','2017-11-28 13:44:54','','1','1','4 Pictures','0','','4pics_with_text','4 pictures in 2 columns','{SITE_URL}userfiles/elements/4pics_with_text.png','Microweber','http://microweber.com','','','','0','11','1','0','','0','0.2','','','dynamic'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('3','2017-11-28 13:44:54','2017-11-28 13:44:54','','1','1','Double - floated image with paragraph','0','','floatet_image_paragraph_2x','Two elements with floated image(on the left) and a paragraph (on the right)','{SITE_URL}userfiles/elements/floatet_image_paragraph_2x.png','Microweber','http://microweber.com','','','','0','12','1','0','','0','0.1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('4','2017-11-28 13:44:54','2017-11-28 13:44:54','','1','1','Image, text, categories and banners.','0','','header_imgcategories_text_multiple_baners','Header Image with categories text and banners.','{SITE_URL}userfiles/elements/header_imgcategories_text_multiple_baners.png','Microweber','http://microweber.com','','','','0','17','1','0','','0','0.7','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('5','2017-11-28 13:44:55','2017-11-28 13:44:55','','1','1','Image Categories Text','0','','image_cats_left_text','Widescreen image with categories on the bottom left and text.','{SITE_URL}userfiles/elements/image_cats_left_text.png','Microweber','http://microweber.com','','','','0','13','1','0','','0','0.5','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('6','2017-11-28 13:44:55','2017-11-28 13:44:55','','1','1','Image Categories Text','0','','image_cats_right_text','Widescreen image with categories on the bottom right and text on the bottom left side.','{SITE_URL}userfiles/elements/image_cats_right_text.png','Microweber','http://microweber.com','','','','0','14','1','0','','0','0.1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('7','2017-11-28 13:44:55','2017-11-28 13:44:55','','1','1','Header Image text, newsletter, banners and categories.','0','','image_text_subscribe_banners_cats_left','Header Image with text, newsletter, banners and categories.','{SITE_URL}userfiles/elements/image_text_subscribe_banners_cats_left.png','Microweber','http://microweber.com','','','','0','15','1','0','','0','0.2','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('8','2017-11-28 13:44:55','2017-11-28 13:44:55','','1','1','Header Image text, newsletter, banners and categories.','0','','image_text_subscribe_banners_cats_right','Header Image with text, newsletter, banners and categories.','{SITE_URL}userfiles/elements/image_text_subscribe_banners_cats_right.png','Microweber','http://microweber.com','','','','0','16','1','0','','0','0.1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('9','2017-11-28 13:44:56','2017-11-28 13:44:56','','1','1','Last articles','0','','last_articles','Last articles','{SITE_URL}userfiles/elements/last_articles.png','Microweber','http://microweber.com','','','','0','18','1','0','','0','1.4','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('10','2017-11-28 13:44:56','2017-11-28 13:44:56','','1','1','Text with picture','0','','text with picture/01_text_with_pic','Text with picture','{SITE_URL}userfiles/elements/text with picture/01_text_with_pic.png','Microweber','http://microweber.com','','','','0','4','1','0','','0','0.1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('11','2017-11-28 13:44:56','2017-11-28 13:44:56','','1','1','Two Columns with Pictures','0','','text with picture/02_text_2_column','2 columns with text and picture','{SITE_URL}userfiles/elements/text with picture/02_text_2_column.png','Microweber','http://microweber.com','','','','0','5','1','0','','0','0.1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('12','2017-11-28 13:44:56','2017-11-28 13:44:56','','1','1','Three Columns with Pictures','0','','text with picture/03_text_3_column','Text and pictures 3 column','{SITE_URL}userfiles/elements/text with picture/03_text_3_column.png','Microweber','http://microweber.com','','','','0','6','1','0','','0','0.2','','','dynamic'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('13','2017-11-28 13:44:57','2017-11-28 13:44:57','','1','1','Text with Picture','0','','text with picture/04_text_column','Text with wide picture on the top.','{SITE_URL}userfiles/elements/text with picture/04_text_column.png','Microweber','http://microweber.com','','','','0','7','1','0','','0','0.4','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('14','2017-11-28 13:44:57','2017-11-28 13:44:57','','1','1','Two Columns &amp; Picture','0','','text with picture/05_text_column','Text (2 columns) and wide picture','{SITE_URL}userfiles/elements/text with picture/05_text_column.png','Microweber','http://microweber.com','','','','0','8','1','0','','0','0.2','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('15','2017-11-28 13:44:57','2017-11-28 13:44:57','','1','1','Text (3 columns) and wide picture','0','','text with picture/06_text_column','Text (3 columns) and wide picture','{SITE_URL}userfiles/elements/text with picture/06_text_column.png','Microweber','http://microweber.com','','','','0','9','1','0','','0','0.02','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('16','2017-11-28 13:44:57','2017-11-28 13:44:57','','1','1','Simple Text','0','','text only/01_text_only','Text 1 column full width','{SITE_URL}userfiles/elements/text only/01_text_only.png','Microweber','http://microweber.com','','','','0','1','1','0','','0','0.41','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('17','2017-11-28 13:44:58','2017-11-28 13:44:58','','1','1','Text 2 columns','0','','text only/02_text_2_columns','Text 2 columns','{SITE_URL}userfiles/elements/text only/02_text_2_columns.png','Microweber','http://microweber.com','','','','0','2','1','0','','0','0.2','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */elements (id,updated_at,created_at,expires_on,created_by,edited_by,name,parent_id,module_id,module,description,icon,author,website,help,type,installed,ui,position,as_element,ui_admin,ui_admin_iframe,is_system,version,notifications,settings,layout_type) VALUES('18','2017-11-28 13:44:58','2017-11-28 13:44:58','','1','1','Three Columns','0','','text only/03_text_3_columns','Text 3 columns','{SITE_URL}userfiles/elements/text only/03_text_3_columns.png','Microweber','http://microweber.com','','','','0','3','1','0','','0','0.2','','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */module_templates" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "module_id" text null, "name" text null, "module" text null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */system_licenses" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "rel_type" text null, "rel_id" text null, "local_key" text null, "local_key_hash" text null, "registered_name" text null, "company_name" text null, "domains" text null, "status" text null, "product_id" integer null, "service_id" integer null, "billing_cycle" text null, "reg_on" datetime null, "due_on" datetime null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */users" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "expires_on" datetime null, "last_login" datetime null, "last_login_ip" varchar null, "created_by" integer null, "edited_by" integer null, "username" varchar null, "password" varchar null, "email" varchar null, "remember_token" varchar null, "is_active" integer null, "is_admin" integer null, "is_verified" integer null, "is_public" integer null, "basic_mode" varchar null, "first_name" varchar null, "middle_name" varchar null, "last_name" varchar null, "thumbnail" varchar null, "parent_id" integer null, "api_key" varchar null, "user_information" text null, "subscr_id" varchar null, "role" varchar null, "medium" varchar null, "oauth_uid" varchar null, "oauth_provider" varchar null, "oauth_token" text null, "oauth_token_secret" text null, "profile_url" varchar null, "website_url" varchar null, "password_reset_hash" varchar null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */users (id,updated_at,created_at,expires_on,last_login,last_login_ip,created_by,edited_by,username,password,email,remember_token,is_active,is_admin,is_verified,is_public,basic_mode,first_name,middle_name,last_name,thumbnail,parent_id,api_key,user_information,subscr_id,role,medium,oauth_uid,oauth_provider,oauth_token,oauth_token_secret,profile_url,website_url,password_reset_hash) VALUES('1','2017-12-14 12:15:18','2017-11-28 08:39:30','','2017-11-28 08:39:30','94.26.57.98','','1','admin','$2y$10$tHdLMEqyKR7.2GMBoeQzoOLQFXKJjHz./JNCC9ybQRFakpIJEKZvS','demo@microweber.com','','1','1','','','0','Admin','','Istrator','','','','','','','','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */users (id,updated_at,created_at,expires_on,last_login,last_login_ip,created_by,edited_by,username,password,email,remember_token,is_active,is_admin,is_verified,is_public,basic_mode,first_name,middle_name,last_name,thumbnail,parent_id,api_key,user_information,subscr_id,role,medium,oauth_uid,oauth_provider,oauth_token,oauth_token_secret,profile_url,website_url,password_reset_hash) VALUES('2','2017-12-14 16:54:38','2017-12-14 12:15:30','','','','','','peter','$2y$10$LoxNGVJtG0UZwXID02NABOQzn27iNoEAhS9/oua.AX5ScLdnhskCe','','','1','1','','','0','','','','','','','','','','','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */users (id,updated_at,created_at,expires_on,last_login,last_login_ip,created_by,edited_by,username,password,email,remember_token,is_active,is_admin,is_verified,is_public,basic_mode,first_name,middle_name,last_name,thumbnail,parent_id,api_key,user_information,subscr_id,role,medium,oauth_uid,oauth_provider,oauth_token,oauth_token_secret,profile_url,website_url,password_reset_hash) VALUES('3','2017-12-14 16:54:27','2017-12-14 16:54:27','','','','','','boris','$2y$10$MlgiPyEhHZwgSPemwvaz/./bQ6Dvn6mbqcqgHpKEin9HRBf5LI69K','sokolov.boris@gmail.com','','1','1','','','0','Boris','','Sokolov','','','','','','','','','','','','','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */users_oauth" ("id" integer not null primary key autoincrement, "user_id" integer null, "provider" varchar null, "data_id" varchar null, "data_name" varchar null, "data_email" varchar null, "data_token" varchar null, "data_avatar" varchar null, "data_raw" varchar null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */log" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "rel_type" text null, "rel_id" text null, "position" integer null, "field" text null, "value" text null, "module" text null, "data_type" text null, "title" text null, "description" text null, "content" text null, "user_ip" text null, "session_id" text null, "is_system" varchar null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('82','2017-12-14 12:12:30','2017-12-14 12:12:30','','','login_failed','','','','','','','User IP 94.26.57.98 is blocked for 1 minute for 5 failed logins.','','Last login url was {SITE_URL}api/user_login','94.26.57.98','Rkna6PvvOP4k00NZvih3nLtM3CS3VCxhV1rmV6AD','n'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('109','2017-12-15 11:36:11','2017-12-15 11:36:11','','','login_failed','','','','','','','Failed login','','','94.26.57.98','gfucoyj3BcXutYBQeQFJhnvjHA9E2fdIwgOBx1J9','y'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('110','2017-12-15 11:36:13','2017-12-15 11:36:13','','','login_failed','','','','','','','Failed login','','','94.26.57.98','gfucoyj3BcXutYBQeQFJhnvjHA9E2fdIwgOBx1J9','y'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('111','2017-12-15 11:36:23','2017-12-15 11:36:23','','','login_failed','','','','','','','Failed login','','','94.26.57.98','gfucoyj3BcXutYBQeQFJhnvjHA9E2fdIwgOBx1J9','y'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('112','2017-12-15 12:05:30','2017-12-15 12:05:30','2','2','cart_orders','1','','','','shop','','You have new order','New order is placed from {SITE_URL}checkout?step=2','New order in the online shop. Order id: 1','94.26.57.98','VyL9Ls2wBvdWCTOPiyMxy6GX2q0BIEBJRdVyWT5y',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('113','2017-12-15 12:12:04','2017-12-15 12:12:04','1','1','cart_orders','2','','','','shop','','You have new order','New order is placed from {SITE_URL}checkout?step=2','New order in the online shop. Order id: 2','94.26.57.98','Bo45kHkVP4s3fGaeD6FtVrG4VyINt79GVvjD4GlA',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('114','2017-12-18 10:13:40','2017-12-18 10:13:40','','','login_failed','','','','','','','Failed login','','','94.26.57.98','7LQLii4C4BDyyeCaVo3ogBhlkLfn3F7rcZKgvcJK','y'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('115','2017-12-18 10:13:44','2017-12-18 10:13:44','','','login_failed','','','','','','','Failed login','','','94.26.57.98','7LQLii4C4BDyyeCaVo3ogBhlkLfn3F7rcZKgvcJK','y'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('116','2017-12-18 10:13:50','2017-12-18 10:13:50','','','login_failed','','','','','','','Failed login','','','94.26.57.98','7LQLii4C4BDyyeCaVo3ogBhlkLfn3F7rcZKgvcJK','y'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */log (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,position,field,value,module,data_type,title,description,content,user_ip,session_id,is_system) VALUES('117','2017-12-18 10:13:53','2017-12-18 10:13:53','','','login_failed','','','','','','','Failed login','','','94.26.57.98','7LQLii4C4BDyyeCaVo3ogBhlkLfn3F7rcZKgvcJK','y'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */notifications" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "rel_id" varchar null, "rel_type" varchar null, "notif_count" integer null, "is_read" integer null, "module" text null, "title" text null, "description" text null, "content" text null, "notification_data" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications (id,updated_at,created_at,created_by,edited_by,rel_id,rel_type,notif_count,is_read,module,title,description,content,notification_data) VALUES('1','2017-12-14 11:49:39','2017-12-14 11:49:39','1','1','0','forms_lists','','0','contact_form','New form entry','You have new form entry','You have new form entry from {SITE_URL}contacts-2First Name: SDVSDCVSEmail: SDCSDCSD@DSDS.COMPhone: SDCSDCSDCIp: 94.26.57.98Message: SDCSDCSD',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications (id,updated_at,created_at,created_by,edited_by,rel_id,rel_type,notif_count,is_read,module,title,description,content,notification_data) VALUES('2','2017-12-15 12:07:48','2017-12-15 12:05:30','2','2','1','cart_orders','','1','shop','You have new order','New order is placed from {SITE_URL}checkout?step=2','New order in the online shop. Order id: 1',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications (id,updated_at,created_at,created_by,edited_by,rel_id,rel_type,notif_count,is_read,module,title,description,content,notification_data) VALUES('3','2017-12-15 12:13:26','2017-12-15 12:12:04','1','2','2','cart_orders','','1','shop','You have new order','New order is placed from {SITE_URL}checkout?step=2','New order in the online shop. Order id: 2',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */comments" ("id" integer not null primary key autoincrement, "rel_type" varchar null, "rel_id" varchar null, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "comment_name" varchar null, "comment_body" text null, "comment_email" varchar null, "comment_website" varchar null, "is_moderated" integer null, "from_url" varchar null, "comment_subject" varchar null, "is_new" integer null, "send_email" integer null, "session_id" varchar null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */content" ("id" integer not null primary key autoincrement, "content_type" varchar null, "subtype" varchar null, "url" text null, "title" text null, "parent" integer null, "description" text null, "position" integer null, "content" text null, "content_body" text null, "is_active" integer null default '1', "subtype_value" varchar null, "custom_type" varchar null, "custom_type_value" varchar null, "active_site_template" varchar null, "layout_file" varchar null, "layout_name" varchar null, "layout_style" varchar null, "content_filename" varchar null, "original_link" varchar null, "is_home" integer null default '0', "is_pinged" integer null default '0', "is_shop" integer null default '0', "is_deleted" integer null default '0', "require_login" integer null default '0', "status" varchar null, "content_meta_title" text null, "content_meta_keywords" text null, "session_id" varchar null, "updated_at" datetime null, "created_at" datetime null, "expires_at" datetime null, "created_by" integer null, "edited_by" integer null, "posted_at" datetime null, "draft_of" integer null, "copy_of" integer null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('1','page','static','home','Home','0','','1','','','1','','','','default','index.php','','','','','1','0','0','0','0','','','','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','2017-12-14 16:38:21','2017-11-28 08:39:25','','','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('2','page','static','home-2','Home 2','0','','0','','','1','','','','default','layouts__index-2.php','','','','','0','0','0','0','0','','','','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','2017-11-28 14:35:14','2017-11-28 14:35:13','','1','1','2017-11-28 14:35:13','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('3','page','static','home-3','Home 3','0','','-1','','','1','','','','default','layouts__index-3.php','','','','','0','0','0','0','0','','','','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','2017-11-28 14:35:44','2017-11-28 14:35:43','','1','1','2017-11-28 14:35:43','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('4','page','static','home-4','Home 4','0','','-2','','','1','','','','default','layouts__index-4.php','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:56:29','2017-11-28 14:36:01','','1','1','2017-11-28 14:36:01','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('5','page','dynamic','blog','Blog','0','','-3','','','1','','','','default','layouts__blog.php','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:42:02','2017-12-01 09:30:47','','1','1','2017-12-01 11:40:13','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('6','page','dynamic','blog-2','Blog 2','0','','-4','','','1','','','','default','layouts__blog-2.php','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:41:42','2017-12-01 09:31:39','','1','1','2017-12-01 11:41:05','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('7','page','dynamic','blog-3','Blog 3','0','','-5','','','1','','','','default','layouts__blog-3.php','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:43:17','2017-12-01 09:32:08','','1','1','2017-12-01 09:32:08','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('8','page','dynamic','shop','Shop','0','','-6','','','1','','','','default','layouts__shop.php','','','','','0','0','1','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:57:41','2017-12-01 09:32:57','','1','1','2017-12-01 12:57:35','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('9','page','dynamic','shop-2','Shop 2','0','','-7','','','1','','','','default','layouts__shop-2.php','','','','','0','0','1','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 13:00:04','2017-12-01 09:33:10','','1','1','2017-12-01 12:59:57','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('10','page','dynamic','shop-3','Shop 3','0','','-8','','','1','','','','default','layouts__shop-3.php','','','','','0','0','1','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:58:49','2017-12-01 09:33:21','','1','1','2017-12-01 12:58:43','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('11','page','dynamic','shop-4','Shop 4','0','','-9','','','1','','','','default','layouts__shop-4.php','','','','','0','0','1','0','0','','','','Bo45kHkVP4s3fGaeD6FtVrG4VyINt79GVvjD4GlA','2017-12-15 11:57:02','2017-12-01 09:33:32','','1','1','2017-12-01 09:33:32','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('12','page','static','services','Services','0','','-10','','','1','','','','default','layouts__services-cards.php','','','','','0','0','0','0','0','','','','2fsvpbTraoW3B85VpvOciSlDc32t2j9ELwkgPStS','2017-12-13 14:58:16','2017-12-01 09:34:07','','1','1','2017-12-01 09:34:07','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('13','page','static','services-2','Services 2','0','','-11','','','1','','','','default','layouts__services-boxes.php','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:46:01','2017-12-01 09:34:19','','1','1','2017-12-01 09:34:19','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('14','page','static','about','About','0','','-12','','','1','','','','default','layouts__about.php','','','','','0','0','0','0','0','','','','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','2017-12-14 11:41:14','2017-12-01 09:34:38','','1','1','2017-12-01 09:34:38','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('15','page','static','portfolio','Portfolio','0','','-13','','','1','','','','default','layouts__portfolio.php','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:48:09','2017-12-01 09:35:36','','1','1','2017-12-01 09:35:36','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('16','page','static','text-page','Text Page','0','','-14','','','1','','','','default','layouts__text-page.php','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:48:40','2017-12-01 09:36:04','','1','1','2017-12-01 09:36:04','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('17','page','static','contacts','Contacts','0','','-15','','','1','','','','default','layouts__contacts-simple.php','','','','','0','0','0','0','0','','','','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','2017-12-14 11:47:11','2017-12-01 09:36:44','','1','1','2017-12-01 09:36:44','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('18','page','static','contacts-2','Contacts 2','0','','-16','','','1','','','','default','layouts__contacts.php','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 09:36:56','2017-12-01 09:36:55','','1','1','2017-12-01 09:36:55','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('19','post','post','doing-more-with-less-a-guide-to-downsized-living','Doing more with less: A guide to downsized living','5','','2','
                            <div class="element">
                                <p align="justify" class="element element-over" id="element_1512127253081"><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&rsquo;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  <br></p>
                            </div>
                        ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:37:12','2017-12-01 11:21:44','','1','1','2017-12-01 11:21:44','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('20','post','post','opinion-mobile-camera-apps-have-reached-saturation-point','Opinion: Mobile camera apps have reached saturation point','6','','3','
                            <div class="element">
                                <p align="justify" class="element element-over" id="element_1512128086907">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it
                                    anywhere on
                                    the
                                    site. Get creative, Make Web.</p>
                            </div>
                        ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:35:34','2017-12-01 11:35:24','','1','1','2017-12-01 11:35:24','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('21','post','post','opinion-mobile-camera-apps-have-reached-saturation-point-1','Opinion: Mobile camera apps have reached saturation point copy','6','','1','
                            <div class="element">
                                <p align="justify" class="element element-over" id="element_1512128086907">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it
                                    anywhere on
                                    the
                                    site. Get creative, Make Web.</p>
                            </div>
                        ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:39:30','2017-12-01 11:35:24','','1','1','2017-12-01 11:35:34','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('22','post','post','doing-more-with-less-a-guide-to-downsized-living-1','Doing more with less: A guide to downsized living copy','5','','0','
                            <div class="element">
                                <p align="justify" class="element element-over" id="element_1512127253081"><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&rsquo;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  <br></p>
                            </div>
                        ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:40:13','2017-12-01 11:21:44','','1','1','2017-12-01 11:37:12','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('23','post','post','opinion-mobile-camera-apps-have-reached-saturation-point-1-1','Opinion: Mobile camera apps have reached saturation point copy copy','6','','-1','
                            <div class="element">
                                <p align="justify" class="element element-over" id="element_1512128086907">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it
                                    anywhere on
                                    the
                                    site. Get creative, Make Web.</p>
                            </div>
                        ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 11:41:05','2017-12-01 11:35:24','','1','1','2017-12-01 11:37:57','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('24','product','product','francis-felt-hat','Francis Felt Hat','8','','4','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:51:12','2017-12-01 12:51:07','','1','1','2017-12-01 12:51:07','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('25','product','product','hunter-formal-shirt','Hunter Formal Shirt','9','','5','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:52:31','2017-12-01 12:52:25','','1','1','2017-12-01 12:52:25','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('26','product','product','dennis-glasses','Dennis Glasses','10','','6','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:53:28','2017-12-01 12:52:59','','1','1','2017-12-01 12:52:59','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('27','product','product','bruce-leather-shoes','Bruce Leather Shoes','9','','7','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:54:58','2017-12-01 12:54:15','','1','1','2017-12-01 12:54:15','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('28','product','product','bonnie-denim-tote','Bonnie Denim Tote','9','','8','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:56:12','2017-12-01 12:56:00','','1','1','2017-12-01 12:56:00','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('29','product','product','dave-wool-beanie','Dave Wool Beanie','8','','9','','
                            <p class="element element-over" id="element_1512133040928">
                                A sturdy, handwoven fabric makes this American Apparel indigo-T a dependable addition to your casual wardrobe. This is a no bullshit plain ol’ t-shirt.
                            </p>
                        ','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:57:43','2017-12-01 12:57:35','','1','1','2017-12-01 12:57:35','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('30','product','product','dave-wool-beanie-1','Dave Wool Beanie','10','','10','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 12:58:48','2017-12-01 12:58:43','','1','1','2017-12-01 12:58:43','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('31','product','product','charles-leather-bag','Charles Leather Bag','9','','11','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','2017-12-01 13:00:04','2017-12-01 12:59:57','','1','1','2017-12-01 12:59:57','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('32','page','dynamic','shop4-1','Shop4-1','0','','-17','','','1','','','','default','layouts__shop-4.php','','','','','0','0','1','0','0','','','','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','2017-12-14 15:24:43','2017-12-14 14:58:44','','1','1','2017-12-14 14:58:44','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */content_data" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "content_id" varchar null, "field_name" text null, "field_value" text null, "session_id" varchar null, "rel_type" varchar null, "rel_id" varchar null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('1','2017-12-01 12:51:10','2017-12-01 12:51:10','1','1','24','qty','nolimit','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('2','2017-12-01 12:51:10','2017-12-01 12:51:10','1','1','24','sku','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('3','2017-12-01 12:51:10','2017-12-01 12:51:10','1','1','24','shipping_weight','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('4','2017-12-01 12:51:11','2017-12-01 12:51:11','1','1','24','shipping_width','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('5','2017-12-01 12:51:11','2017-12-01 12:51:11','1','1','24','shipping_height','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('6','2017-12-01 12:51:11','2017-12-01 12:51:11','1','1','24','shipping_depth','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('7','2017-12-01 12:51:12','2017-12-01 12:51:12','1','1','24','additional_shipping_cost','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('8','2017-12-01 12:51:12','2017-12-01 12:51:12','1','1','24','max_qty_per_order','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('9','2017-12-01 12:52:28','2017-12-01 12:52:28','1','1','25','qty','nolimit','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('10','2017-12-01 12:52:29','2017-12-01 12:52:29','1','1','25','sku','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('11','2017-12-01 12:52:29','2017-12-01 12:52:29','1','1','25','shipping_weight','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('12','2017-12-01 12:52:29','2017-12-01 12:52:29','1','1','25','shipping_width','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('13','2017-12-01 12:52:30','2017-12-01 12:52:30','1','1','25','shipping_height','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('14','2017-12-01 12:52:30','2017-12-01 12:52:30','1','1','25','shipping_depth','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('15','2017-12-01 12:52:30','2017-12-01 12:52:30','1','1','25','additional_shipping_cost','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('16','2017-12-01 12:52:31','2017-12-01 12:52:31','1','1','25','max_qty_per_order','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('17','2017-12-01 12:53:26','2017-12-01 12:53:03','1','1','26','qty','nolimit','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('18','2017-12-01 12:53:26','2017-12-01 12:53:03','1','1','26','sku','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('19','2017-12-01 12:53:27','2017-12-01 12:53:03','1','1','26','shipping_weight','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('20','2017-12-01 12:53:27','2017-12-01 12:53:04','1','1','26','shipping_width','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('21','2017-12-01 12:53:27','2017-12-01 12:53:04','1','1','26','shipping_height','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('22','2017-12-01 12:53:27','2017-12-01 12:53:04','1','1','26','shipping_depth','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('23','2017-12-01 12:53:28','2017-12-01 12:53:05','1','1','26','additional_shipping_cost','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('24','2017-12-01 12:53:28','2017-12-01 12:53:05','1','1','26','max_qty_per_order','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('25','2017-12-01 12:54:46','2017-12-01 12:54:18','1','1','27','qty','nolimit','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('26','2017-12-01 12:54:47','2017-12-01 12:54:18','1','1','27','sku','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('27','2017-12-01 12:54:47','2017-12-01 12:54:19','1','1','27','shipping_weight','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('28','2017-12-01 12:54:47','2017-12-01 12:54:19','1','1','27','shipping_width','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('29','2017-12-01 12:54:47','2017-12-01 12:54:19','1','1','27','shipping_height','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('30','2017-12-01 12:54:48','2017-12-01 12:54:20','1','1','27','shipping_depth','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('31','2017-12-01 12:54:56','2017-12-01 12:54:20','1','1','27','additional_shipping_cost','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('32','2017-12-01 12:54:57','2017-12-01 12:54:20','1','1','27','max_qty_per_order','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('33','2017-12-01 12:56:04','2017-12-01 12:56:04','1','1','28','qty','nolimit','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('34','2017-12-01 12:56:04','2017-12-01 12:56:04','1','1','28','sku','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('35','2017-12-01 12:56:04','2017-12-01 12:56:04','1','1','28','shipping_weight','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('36','2017-12-01 12:56:05','2017-12-01 12:56:05','1','1','28','shipping_width','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('37','2017-12-01 12:56:05','2017-12-01 12:56:05','1','1','28','shipping_height','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('38','2017-12-01 12:56:05','2017-12-01 12:56:05','1','1','28','shipping_depth','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('39','2017-12-01 12:56:11','2017-12-01 12:56:11','1','1','28','additional_shipping_cost','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('40','2017-12-01 12:56:12','2017-12-01 12:56:12','1','1','28','max_qty_per_order','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('41','2017-12-01 12:57:38','2017-12-01 12:57:38','1','1','29','qty','nolimit','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('42','2017-12-01 12:57:39','2017-12-01 12:57:39','1','1','29','sku','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('43','2017-12-01 12:57:39','2017-12-01 12:57:39','1','1','29','shipping_weight','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('44','2017-12-01 12:57:39','2017-12-01 12:57:39','1','1','29','shipping_width','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('45','2017-12-01 12:57:40','2017-12-01 12:57:40','1','1','29','shipping_height','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('46','2017-12-01 12:57:40','2017-12-01 12:57:40','1','1','29','shipping_depth','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('47','2017-12-01 12:57:40','2017-12-01 12:57:40','1','1','29','additional_shipping_cost','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('48','2017-12-01 12:57:41','2017-12-01 12:57:41','1','1','29','max_qty_per_order','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('49','2017-12-01 12:58:46','2017-12-01 12:58:46','1','1','30','qty','nolimit','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('50','2017-12-01 12:58:46','2017-12-01 12:58:46','1','1','30','sku','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('51','2017-12-01 12:58:46','2017-12-01 12:58:46','1','1','30','shipping_weight','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('52','2017-12-01 12:58:47','2017-12-01 12:58:47','1','1','30','shipping_width','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('53','2017-12-01 12:58:47','2017-12-01 12:58:47','1','1','30','shipping_height','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('54','2017-12-01 12:58:47','2017-12-01 12:58:47','1','1','30','shipping_depth','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('55','2017-12-01 12:58:48','2017-12-01 12:58:48','1','1','30','additional_shipping_cost','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('56','2017-12-01 12:58:48','2017-12-01 12:58:48','1','1','30','max_qty_per_order','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('57','2017-12-01 13:00:01','2017-12-01 13:00:01','1','1','31','qty','nolimit','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('58','2017-12-01 13:00:01','2017-12-01 13:00:01','1','1','31','sku','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('59','2017-12-01 13:00:02','2017-12-01 13:00:02','1','1','31','shipping_weight','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('60','2017-12-01 13:00:02','2017-12-01 13:00:02','1','1','31','shipping_width','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('61','2017-12-01 13:00:03','2017-12-01 13:00:03','1','1','31','shipping_height','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('62','2017-12-01 13:00:03','2017-12-01 13:00:03','1','1','31','shipping_depth','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('63','2017-12-01 13:00:04','2017-12-01 13:00:04','1','1','31','additional_shipping_cost','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('64','2017-12-01 13:00:04','2017-12-01 13:00:04','1','1','31','max_qty_per_order','','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','31'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */attributes" ("id" integer not null primary key autoincrement, "attribute_name" text null, "attribute_value" text null, "rel_type" varchar null, "rel_id" varchar null, "attribute_type" varchar null, "session_id" varchar null, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */content_fields" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "rel_type" varchar null, "rel_id" varchar null, "field" text null, "value" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('4','2017-12-01 11:41:43','2017-12-01 11:41:43','1','1','module','6','layout-skin-68-module-layouts-6','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128483029">Blog Simple</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('5','2017-12-01 11:42:02','2017-12-01 11:42:02','1','1','content','5','dream_content','

        <module class="module module-layouts module-over" id="module-layouts-5" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-5"></module>
<section class=" element"><div class="container">
                <div class="row">
                    <div class="col-md-8" style="height: auto;">
                        <module class=" module module-posts " data-mw-title="Posts List" data-type="posts" template="skin-2" id="blog-posts-5" parent-module="posts" parent-module-id="blog-posts-5"></module>
</div>
                    <div class="col-md-3 col-md-offset-1 hidden-sm hidden-xs" style="height: auto;">
                        <div class="edit" field="dream_blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>
                    </div>
                </div>
            </div>
        </section>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('6','2017-12-01 11:42:03','2017-12-01 11:42:03','1','1','module','5','layout-skin-68-module-layouts-5','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512127958881">Blog Sidebar</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>


'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('7','2017-12-01 11:43:16','2017-12-01 11:43:16','1','1','content','7','dream_content','
        <module class="module module-layouts module-over" id="module-layouts-7" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7"></module>
<module class="module module-posts" data-mw-title="Posts List" data-type="posts" template="skin-4" id="blog-3-posts-7" parent-module="posts" parent-module-id="blog-3-posts-7"></module>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('8','2017-12-01 11:43:17','2017-12-01 11:43:17','1','1','module','7','layout-skin-68-module-layouts-7','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128555606">Blog Cards</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('9','2017-12-01 11:44:27','2017-12-01 11:44:27','1','1','content','8','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-8" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-8"></module>
<section class="masonry-contained element" id="element_1512128656367"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class=" module module-categories " id="module-categories-8" data-mw-title="Categories" content-id="8" data-type="categories" parent-module="categories" parent-module-id="module-categories-8"></module>
<module class=" module module-shop-products " id="module-shop-products-8" data-mw-title="Products" limit="18" description-length="70" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-8"></module>
</div>
            </div>
        </div>
    </section>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('10','2017-12-01 11:44:28','2017-12-01 11:44:28','1','1','module','8','layout-skin-68-module-layouts-8','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128656517">Shop 1</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('11','2017-12-01 11:44:42','2017-12-01 11:44:42','1','1','content','9','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-9" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-9"></module>
<section class="masonry-contained element" id="element_1512128674249"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class=" module module-categories " id="module-categories-9" data-mw-title="Categories" content-id="9" data-type="categories" parent-module="categories" parent-module-id="module-categories-9"></module>
<module class=" module module-shop-products " id="module-shop-products-9" data-mw-title="Products" limit="18" description-length="70" template="skin-1" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-9"></module>
</div>
            </div>
        </div>
    </section>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('12','2017-12-01 11:44:43','2017-12-01 11:44:43','1','1','module','9','layout-skin-68-module-layouts-9','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128674023">Shop 2</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('13','2017-12-01 11:44:59','2017-12-01 11:44:59','1','1','content','10','dream_content','
    <module class="module module-layouts" id="module-layouts-10" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-10"></module>
<section class="masonry-contained element element-over" id="element_1512128689313"><div class="container">
            <div class="row">
                <div class="col-md-9" style="height: auto;">
                    <div class="masonry-shop element">
                        <module class=" module module-shop-products " id="module-shop-products-10" data-mw-title="Products" limit="18" description-length="70" template="skin-2" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-10"></module>
</div>
                </div>

                <div class="col-md-3 hidden-sm hidden-xs" style="height: auto;">
                    <div class="edit" field="blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>


                </div>
            </div>
        </div>
    </section>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('14','2017-12-01 11:45:00','2017-12-01 11:45:00','1','1','module','10','layout-skin-68-module-layouts-10','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128688938">Shop 3</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('16','2017-12-01 11:45:17','2017-12-01 11:45:17','1','1','module','11','layout-skin-42-module-layouts-11','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero4.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1>Shop 4</h1>
                <p class="lead">Showcase a gallery of images with lightbox capability</p>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('19','2017-12-01 11:46:01','2017-12-01 11:46:01','1','1','content','13','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-13" data-mw-title="Layouts" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13"></module>
<module class="module module-layouts" id="module-layouts-13--1" data-mw-title="Layouts" template="skin-53" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--1"></module>
<module class="module module-layouts" id="module-layouts-13--2" data-mw-title="Layouts" template="skin-54" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--2"></module>
<module class=" module module-layouts " id="module-layouts-13--3" data-mw-title="Layouts" template="skin-53" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--3"></module>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('20','2017-12-01 11:46:01','2017-12-01 11:46:01','1','1','module','13','layout-skin-41-module-layouts-13','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Services Boxes</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>

'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('25','2017-12-01 11:48:09','2017-12-01 11:48:09','1','1','content','15','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-15" data-mw-title="Layouts" template="skin-57" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-15"></module>
<module class=" module module-layouts " id="module-layouts-15--1" data-mw-title="Layouts" template="skin-56" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-15--1"></module>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('26','2017-12-01 11:48:10','2017-12-01 11:48:10','1','1','module','15','layout-skin-57-module-layouts-15','
    <section class="height-70 safe-mode bg--dark imagebg page-title page-title--animate parallax" data-overlay="4"><div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); transform: translate3d(0px, 0px, 0px); background-position: initial; opacity: 1; top: 0px;"></div>

        <div class="container pos-vertical-center">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                    <h1>Portfolio</h1>
                </div>
            </div>
        </div>
    </section><section class="masonry-contained section--overlap"><div class="container">
            <div class="row">
                <div class="masonry box-shadow-wide">
                    <div class="masonry__filters masonry__filters--outside text-center" data-filter-all-text="Show All"><ul>
<li class="active" data-masonry-filter="*">Show All</li>
<li data-masonry-filter="branding">branding</li>
<li data-masonry-filter="digital">digital</li>
<li data-masonry-filter="packaging">packaging</li>
</ul></div>
                    <div class="masonry__container masonry--gapless masonry--animate masonry--active" style="position: relative; height: 1316.25px;">
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 0px; top: 0px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work6.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Freehance</h5>
                                            <span>
                                                        <em>iOS Application</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-branding" data-masonry-filter="branding" style="position: absolute; left: 585px; top: 0px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work2.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Michael Andrews</h5>
                                            <span>
                                                        <em>Branding &amp; Identity</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-packaging" data-masonry-filter="packaging" style="position: absolute; left: 0px; top: 438px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work5.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Authentic Apparel</h5>
                                            <span>
                                                        <em>Packaging Design</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-branding" data-masonry-filter="branding" style="position: absolute; left: 585px; top: 438px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work10.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Wave Poster</h5>
                                            <span>
                                                        <em>Logo Design</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 0px; top: 877px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work12.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Tesla Controller</h5>
                                            <span>
                                                        <em>Apple Watch Application</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 585px; top: 877px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work14.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Pillar</h5>
                                            <span>
                                                        <em>Website &amp; Digital</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('28','2017-12-01 11:48:40','2017-12-01 11:48:40','1','1','module','16','layout-skin-2-module-layouts-16','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center  allow-drop" style="height: auto;">
                <h2 class="element allow-drop" id="element_1512128900792">Clean Page</h2>
                <div class="element" id="element_1512128900911"><span class="safe-element"><em>Just a Text Page</em></span></div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('30','2017-12-01 11:56:30','2017-12-01 11:56:30','1','1','module','4','layout-skin-23-module-layouts-4','
<div class="col-md-6 col-sm-5">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero6.jpg&rsquo;); background-position: initial; opacity: 1;" id="element_1512129358480"></div>
    </div>
    <div class="col-md-6 col-sm-7 bg--white text-center">
        <div class="pos-vertical-center allow-drop">
            <img class="logo" alt="Dream" src="{SITE_URL}userfiles/templates/dream/assets/img/logo-large-dark.png"><p class="lead"><br>A beautiful collection of
                <br> hand-crafted web components
            </p>

            <module class=" module module-btn " id="module-layouts-4-btn" data-mw-title="Button" template="default" text="Purchase Dream" data-type="btn" parent-module-id="module-layouts-4" parent-module="layouts"></module>
</div>

        <div class="col-sm-12 text-center pos-absolute pos-bottom">
            <module class=" module module-social-links " id="module-layouts-4-social-links" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-4" parent-module="layouts"></module>
</div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('31','2017-12-01 12:57:43','2017-12-01 12:57:43','1','1','content','29','content_body','
                            <p class="element element-over" id="element_1512133040928">
                                A sturdy, handwoven fabric makes this American Apparel indigo-T a dependable addition to your casual wardrobe. This is a no bullshit plain ol’ t-shirt.
                            </p>
                        '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('32','2017-12-13 14:58:16','2017-12-13 14:58:16','1','1','content','12','dream_content',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('35','2017-12-14 11:40:22','2017-12-14 11:40:22','1','1','module','14','layout-skin-40-module-layouts-14','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/hero10.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h1>About Us</h1>
            </div>
        </div>

    </div>


'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('36','2017-12-14 11:41:14','2017-12-14 11:41:14','1','1','content','14','dream_content','
    
    <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-14" template="skin-40" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--1" template="skin-17" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--1"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--2" template="skin-18" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--2"></module>
<module class="module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-14--3" template="skin-19" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--3"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--4" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--4"></module>

'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('37','2017-12-14 11:41:15','2017-12-14 11:41:15','1','1','module','14','layout-skin-20-module-layouts-14--4','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/hero8.jpg&rsquo;); transform: translate3d(0px, 1300px, 0px); background-position: initial; opacity: 1; top: 0px;"></div>

    <div class="container">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h4>What can Dream do for your business?</h4>
                <module class="module module-btn" id="module-layouts-14--4-btn--1" data-mw-title="Button" text="Arrange A Consultation" data-type="btn" parent-module-id="module-layouts-14--4" parent-module="layouts"></module>
</div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('38','2017-12-14 11:41:43','2017-12-14 11:41:43','1','1','global','0','dream_footer','
            <div class="row">
                <div class="col-md-3 col-sm-4 allow-drop" style="height: auto;">
                    <module class="module module-logo" data-mw-title="Logo" id="footer-logo" template="footer" data-type="logo" parent-module="logo" parent-module-id="footer-logo"></module><p class="element" id="element_1513251682706"><em>Microweber CMS &amp; Website Builder</em></p>
                    <module class="module module-menu" data-mw-title="Menu" template="footer" name="footer_menu" id="footer_menu" data-type="menu" parent-module="menu" parent-module-id="footer_menu"></module>
</div>

                <div class="col-md-4 col-sm-8 allow-drop" style="height: auto;">
                    <h6 class=" element">Recent News</h6>
                    <module class=" module module-posts " data-mw-title="Posts List" template="skin-5" id="recent-news-14" limit="3" hide-paging="true" data-type="posts" parent-module="posts" parent-module-id="recent-news-14"></module>
</div>

                <div class="col-md-4 col-md-offset-1 col-sm-12 allow-drop" style="height: auto;">
                    <h6 class=" element">Subscribe</h6>
                    <p class=" element">Get monthly updates and free resources.</p>

                    <module class=" module module-newsletter " data-mw-title="Newsletter" id="footer-newsletter" data-type="newsletter" parent-module="newsletter" parent-module-id="footer-newsletter"></module><h6 class=" element">Connect with Us</h6>
                    <module class=" module module-social-links " data-mw-title="Social Links" id="socials" data-type="social_links" parent-module="social_links" parent-module-id="socials"></module>
</div>
            </div>
        '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('39','2017-12-14 11:47:11','2017-12-14 11:47:11','1','1','content','17','dream_content','
            <module class="module module-layouts module-over" id="module-layouts-17" data-mw-title="Layouts" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17"></module>
<module class=" module module-layouts " id="module-layouts-17--1" data-mw-title="Layouts" template="skin-50" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--1"></module>
<module class=" module module-layouts " id="module-layouts-17--2" data-mw-title="Layouts" template="skin-47" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--2"></module>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('40','2017-12-14 11:47:11','2017-12-14 11:47:11','1','1','module','17','layout-skin-41-module-layouts-17','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/hero16.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Development Process</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>

'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('41','2017-12-14 15:24:42','2017-12-14 15:24:42','1','1','content','32','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-32" data-mw-title="Layouts" template="skin-42" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-32"></module>
<section class="wide-grid masonry masonry-shop element"><module class="module module-categories" id="module-categories-32" data-mw-title="Categories" content_id="32" data-type="categories" parent-module="categories" parent-module-id="module-categories-32"></module>
<module class="module module-shop-products" id="module-shop-products-32" data-mw-title="Products" limit="18" description-length="70" template="skin-3" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-32"></module>
<div class="clearfix element"><p class="element"></p></div>
    </section>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('42','2017-12-14 15:24:43','2017-12-14 15:24:43','1','1','module','32','layout-skin-42-module-layouts-32','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/header_ttd_shopping_bbac913b-c0ee-4569-84a6-2d44857c018a.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1>Image Showcase</h1>
                <p class="lead">Showcase a gallery of images with lightbox capability</p>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('43','2017-12-14 16:38:21','2017-12-14 16:38:21','1','1','content','1','dream_content','
    <module class="module module-layouts" id="module-layouts-1" data-mw-title="Layouts" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts" id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module module-layouts" id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class=" module module-layouts " id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class=" module module-layouts " id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class=" module module-layouts " id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class=" module module-layouts " id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class=" module module-layouts " id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class=" module module-layouts " id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('44','2017-12-15 11:57:01','2017-12-15 11:57:01','1','1','content','11','dream_content',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */content_fields_drafts" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "rel_type" varchar null, "rel_id" varchar null, "field" text null, "value" text null, "session_id" varchar null, "is_temp" integer null, "url" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('1','2017-11-28 15:44:57','2017-11-28 15:44:57','1','1','content','1','dream_content','
    <module class="module  module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class=" module module-layouts " id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class=" module module-layouts " id="module-layouts-1--3" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--3"></module>
<module class=" module module-layouts " id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class=" module module-layouts " id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class=" module module-layouts " id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class=" module module-layouts " id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class=" module module-layouts " id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class=" module module-layouts " id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class=" module module-layouts " id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('2','2017-11-28 15:44:58','2017-11-28 15:44:58','1','1','module','1','layout-skin-1-module-layouts-1','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero1.jpg&rsquo;); top: 0px; height: 1021px;">‌ </div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-6 text-right text-center-xs">
                <div class="allow-drop">
                    <p class="logo-text"><span id="fitty-module-layouts-1" class="safe-element">Dream.</span></p>
                </div>
            </div>
            <div class="col-sm-6 text-center-xs">
                <div class="allow-drop">
                    <p class="lead">
                        A beautiful collection of
                        <br> hand-crafted web components
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="modal-instance modal-video-1 element">
                    <module class=" module module-btn  element" id="module-layouts-1-btn" data-mw-title="Button" text="Watch video" data-type="btn" parent-module-id="module-layouts-1" parent-module="layouts"></module>
</div>
            </div>
        </div>
    </div>

    <div class="col-sm-12 pos-absolute pos-bottom">
        <div class="row">
            <div class="col-sm-12 text-center">
                <module class="module module-social-links  element" data-mw-title="Social Links" id="socials" data-type="social_links" parent-module-id="module-layouts-1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('3','2017-11-28 16:10:55','2017-11-28 16:10:55','1','1','content','1','dream_content','
    <module class="module module-layouts" id="module-layouts-1" data-mw-title="Layouts" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts" id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class="module module-layouts" id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class=" module module-layouts " id="module-layouts-1--3" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--3"></module>
<module class=" module module-layouts " id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class=" module module-layouts " id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module-layouts" id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class=" module module-layouts " id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class=" module module-layouts " id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module-layouts module-over currentDragMouseOver" id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<li data-module-name="layouts"  template="skin-46.php" data-filter="Tab Features 3" class="module-item" unselectable="on" style="position: absolute; left: 1764px; top: 5696px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Tab Features 3" title="Tab Features 3 [skin-46]" class="module_draggable" data-module-name-enc="layout_2017112815563345" data-module-name="layouts"  src="{SITE_URL}userfiles/cache/thumbnails/340/tn-1efcb7ed9428ec2c5f2e4e4e2f98ca0c.jpg" data-src="{SITE_URL}userfiles/cache/thumbnails/340/tn-1efcb7ed9428ec2c5f2e4e4e2f98ca0c.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Tab Features 3</span>
                    </span>
                </li>
<module class="module module-layouts" id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('4','2017-11-30 12:24:59','2017-11-30 12:24:59','1','1','content','4','dream_content','
<li data-module-name="layouts"  template="skin-30.php" data-filter="Cover YouTube Background" class="module-item" unselectable="on" style="position: absolute; left: 1636px; top: 663.063px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Cover YouTube Background" title="Cover YouTube Background [skin-30]" class="module_draggable" data-module-name-enc="layout_2017113012244129" data-module-name="layouts"  src="{SITE_URL}api_html/thumbnail_img?&amp;src=userfiles/templates/dream/modules/layouts/templates/skin-30.jpg&amp;width=340&amp;height=340&amp;crop=&amp;cache_id=tn-602f416022fe8b1bbe45440390d7b210.jpg" data-src="{SITE_URL}api_html/thumbnail_img?&amp;src=userfiles/templates/dream/modules/layouts/templates/skin-30.jpg&amp;width=340&amp;height=340&amp;crop=&amp;cache_id=tn-602f416022fe8b1bbe45440390d7b210.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Cover YouTube Background</span>
                    </span>
                </li>
    <module class="module module-layouts" id="module-layouts-4" data-mw-title="Layouts" template="skin-23" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-4"></module>
','o3ekWhhKqHKxX4w4q4zB3NHSEcWhPmIbuXfSHda2','','home-4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('5','2017-11-30 12:27:09','2017-11-30 12:27:09','1','1','content','4','dream_content','
<module class="  module module-layouts module-over" data-mw-title="Layouts" template="skin-30.php" data-type="layouts" id="layouts-201711301224595a1ff89b0d72b" parent-module="layouts" parent-module-id="layouts-201711301224595a1ff89b0d72b"></module>
    <module class="module module-layouts" id="module-layouts-4" data-mw-title="Layouts" template="skin-23" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-4"></module>
','o3ekWhhKqHKxX4w4q4zB3NHSEcWhPmIbuXfSHda2','','home-4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('6','2017-11-30 12:27:09','2017-11-30 12:27:09','1','1','module','4','layout-skin-29-layouts-201711301224595a1ff89b0d72b','
<div class="youtube-background mb_YTPlayer element isMuted" data-video-url="qRaYWfxWq9M" data-start-at="0" data-property=&rsquo;{videoURL:"qRaYWfxWq9M",containment:"self",autoPlay:true, mute:true, startAt:0, opacity:1}&rsquo; id="video_1512044743909" style="background-image: none;">
<span id="controlBar_video_1512044743909" class="mb_YTPBar inlinePlayer compact" style="white-space: nowrap; position: absolute; z-index: 1000;"><div class="buttonBar">
<span class="mb_YTPPlaypause ytpicon">p</span><span class="mb_YTPMuteUnmute ytpicon">A</span><div class="mb_YTPVolumeBar simpleSlider muted" style="display: inline-block; cursor: auto;"><div class="level horizontal"></div></div>
<span class="mb_YTPTime">00 : 29 / 19 : 06</span><span class="mb_YTPUrl ytpicon" title="view on YouTube">Y</span><span class="mb_OnlyYT ytpicon">O</span>
</div>
<div class="mb_YTPProgress" style="position: absolute;">
<div class="mb_YTPLoaded" style="position: absolute; left: 0px; width: 11.1603%;"></div>
<div class="mb_YTPseekbar" style="position: absolute; left: 0px; width: 0px;"></div>
</div></span><div class="mbYTP_wrapper element" id="wrapper_mbYTP_video_1512044743909" style="position: absolute; z-index: 0; min-width: 100%; min-height: 100%; left: 0px; top: 0px; overflow: hidden; opacity: 1; transition-property: opacity; transition-duration: 2000ms;">
<div class="YTPOverlay element" style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
</div>
</div>
    <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/equis-739x340.png&rsquo;); background-position: initial; opacity: 1;"></div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop">
                <p class="lead">
                    Dream is a Chicago-based collective of passionate designers, developers and brand strategists offering insight to some of the world&rsquo;s most admired brands.
                </p>
            </div>
        </div>
    </div>
<div class="loading-indicator element"></div>
','o3ekWhhKqHKxX4w4q4zB3NHSEcWhPmIbuXfSHda2','','home-4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('7','2017-12-01 11:33:39','2017-12-01 11:33:39','1','1','content','5','dream_content','

        <module class="module module-layouts module-over" id="module-layouts-5" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-5"></module>
<section class="element" id="element_1512127958747"><div class="container">
                <div class="row">
                    <div class="col-md-8" style="height: auto;">
                        <module class="module module-posts" data-mw-title="Posts List" data-type="posts" template="skin-2" id="blog-posts-5" parent-module="posts" parent-module-id="blog-posts-5"></module>
</div>
                    <div class="col-md-3 col-md-offset-1 hidden-sm hidden-xs" style="height: auto;">
                        <div class="edit" field="dream_blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>
                    </div>
                </div>
            </div>
        </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('8','2017-12-01 11:33:39','2017-12-01 11:33:39','1','1','module','5','layout-skin-68-module-layouts-5','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512127958881">Title</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('9','2017-12-01 11:41:36','2017-12-01 11:41:36','1','1','content','6','dream_content','
        <module class="module module-layouts module-over" id="module-layouts-6" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6"></module>
<module class=" module module-posts " data-mw-title="Posts List" data-type="posts" template="skin-3" id="blog-2-posts-6" parent-module="posts" parent-module-id="blog-2-posts-6"></module>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('10','2017-12-01 11:41:37','2017-12-01 11:41:37','1','1','module','6','layout-skin-68-module-layouts-6','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128483029">Bl</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('11','2017-12-01 11:41:38','2017-12-01 11:41:38','1','1','module','6','layout-skin-68-module-layouts-6','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128483029">Blog Sim</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('12','2017-12-01 11:41:59','2017-12-01 11:41:59','1','1','content','5','dream_content','

        <module class="module module-layouts module-over" id="module-layouts-5" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-5"></module>
<section class=" element"><div class="container">
                <div class="row">
                    <div class="col-md-8" style="height: auto;">
                        <module class=" module module-posts " data-mw-title="Posts List" data-type="posts" template="skin-2" id="blog-posts-5" parent-module="posts" parent-module-id="blog-posts-5"></module>
</div>
                    <div class="col-md-3 col-md-offset-1 hidden-sm hidden-xs" style="height: auto;">
                        <div class="edit" field="dream_blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>
                    </div>
                </div>
            </div>
        </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('13','2017-12-01 11:41:59','2017-12-01 11:41:59','1','1','module','5','layout-skin-68-module-layouts-5','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512127958881">Blog Sid</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>


','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('14','2017-12-01 11:43:12','2017-12-01 11:43:12','1','1','content','7','dream_content','
        <module class="module module-layouts module-over" id="module-layouts-7" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7"></module>
<module class="module module-posts" data-mw-title="Posts List" data-type="posts" template="skin-4" id="blog-3-posts-7" parent-module="posts" parent-module-id="blog-3-posts-7"></module>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog-3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('15','2017-12-01 11:43:13','2017-12-01 11:43:13','1','1','module','7','layout-skin-68-module-layouts-7','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128555606">Blo</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog-3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('16','2017-12-01 11:43:14','2017-12-01 11:43:14','1','1','module','7','layout-skin-68-module-layouts-7','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128555606">Blog </h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','blog-3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('17','2017-12-01 11:44:24','2017-12-01 11:44:24','1','1','content','8','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-8" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-8"></module>
<section class="masonry-contained element" id="element_1512128656367"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class=" module module-categories " id="module-categories-8" data-mw-title="Categories" content-id="8" data-type="categories" parent-module="categories" parent-module-id="module-categories-8"></module>
<module class=" module module-shop-products " id="module-shop-products-8" data-mw-title="Products" limit="18" description-length="70" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-8"></module>
</div>
            </div>
        </div>
    </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('18','2017-12-01 11:44:27','2017-12-01 11:44:27','1','1','module','8','layout-skin-68-module-layouts-8','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128656517">Title</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('19','2017-12-01 11:44:41','2017-12-01 11:44:41','1','1','content','9','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-9" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-9"></module>
<section class="masonry-contained element"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class=" module module-categories " id="module-categories-9" data-mw-title="Categories" content-id="9" data-type="categories" parent-module="categories" parent-module-id="module-categories-9"></module>
<module class=" module module-shop-products " id="module-shop-products-9" data-mw-title="Products" limit="18" description-length="70" template="skin-1" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-9"></module>
</div>
            </div>
        </div>
    </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('20','2017-12-01 11:44:41','2017-12-01 11:44:41','1','1','module','9','layout-skin-68-module-layouts-9','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128674023">Shop 2</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('21','2017-12-01 11:44:54','2017-12-01 11:44:54','1','1','content','10','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-10" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-10"></module>
<section class="masonry-contained element"><div class="container">
            <div class="row">
                <div class="col-md-9" style="height: auto;">
                    <div class="masonry-shop element">
                        <module class=" module module-shop-products " id="module-shop-products-10" data-mw-title="Products" limit="18" description-length="70" template="skin-2" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-10"></module>
</div>
                </div>

                <div class="col-md-3 hidden-sm hidden-xs" style="height: auto;">
                    <div class="edit" field="blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>


                </div>
            </div>
        </div>
    </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop-3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('22','2017-12-01 11:44:55','2017-12-01 11:44:55','1','1','module','10','layout-skin-68-module-layouts-10','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128688938">Title</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop-3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('23','2017-12-01 11:44:56','2017-12-01 11:44:56','1','1','content','10','dream_content','
    <module class="module module-layouts" id="module-layouts-10" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-10"></module>
<section class="masonry-contained element element-over" id="element_1512128689313"><div class="container">
            <div class="row">
                <div class="col-md-9" style="height: auto;">
                    <div class="masonry-shop element">
                        <module class=" module module-shop-products " id="module-shop-products-10" data-mw-title="Products" limit="18" description-length="70" template="skin-2" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-10"></module>
</div>
                </div>

                <div class="col-md-3 hidden-sm hidden-xs" style="height: auto;">
                    <div class="edit" field="blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>


                </div>
            </div>
        </div>
    </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop-3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('24','2017-12-01 11:44:58','2017-12-01 11:44:58','1','1','module','10','layout-skin-68-module-layouts-10','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128688938">Shop 3</h1>
                <p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop-3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('25','2017-12-01 11:45:14','2017-12-01 11:45:14','1','1','content','11','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-11" data-mw-title="Layouts" template="skin-42" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-11"></module>
<section class="wide-grid masonry masonry-shop element"><module class="module module-categories" id="module-categories-11" data-mw-title="Categories" content_id="11" data-type="categories" parent-module="categories" parent-module-id="module-categories-11"></module>
<module class="module module-shop-products" id="module-shop-products-11" data-mw-title="Products" limit="18" description-length="70" template="skin-3" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-11"></module>
<div class="clearfix element"><p class="element"></p></div>
    </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop-4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('26','2017-12-01 11:45:14','2017-12-01 11:45:14','1','1','module','11','layout-skin-42-module-layouts-11','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero4.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1>S</h1>
                <p class="lead">Showcase a gallery of images with lightbox capability</p>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','shop-4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('27','2017-12-01 11:45:29','2017-12-01 11:45:29','1','1','content','12','dream_content','
        <module class="height-70 module module-layouts module-over" id="module-layouts-12" data-mw-title="Layouts" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12"></module>
<module class="section--overlap module module-layouts " id="module-layouts-12--1" data-mw-title="Layouts" template="skin-55" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--1"></module>
<module class=" module module-layouts " id="module-layouts-12--2" data-mw-title="Layouts" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--2"></module>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','services'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('28','2017-12-01 11:45:30','2017-12-01 11:45:30','1','1','module','12','layout-skin-41-module-layouts-12','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Serv</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>

','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','services'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('29','2017-12-01 11:45:32','2017-12-01 11:45:32','1','1','module','12','layout-skin-41-module-layouts-12','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Services Car</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>

','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','services'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('30','2017-12-01 11:45:56','2017-12-01 11:45:56','1','1','content','13','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-13" data-mw-title="Layouts" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13"></module>
<module class="module module-layouts" id="module-layouts-13--1" data-mw-title="Layouts" template="skin-53" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--1"></module>
<module class="module module-layouts" id="module-layouts-13--2" data-mw-title="Layouts" template="skin-54" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--2"></module>
<module class=" module module-layouts " id="module-layouts-13--3" data-mw-title="Layouts" template="skin-53" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--3"></module>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','services-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('31','2017-12-01 11:45:56','2017-12-01 11:45:56','1','1','module','13','layout-skin-41-module-layouts-13','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Seric</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>

','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','services-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('32','2017-12-01 11:45:58','2017-12-01 11:45:58','1','1','module','13','layout-skin-41-module-layouts-13','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Services</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>

','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','services-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('33','2017-12-01 11:46:18','2017-12-01 11:46:18','1','1','content','14','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-14" data-mw-title="Layouts" template="skin-40" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14"></module>
<module class=" module module-layouts " id="module-layouts-14--1" data-mw-title="Layouts" template="skin-17" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--1"></module>
<module class=" module module-layouts " id="module-layouts-14--2" data-mw-title="Layouts" template="skin-18" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--2"></module>
<module class=" module module-layouts " id="module-layouts-14--3" data-mw-title="Layouts" template="skin-19" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--3"></module>
<module class=" module module-layouts " id="module-layouts-14--4" data-mw-title="Layouts" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--4"></module>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('34','2017-12-01 11:46:18','2017-12-01 11:46:18','1','1','module','14','layout-skin-40-module-layouts-14','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h1>S.</h1>
            </div>
        </div>

    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('35','2017-12-01 11:46:20','2017-12-01 11:46:20','1','1','module','14','layout-skin-40-module-layouts-14','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h1>About .</h1>
            </div>
        </div>

    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('36','2017-12-01 11:46:22','2017-12-01 11:46:22','1','1','module','14','layout-skin-40-module-layouts-14','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h1>About Us</h1>
            </div>
        </div>

    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('37','2017-12-01 11:46:42','2017-12-01 11:46:42','1','1','content','15','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-15" data-mw-title="Layouts" template="skin-57" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-15"></module>
<module class=" module module-layouts " id="module-layouts-15--1" data-mw-title="Layouts" template="skin-56" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-15--1"></module>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','portfolio'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('38','2017-12-01 11:46:43','2017-12-01 11:46:43','1','1','module','15','layout-skin-57-module-layouts-15','
    <section class="height-70 safe-mode bg--dark imagebg page-title page-title--animate parallax" data-overlay="4"><div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); transform: translate3d(0px, 0px, 0px); background-position: initial; opacity: 1; top: 0px;"></div>

        <div class="container pos-vertical-center">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                    <h1>Port</h1>
                </div>
            </div>
        </div>
    </section><section class="masonry-contained section--overlap"><div class="container">
            <div class="row">
                <div class="masonry box-shadow-wide">
                    <div class="masonry__filters masonry__filters--outside text-center" data-filter-all-text="Show All"><ul>
<li class="active" data-masonry-filter="*">Show All</li>
<li data-masonry-filter="branding">branding</li>
<li data-masonry-filter="digital">digital</li>
<li data-masonry-filter="packaging">packaging</li>
</ul></div>
                    <div class="masonry__container masonry--gapless masonry--animate masonry--active" style="position: relative; height: 1316.25px;">
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 0px; top: 0px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work6.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Freehance</h5>
                                            <span>
                                                        <em>iOS Application</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-branding" data-masonry-filter="branding" style="position: absolute; left: 585px; top: 0px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work2.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Michael Andrews</h5>
                                            <span>
                                                        <em>Branding &amp; Identity</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-packaging" data-masonry-filter="packaging" style="position: absolute; left: 0px; top: 438px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work5.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Authentic Apparel</h5>
                                            <span>
                                                        <em>Packaging Design</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-branding" data-masonry-filter="branding" style="position: absolute; left: 585px; top: 438px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work10.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Wave Poster</h5>
                                            <span>
                                                        <em>Logo Design</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 0px; top: 877px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work12.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Tesla Controller</h5>
                                            <span>
                                                        <em>Apple Watch Application</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 585px; top: 877px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work14.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Pillar</h5>
                                            <span>
                                                        <em>Website &amp; Digital</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','portfolio'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('39','2017-12-01 11:48:06','2017-12-01 11:48:06','1','1','module','15','layout-skin-57-module-layouts-15','
    <section class="height-70 safe-mode bg--dark imagebg page-title page-title--animate parallax" data-overlay="4"><div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); transform: translate3d(0px, 0px, 0px); background-position: initial; opacity: 1; top: 0px;"></div>

        <div class="container pos-vertical-center">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                    <h1>Portfolio</h1>
                </div>
            </div>
        </div>
    </section><section class="masonry-contained section--overlap"><div class="container">
            <div class="row">
                <div class="masonry box-shadow-wide">
                    <div class="masonry__filters masonry__filters--outside text-center" data-filter-all-text="Show All"><ul>
<li class="active" data-masonry-filter="*">Show All</li>
<li data-masonry-filter="branding">branding</li>
<li data-masonry-filter="digital">digital</li>
<li data-masonry-filter="packaging">packaging</li>
</ul></div>
                    <div class="masonry__container masonry--gapless masonry--animate masonry--active" style="position: relative; height: 1316.25px;">
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 0px; top: 0px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work6.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Freehance</h5>
                                            <span>
                                                        <em>iOS Application</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-branding" data-masonry-filter="branding" style="position: absolute; left: 585px; top: 0px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work2.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Michael Andrews</h5>
                                            <span>
                                                        <em>Branding &amp; Identity</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-packaging" data-masonry-filter="packaging" style="position: absolute; left: 0px; top: 438px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work5.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Authentic Apparel</h5>
                                            <span>
                                                        <em>Packaging Design</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-branding" data-masonry-filter="branding" style="position: absolute; left: 585px; top: 438px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work10.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Wave Poster</h5>
                                            <span>
                                                        <em>Logo Design</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 0px; top: 877px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work12.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Tesla Controller</h5>
                                            <span>
                                                        <em>Apple Watch Application</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                        <div class="col-sm-6 masonry__item filter-digital" data-masonry-filter="digital" style="position: absolute; left: 585px; top: 877px;">
                            <a href="#">
                                <div class="hover-element hover-element-1" data-title-position="top,right">
                                    <div class="hover-element__initial">
                                        <img alt="Pic" src="{SITE_URL}userfiles/templates/dream/assets/img/work14.jpg">
</div>
                                    <div class="hover-element__reveal" data-overlay="9">
                                        <div class="boxed">
                                            <h5>Pillar</h5>
                                            <span>
                                                        <em>Website &amp; Digital</em>
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','portfolio'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('40','2017-12-01 11:48:34','2017-12-01 11:48:34','1','1','content','16','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-16" data-mw-title="Layouts" template="skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-16"></module>
<module class=" module module-layouts " id="module-layouts-16--1" data-mw-title="Layouts" template="skin-52" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-16--1"></module>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','text-page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('41','2017-12-01 11:48:35','2017-12-01 11:48:35','1','1','module','16','layout-skin-2-module-layouts-16','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center  allow-drop" style="height: auto;">
                <h2 class="element allow-drop" id="element_1512128900792">Clean Page</h2>
                <div class="element" id="element_1512128900911"><span class="safe-element"><em>Just a </em></span></div>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','text-page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('42','2017-12-01 11:48:36','2017-12-01 11:48:36','1','1','module','16','layout-skin-2-module-layouts-16','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center  allow-drop" style="height: auto;">
                <h2 class="element allow-drop" id="element_1512128900792">Clean Page</h2>
                <div class="element" id="element_1512128900911"><span class="safe-element"><em>Just a Text Pa</em></span></div>
            </div>
        </div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','text-page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('43','2017-12-01 11:56:26','2017-12-01 11:56:26','1','1','content','4','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-4" data-mw-title="Layouts" template="skin-23" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-4"></module>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','home-4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('44','2017-12-01 11:56:26','2017-12-01 11:56:26','1','1','module','4','layout-skin-23-module-layouts-4','
<div class="col-md-6 col-sm-5">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero6.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>
    <div class="col-md-6 col-sm-7 bg--white text-center">
        <div class="pos-vertical-center allow-drop">
            <img class="logo" alt="Dream" src="{SITE_URL}userfiles/templates/dream/assets/img/logo-large-dark.png"><p class="lead">
                A beautiful collection of
                <br> hand-crafted web components
            </p>

            <module class=" module module-btn " id="module-layouts-4-btn" data-mw-title="Button" template="default" text="Purchase Dream" data-type="btn" parent-module-id="module-layouts-4" parent-module="layouts"></module>
</div>

        <div class="col-sm-12 text-center pos-absolute pos-bottom">
            <module class=" module module-social-links " id="module-layouts-4-social-links" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-4" parent-module="layouts"></module>
</div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','home-4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('45','2017-12-01 11:56:27','2017-12-01 11:56:27','1','1','module','4','layout-skin-23-module-layouts-4','
<div class="col-md-6 col-sm-5">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero6.jpg&rsquo;); background-position: initial; opacity: 1;" id="element_1512129358480"></div>
    </div>
    <div class="col-md-6 col-sm-7 bg--white text-center">
        <div class="pos-vertical-center allow-drop">
            <img class="logo" alt="Dream" src="{SITE_URL}userfiles/templates/dream/assets/img/logo-large-dark.png"><p class="lead"><br><br>A beautiful collection of
                <br> hand-crafted web components
            </p>

            <module class=" module module-btn " id="module-layouts-4-btn" data-mw-title="Button" template="default" text="Purchase Dream" data-type="btn" parent-module-id="module-layouts-4" parent-module="layouts"></module>
</div>

        <div class="col-sm-12 text-center pos-absolute pos-bottom">
            <module class=" module module-social-links " id="module-layouts-4-social-links" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-4" parent-module="layouts"></module>
</div>
    </div>
','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','home-4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('46','2017-12-01 11:57:55','2017-12-01 11:57:55','1','1','global','0','dream_footer','
            <div class="row">
                <div class="col-md-3 col-sm-4 allow-drop" style="height: auto;">
                    <module class="module module-logo" data-mw-title="Logo" id="footer-logo" template="footer" data-type="logo" parent-module="logo" parent-module-id="footer-logo"></module><p class="element" id="element_1512129402394"><em>Digital Design Melbourne</em></p>
                    <module class="module   module module-menu module-over" data-mw-title="Menu" template="footer" name="footer_menu" id="footer_menu" data-type="menu" parent-module="menu" parent-module-id="footer_menu"></module>
</div>

                <div class="col-md-4 col-sm-8 allow-drop" style="height: auto;">
                    <h6 class=" element">Recent News</h6>
                    <module class="module module-posts" data-mw-title="Posts List" template="skin-5" id="recent-news-1" limit="3" hide-paging="true" data-type="posts" parent-module="posts" parent-module-id="recent-news-1"></module>
</div>

                <div class="col-md-4 col-md-offset-1 col-sm-12 allow-drop" style="height: auto;">
                    <h6 class=" element">Subscribe</h6>
                    <p class=" element">Get monthly updates and free resources.</p>

                    <module class=" module module-newsletter " data-mw-title="Newsletter" id="footer-newsletter" data-type="newsletter" parent-module="newsletter" parent-module-id="footer-newsletter"></module><h6 class=" element">Connect with Us</h6>
                    <module class=" module module-social-links " data-mw-title="Social Links" id="socials" data-type="social_links" parent-module="social_links" parent-module-id="socials"></module>
</div>
            </div>
        ','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('47','2017-12-01 11:58:36','2017-12-01 11:58:36','1','1','global','0','dream_footer','
            <div class="row">
                <div class="col-md-3 col-sm-4 allow-drop" style="height: auto;">
                    <module class="module module-logo" data-mw-title="Logo" id="footer-logo" template="footer" data-type="logo" parent-module="logo" parent-module-id="footer-logo"></module><p class="element" id="element_1512129402394"><em>Digital Design Melbourne</em></p>
                    <module class="module   module module-menu" data-mw-title="Menu" template="footer" name="footer_menu" id="footer_menu" data-type="menu" parent-module="menu" parent-module-id="footer_menu"></module>
</div>

                <div class="col-md-4 col-sm-8 allow-drop" style="height: auto;">
                    <h6 class=" element">Recent News</h6>
                    <module class="module module-posts" data-mw-title="Posts List" template="skin-5" id="recent-news-1" limit="3" hide-paging="true" data-type="posts" parent-module="posts" parent-module-id="recent-news-1"></module>
</div>

                <div class="col-md-4 col-md-offset-1 col-sm-12 allow-drop" style="height: auto;">
                    <h6 class=" element">Subscribe</h6>
                    <p class=" element">Get monthly updates and free resources.</p>

                    <module class=" module module-newsletter " data-mw-title="Newsletter" id="footer-newsletter" data-type="newsletter" parent-module="newsletter" parent-module-id="footer-newsletter"></module><h6 class=" element">Connect with Us</h6>
                    <module class=" module module-social-links " data-mw-title="Social Links" id="socials" data-type="social_links" parent-module="social_links" parent-module-id="socials"></module>
</div>
            </div>
        ','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('48','2017-12-05 09:41:39','2017-12-05 09:41:39','1','1','content','15','dream_content','
    
    <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-15" template="skin-57" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-15"></module>
<module class="module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-15--1" template="skin-56" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-15--1"></module>

','5kwoI30ca19G24Z5AhtHMFpxYyCHewww3VA01oCb','','portfolio'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('49','2017-12-05 09:41:39','2017-12-05 09:41:39','1','1','module','15','layout-skin-56-module-layouts-15--1','
<div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3 class="element allow-drop mw_drag_current" id="element_1512466858320" style="visibility: hidden;">Start building with Dream</h3>
                <p class="lead">We&rsquo;d love to hear from you to discuss web design, product development or to hear your new startup idea.</p>

                <module class="module module-btn  element" id="module-layouts-15--1-btn--1" data-mw-title="Button" text="Lets Talk" data-type="btn" parent-module-id="module-layouts-15--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','5kwoI30ca19G24Z5AhtHMFpxYyCHewww3VA01oCb','','portfolio'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('50','2017-12-05 09:41:41','2017-12-05 09:41:41','1','1','module','15','layout-skin-56-module-layouts-15--1','
<div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 text-center allow-drop currentDragMouseOver" style="height: auto;">
<h3 class="element allow-drop" id="element_1512466858320" style="">Start building with Dream</h3>
                
                <p class="lead">We&rsquo;d love to hear from you to discuss web design, product development or to hear your new startup idea.</p>

                <module class="module module-btn  element" id="module-layouts-15--1-btn--1" data-mw-title="Button" text="Lets Talk" data-type="btn" parent-module-id="module-layouts-15--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','5kwoI30ca19G24Z5AhtHMFpxYyCHewww3VA01oCb','','portfolio'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('51','2017-12-05 11:02:12','2017-12-05 11:02:12','1','1','content','9','dream_content','
    
    <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-9" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-9"></module>
<section class="masonry-contained element" id="element_1512128674249"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class="module module-categories module-over" data-mw-title="Categories" id="module-categories-9" content-id="9" data-type="categories" parent-module="categories" parent-module-id="module-categories-9"></module>
<module class=" module module-shop-products " data-mw-title="Products" id="module-shop-products-9" limit="18" description-length="70" template="skin-1" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-9"></module>
</div>
            </div>
        </div>
    </section>
','yDURvhEjrE9efmgITRrAGqNoxj6JNCAj70DeVqw5','','shop-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('52','2017-12-05 11:02:12','2017-12-05 11:02:12','1','1','module','9','layout-skin-68-module-layouts-9','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128674023" data-gramm_id="39da8eb3-133c-bdc2-5e18-6bf81afb0038" data-gramm="true" spellcheck="false" data-gramm_editor="true">Shop 2</h1>
<grammarly-btn><div class="_1BN1N Kzi1t _2DJZN" style="z-index: 2; transform: translate(2250px, 70px);"><div class="_1HjH7"><div title="Protected by Grammarly" class="_3qe6h"> </div></div></div></grammarly-btn><p class="lead">Showcase blog posts in a classic column arrangement</p>
            </div>
        </div>
    </div>


','yDURvhEjrE9efmgITRrAGqNoxj6JNCAj70DeVqw5','','shop-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('53','2017-12-13 14:51:18','2017-12-13 14:51:18','1','1','content','12','dream_content','
        
        <module class="height-70  module module-layouts mwfadeout module-over" data-mw-title="Layouts" id="module-layouts-12" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12"></module>
<module class="section--overlap module module-layouts " data-mw-title="Layouts" id="module-layouts-12--1" template="skin-55" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-12--2" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--2"></module>

','2fsvpbTraoW3B85VpvOciSlDc32t2j9ELwkgPStS','','services'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('54','2017-12-13 14:52:53','2017-12-13 14:52:53','1','1','content','12','dream_content','
        
        <module class="height-70    module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-12" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12"></module>
<module class="section--overlap module module-layouts " data-mw-title="Layouts" id="module-layouts-12--1" template="skin-55" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-12--2" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--2"></module>

','2fsvpbTraoW3B85VpvOciSlDc32t2j9ELwkgPStS','','services'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('55','2017-12-13 14:52:53','2017-12-13 14:52:53','1','1','module','12','layout-skin-41-module-layouts-12','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero21.jpg&rsquo;); background-position: initial; opacity: 1;">‌ </div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Services Cards</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>





','2fsvpbTraoW3B85VpvOciSlDc32t2j9ELwkgPStS','','services'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('56','2017-12-13 14:55:01','2017-12-13 14:55:01','1','1','content','12','dream_content','
        
        <module class="height-70    module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-12" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12"></module>
<module class="section--overlap module module-layouts" data-mw-title="Layouts" id="module-layouts-12--1" template="skin-55" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-12--2" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--2"></module>

','2fsvpbTraoW3B85VpvOciSlDc32t2j9ELwkgPStS','','services'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('57','2017-12-13 14:55:01','2017-12-13 14:55:01','1','1','module','12','layout-skin-41-module-layouts-12','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/19-min.jpg&rsquo;); background-position: initial; opacity: 1;">‌ </div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Services Cards</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>





','2fsvpbTraoW3B85VpvOciSlDc32t2j9ELwkgPStS','','services'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('58','2017-12-14 11:07:31','2017-12-14 11:07:31','1','1','content','1','dream_content','
    <module class=" module module-layouts " id="module-layouts-1" data-mw-title="Layouts" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts" id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module module-layouts module-over" id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class=" module module-layouts " id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class=" module module-layouts " id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class=" module module-layouts " id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class=" module module-layouts " id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class=" module module-layouts " id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class=" module module-layouts " id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('59','2017-12-14 11:14:59','2017-12-14 11:14:59','1','1','content','31','title','Product name','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','charles-leather-bag'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('60','2017-12-14 11:21:42','2017-12-14 11:21:42','1','1','content','1','dream_content','
    
    <module class="module module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<li data-module-name="layouts"  template="skin-1.php" data-filter="Cover Media 1" class="module-item" unselectable="on" style="position: absolute; left: 1082px; top: 338px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Cover Media 1" title="Cover Media 1 [skin-1]" class="module_draggable" data-module-name-enc="layout_201712141112160" data-module-name="layouts"  src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg" data-src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Cover Media 1</span>
                    </span>
                </li>
<module class="module module module-layouts currentDragMouseOver" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('61','2017-12-14 11:25:31','2017-12-14 11:25:31','1','1','content','1','dream_content','
    
    <module class="module module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('62','2017-12-14 11:25:32','2017-12-14 11:25:32','1','1','module','1','layout-skin-1-module-layouts-1','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero1.jpg&rsquo;); top: 0px; transform: translate3d(0px, 0px, 0px); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-6 text-right text-center-xs" style="height: auto;">
                <div class="allow-drop">
                    <p class="logo-text"><span id="fitty-module-layouts-1" class="safe-element">Dream.</span></p>
                </div>
            </div>
            <div class="col-sm-6 text-center-xs" style="height: auto;">
                <div class="allow-drop">
                    <p class="lead" data-gramm_id="f452f464-b1ed-ace8-8dcb-d654b5745d9e" data-gramm="true" spellcheck="false" data-gramm_editor="true">
                        A beautiful collection of
                        <br> hand-craf<i class="mw-icon mw-icon-mw"></i>ted web components
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center" style="height: auto;">
                <div class="modal-instance modal-video-1">
                    <module class="module module-btn" id="module-layouts-1-btn--1" data-mw-title="Button" text="Watch video" data-type="btn" parent-module-id="module-layouts-1" parent-module="layouts"></module>
</div>
            </div>
        </div>
    </div>

    <div class="col-sm-12 pos-absolute pos-bottom">
        <div class="row">
            <div class="col-sm-12 text-center" style="height: auto;">
                <module class="module module-social-links" data-mw-title="Social Links" id="socials" data-type="social_links" parent-module-id="module-layouts-1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('63','2017-12-14 11:26:31','2017-12-14 11:26:31','1','1','module','1','layout-skin-1-module-layouts-1','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero1.jpg&rsquo;); top: 0px; transform: translate3d(0px, 0px, 0px); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-6 text-right text-center-xs" style="height: auto;">
                <div class="allow-drop">
                    <p class="logo-text"><span id="fitty-module-layouts-1" class="safe-element">Dream.</span></p>
                </div>
            </div>
            <div class="col-sm-6 text-center-xs" style="height: auto;">
                <div class="allow-drop">
                    <p class="lead" data-gramm_id="f452f464-b1ed-ace8-8dcb-d654b5745d9e" data-gramm="true" spellcheck="false" data-gramm_editor="true">
                        A beautiful collection of
                        <br> hand-craf<i class="mw-icon mw-icon-mw"></i>ted web components
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center" style="height: auto;" data-gramm_id="f805e04d-792c-32ea-4674-5d9ab1c68e45" data-gramm="true" spellcheck="false" data-gramm_editor="true">
                <div class="modal-instance modal-video-1">
                    <module class="module module-btn" id="module-layouts-1-btn--1" data-mw-title="Button" text="Watch video" data-type="btn" parent-module-id="module-layouts-1" parent-module="layouts"></module>
</div>
            </div>
        </div>
    </div>

    <div class="col-sm-12 pos-absolute pos-bottom">
        <div class="row">
            <div class="col-sm-12 text-center" style="height: auto;">
                <module class="module module-social-links" data-mw-title="Social Links" id="socials" data-type="social_links" parent-module-id="module-layouts-1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('64','2017-12-14 11:31:25','2017-12-14 11:31:25','1','1','content','1','dream_content','
    
    <module class="module module module-layouts module-over currentDragMouseOver" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<li data-module-name="layouts"  template="skin-1.php" data-filter="Cover Media 1" class="module-item" unselectable="on" style="position: absolute; left: 1082px; top: 238px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Cover Media 1" title="Cover Media 1 [skin-1]" class="module_draggable" data-module-name-enc="layout_201712141120440" data-module-name="layouts"  src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg" data-src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Cover Media 1</span>
                    </span>
                </li>
<module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('65','2017-12-14 11:31:56','2017-12-14 11:31:56','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module module-layouts module-over currentDragMouseOver" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('66','2017-12-14 11:32:29','2017-12-14 11:32:29','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<li data-module-name="layouts"  template="skin-1.php" data-filter="Cover Media 1" class="module-item" unselectable="on" style="position: absolute; left: 1082px; top: 638px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Cover Media 1" title="Cover Media 1 [skin-1]" class="module_draggable" data-module-name-enc="layout_201712141132080" data-module-name="layouts"  src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg" data-src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Cover Media 1</span>
                    </span>
                </li>
<module class="module module module-layouts module-over currentDragMouseOver" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('67','2017-12-14 11:33:07','2017-12-14 11:33:07','1','1','content','9','dream_content','
    
    <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-9" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-9"></module>
<section class="masonry-contained element element-over" id="element_1512128674249"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class="module module-categories" data-mw-title="Categories" id="module-categories-9" content-id="9" data-type="categories" parent-module="categories" parent-module-id="module-categories-9"></module>
<module class="module module-shop-products" data-mw-title="Products" id="module-shop-products-9" limit="18" description-length="70" template="skin-1" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-9"></module>
</div>
            </div>
        </div>
    </section>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','shop-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('68','2017-12-14 11:36:35','2017-12-14 11:36:35','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts module-over currentDragMouseOver" data-mw-title="Layouts" template="skin-1.php" data-type="layouts" id="layouts-201712141132285a32614ce6af5" parent-module="layouts" parent-module-id="layouts-201712141132285a32614ce6af5"></module>
<li data-module-name="layouts"  template="skin-1.php" data-filter="Cover Media 1" class="module-item" unselectable="on" style="position: absolute; left: 1082px; top: 938px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Cover Media 1" title="Cover Media 1 [skin-1]" class="module_draggable" data-module-name-enc="layout_201712141132080" data-module-name="layouts"  src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg" data-src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Cover Media 1</span>
                    </span>
                </li>
<module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('69','2017-12-14 11:36:45','2017-12-14 11:36:45','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts currentDragMouseOver" data-mw-title="Layouts" template="skin-1.php" data-type="layouts" id="layouts-201712141132285a32614ce6af5" parent-module="layouts" parent-module-id="layouts-201712141132285a32614ce6af5"></module>
<module class="module module-layouts" data-mw-title="Layouts" template="skin-1.php" data-type="layouts" id="layouts-201712141136345a326242e8ddd" parent-module="layouts" parent-module-id="layouts-201712141136345a326242e8ddd"></module>
<module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('70','2017-12-14 11:36:45','2017-12-14 11:36:45','1','1','module','1','layout-skin-1-layouts-201712141136345a326242e8ddd','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero1.jpg&rsquo;); top: 0px; height: 637px; transform: translate3d(0px, 600px, 0px);"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-6 text-right text-center-xs">
                <div class="allow-drop">
                    <p class="logo-text"><span id="fitty-layouts-201712141136345a326242e8ddd" class="safe-element">Dream.</span></p>
                </div>
            </div>
            <div class="col-sm-6 text-center-xs">
                <div class="allow-drop">
                    <p class="lead" spellcheck="true">
                        A beautiful collection of
                        <br> hand-crafted web components
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="modal-instance modal-video-1">
                    <div class="edit" field="layout-skin-1-btn-layouts-201712141136345a326242e8ddd" rel="module">
                        <module class="module module-btn" id="layouts-201712141136345a326242e8ddd-btn" data-mw-title="Button" text="Watch video" data-type="btn" parent-module-id="layouts-201712141136345a326242e8ddd" parent-module="layouts"></module>
</div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-12 pos-absolute pos-bottom">
        <div class="row">
            <div class="col-sm-12 text-center">
                <module class=" module module-social-links " data-mw-title="Social Links" id="socials" data-type="social_links" parent-module-id="layouts-201712141136345a326242e8ddd" parent-module="layouts"></module>
</div>
        </div>
    </div>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('71','2017-12-14 11:37:21','2017-12-14 11:37:21','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module module-layouts module-over currentDragMouseOver" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<li data-module-name="layouts"  template="skin-1.php" data-filter="Cover Media 1" class="module-item" unselectable="on" style="position: absolute; left: 1082px; top: 338px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Cover Media 1" title="Cover Media 1 [skin-1]" class="module_draggable" data-module-name-enc="layout_201712141136500" data-module-name="layouts"  src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg" data-src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Cover Media 1</span>
                    </span>
                </li>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('72','2017-12-14 11:38:21','2017-12-14 11:38:21','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module module-layouts module-over currentDragMouseOver" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('73','2017-12-14 11:38:30','2017-12-14 11:38:30','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts " data-mw-title="Layouts" template="skin-1.php" data-type="layouts" id="layouts-201712141138215a3262ad7956d" parent-module="layouts" parent-module-id="layouts-201712141138215a3262ad7956d"></module>
<module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<li data-module-name="layouts"  template="skin-1.php" data-filter="Cover Media 1" class="module-item" unselectable="on" style="position: absolute; left: 1082px; top: 1438px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Cover Media 1" title="Cover Media 1 [skin-1]" class="module_draggable" data-module-name-enc="layout_201712141137410" data-module-name="layouts"  src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg" data-src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Cover Media 1</span>
                    </span>
                </li>
<module class="module  module module-layouts module-over currentDragMouseOver" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('74','2017-12-14 11:39:51','2017-12-14 11:39:51','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts " data-mw-title="Layouts" template="skin-1.php" data-type="layouts" id="layouts-201712141138215a3262ad7956d" parent-module="layouts" parent-module-id="layouts-201712141138215a3262ad7956d"></module>
<module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module module-layouts" data-mw-title="Layouts" template="skin-1.php" data-type="layouts" id="layouts-201712141138305a3262b62be64" parent-module="layouts" parent-module-id="layouts-201712141138305a3262b62be64"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<li data-module-name="layouts"  template="skin-1.php" data-filter="Cover Media 1" class="module-item" unselectable="on" style="position: absolute; left: 1082px; top: 1438px;">
                    <span class="mw_module_hold">
                                                <span class="mw_module_image">
                            <span class="mw_module_image_holder">
                                <img alt="Cover Media 1" title="Cover Media 1 [skin-1]" class="module_draggable" data-module-name-enc="layout_201712141137410" data-module-name="layouts"  src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg" data-src="{SITE_URL}userfiles/cache/thumbnails/340/tn-4b42c9c3739dacc3bf4a39701a01d9d9.jpg"></span>
                        </span>
                        <span class="module_name" alt="">Cover Media 1</span>
                    </span>
                </li>
<module class="module module module-layouts module-over currentDragMouseOver" data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('75','2017-12-14 11:40:18','2017-12-14 11:40:18','1','1','content','14','dream_content','
    
    <module class="module  module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-14" template="skin-40" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--1" template="skin-17" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--1"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--2" template="skin-18" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--2"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--3" template="skin-19" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--3"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--4" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--4"></module>

','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('76','2017-12-14 11:40:18','2017-12-14 11:40:18','1','1','module','14','layout-skin-40-module-layouts-14','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/hero10.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h1>About Us</h1>
            </div>
        </div>

    </div>


','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('77','2017-12-14 11:41:13','2017-12-14 11:41:13','1','1','content','14','dream_content','
    
    <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-14" template="skin-40" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--1" template="skin-17" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--1"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--2" template="skin-18" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--2"></module>
<module class="module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-14--3" template="skin-19" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--3"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--4" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--4"></module>

','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('78','2017-12-14 11:41:13','2017-12-14 11:41:13','1','1','module','14','layout-skin-20-module-layouts-14--4','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/hero8.jpg&rsquo;); transform: translate3d(0px, 1300px, 0px); background-position: initial; opacity: 1; top: 0px;"></div>

    <div class="container">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h4>What can Dream do for your business?</h4>
                <module class="module module-btn" id="module-layouts-14--4-btn--1" data-mw-title="Button" text="Arrange A Consultation" data-type="btn" parent-module-id="module-layouts-14--4" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('79','2017-12-14 11:41:39','2017-12-14 11:41:39','1','1','global','0','dream_footer','
            <div class="row">
                <div class="col-md-3 col-sm-4 allow-drop" style="height: auto;">
                    <module class="module module-logo" data-mw-title="Logo" id="footer-logo" template="footer" data-type="logo" parent-module="logo" parent-module-id="footer-logo"></module><p class="element element-over" id="element_1513251682706"><em>Mic CMS &amp; Website Builder</em></p>
                    <module class="module module-menu" data-mw-title="Menu" template="footer" name="footer_menu" id="footer_menu" data-type="menu" parent-module="menu" parent-module-id="footer_menu"></module>
</div>

                <div class="col-md-4 col-sm-8 allow-drop" style="height: auto;">
                    <h6 class=" element">Recent News</h6>
                    <module class=" module module-posts " data-mw-title="Posts List" template="skin-5" id="recent-news-14" limit="3" hide-paging="true" data-type="posts" parent-module="posts" parent-module-id="recent-news-14"></module>
</div>

                <div class="col-md-4 col-md-offset-1 col-sm-12 allow-drop" style="height: auto;">
                    <h6 class=" element">Subscribe</h6>
                    <p class=" element">Get monthly updates and free resources.</p>

                    <module class=" module module-newsletter " data-mw-title="Newsletter" id="footer-newsletter" data-type="newsletter" parent-module="newsletter" parent-module-id="footer-newsletter"></module><h6 class=" element">Connect with Us</h6>
                    <module class=" module module-social-links " data-mw-title="Social Links" id="socials" data-type="social_links" parent-module="social_links" parent-module-id="socials"></module>
</div>
            </div>
        ','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('80','2017-12-14 11:41:40','2017-12-14 11:41:40','1','1','global','0','dream_footer','
            <div class="row">
                <div class="col-md-3 col-sm-4 allow-drop" style="height: auto;">
                    <module class="module module-logo" data-mw-title="Logo" id="footer-logo" template="footer" data-type="logo" parent-module="logo" parent-module-id="footer-logo"></module><p class="element element-over" id="element_1513251682706"><em>Microweber CMS &amp; Website Builder</em></p>
                    <module class="module module-menu" data-mw-title="Menu" template="footer" name="footer_menu" id="footer_menu" data-type="menu" parent-module="menu" parent-module-id="footer_menu"></module>
</div>

                <div class="col-md-4 col-sm-8 allow-drop" style="height: auto;">
                    <h6 class=" element">Recent News</h6>
                    <module class=" module module-posts " data-mw-title="Posts List" template="skin-5" id="recent-news-14" limit="3" hide-paging="true" data-type="posts" parent-module="posts" parent-module-id="recent-news-14"></module>
</div>

                <div class="col-md-4 col-md-offset-1 col-sm-12 allow-drop" style="height: auto;">
                    <h6 class=" element">Subscribe</h6>
                    <p class=" element">Get monthly updates and free resources.</p>

                    <module class=" module module-newsletter " data-mw-title="Newsletter" id="footer-newsletter" data-type="newsletter" parent-module="newsletter" parent-module-id="footer-newsletter"></module><h6 class=" element">Connect with Us</h6>
                    <module class=" module module-social-links " data-mw-title="Social Links" id="socials" data-type="social_links" parent-module="social_links" parent-module-id="socials"></module>
</div>
            </div>
        ','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('81','2017-12-14 11:44:00','2017-12-14 11:44:00','1','1','content','1','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-1" data-mw-title="Layouts" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts currentDragMouseOver" id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module module-layouts" id="module-layouts-1--3" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--3"></module>
<module class=" module module-layouts " id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class=" module module-layouts " id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class=" module module-layouts " id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class=" module module-layouts " id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class=" module module-layouts " id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class=" module module-layouts " id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class=" module module-layouts " id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('82','2017-12-14 11:44:06','2017-12-14 11:44:06','1','1','content','1','dream_content','
    <module class="module module-layouts" id="module-layouts-1" data-mw-title="Layouts" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts currentDragMouseOver" id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class="module module-layouts" data-mw-title="Layouts" template="skin-1.php" data-type="layouts" id="layouts-201712141144005a326400320c1" parent-module="layouts" parent-module-id="layouts-201712141144005a326400320c1"></module>
<module class=" module module-layouts " id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module module-layouts" id="module-layouts-1--3" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--3"></module>
<module class=" module module-layouts " id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class=" module module-layouts " id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class=" module module-layouts " id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class=" module module-layouts " id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class=" module module-layouts " id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class=" module module-layouts " id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class=" module module-layouts " id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('83','2017-12-14 11:44:07','2017-12-14 11:44:07','1','1','module','1','layout-skin-1-layouts-201712141144005a326400320c1','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero1.jpg&rsquo;); top: 0px; transform: translate3d(0px, 350px, 0px);"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-6 text-right text-center-xs">
                <div class="allow-drop">
                    <p class="logo-text"><span id="fitty-layouts-201712141144005a326400320c1" class="safe-element">Dream.</span></p>
                </div>
            </div>
            <div class="col-sm-6 text-center-xs">
                <div class="allow-drop">
                    <p class="lead">
                        A beautiful collection of
                        <br> hand-crafted web components
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="modal-instance modal-video-1">
                    <div class="edit allow-drop" field="layout-skin-1-btn-layouts-201712141144005a326400320c1" rel="module">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-12 pos-absolute pos-bottom">
        <div class="row">
            <div class="col-sm-12 text-center">
                <module class=" module module-social-links " data-mw-title="Social Links" id="socials" data-type="social_links" parent-module-id="layouts-201712141144005a326400320c1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('84','2017-12-14 11:44:07','2017-12-14 11:44:07','1','1','module','1','layout-skin-1-btn-layouts-201712141144005a326400320c1','
                        <div class="element"></div>
                    ','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('85','2017-12-14 11:47:09','2017-12-14 11:47:09','1','1','content','17','dream_content','
            <module class="module module-layouts module-over" id="module-layouts-17" data-mw-title="Layouts" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17"></module>
<module class=" module module-layouts " id="module-layouts-17--1" data-mw-title="Layouts" template="skin-50" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--1"></module>
<module class=" module module-layouts " id="module-layouts-17--2" data-mw-title="Layouts" template="skin-47" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--2"></module>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('86','2017-12-14 11:47:09','2017-12-14 11:47:09','1','1','module','17','layout-skin-41-module-layouts-17','
<div class="background-image-holder background--bottom element" style="background-position: initial; opacity: 1;">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/hero16.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 text-center allow-drop" style="height: auto;">
                <h3>Development Process</h3>
                <p class="lead">Our rigorous process ensures your project is managed strategically and efficiently from initial conception through to final delivery and after-sales
                    support.</p>
            </div>
        </div>

    </div>

','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('87','2017-12-14 11:49:25','2017-12-14 11:49:25','1','1','content','18','dream_content','
            <module class="module module-layouts" id="module-layouts-18" data-mw-title="Layouts" template="skin-49" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-18"></module>
<module class="module module-layouts" id="module-layouts-18--1" data-mw-title="Layouts" template="skin-47" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-18--1"></module>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('88','2017-12-14 11:49:25','2017-12-14 11:49:25','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form module-over" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('89','2017-12-14 11:49:28','2017-12-14 11:49:28','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('90','2017-12-14 11:49:30','2017-12-14 11:49:30','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('91','2017-12-14 11:49:32','2017-12-14 11:49:32','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form module-over" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('92','2017-12-14 11:49:36','2017-12-14 11:49:36','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form module-over" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('93','2017-12-14 11:49:40','2017-12-14 11:49:40','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form module-over" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('94','2017-12-14 11:50:13','2017-12-14 11:50:13','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form module-over" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('95','2017-12-14 11:50:15','2017-12-14 11:50:15','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form module-over" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('96','2017-12-14 11:50:17','2017-12-14 11:50:17','1','1','module','18','layout-skin-47-module-layouts-18--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form module-over" id="module-layouts-18--1-contact-form" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-18--1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('97','2017-12-14 12:17:18','2017-12-14 12:17:18','1','1','content','1','dream_content','
    
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--2" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--5" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--6" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--7" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--8" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--10" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--11" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('98','2017-12-14 12:17:19','2017-12-14 12:17:19','1','1','module','1','layout-skin-1-module-layouts-1','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero1.jpg&rsquo;); top: 0px; transform: translate3d(0px, 150px, 0px); background-position: initial; opacity: 1;" data-gramm_id="8cf4b9c7-c495-f31f-2a52-a495ea2cee6b" data-gramm="true" spellcheck="false" data-gramm_editor="true"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-6 text-right text-center-xs" style="height: auto;" data-gramm_id="2fd5ed5e-fbe6-0ea2-9981-5e6fb28cfb7d" data-gramm="true" spellcheck="false" data-gramm_editor="true">
                <div class="allow-drop">
                    <p class="logo-text"><span id="fitty-module-layouts-1" class="safe-element">Dream.</span></p>
                </div>
            </div>
            <div class="col-sm-6 text-center-xs" style="height: auto;">
                <div class="allow-drop">
                    <p class="lead" data-gramm_id="f452f464-b1ed-ace8-8dcb-d654b5745d9e" data-gramm="true" spellcheck="false" data-gramm_editor="true">
                        A beautiful collection of
                        <br> hand-craf<i class="mw-icon mw-icon-mw"></i>ted web components
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 text-center" style="height: auto;" data-gramm_id="f805e04d-792c-32ea-4674-5d9ab1c68e45" data-gramm="true" spellcheck="false" data-gramm_editor="true">
                <div class="modal-instance modal-video-1">
                    <module class="module module-btn" id="module-layouts-1-btn--1" data-mw-title="Button" text="Watch video" data-type="btn" parent-module-id="module-layouts-1" parent-module="layouts"></module>
</div>
            </div>
        </div>
    </div>

    <div class="col-sm-12 pos-absolute pos-bottom">
        <div class="row">
            <div class="col-sm-12 text-center" style="height: auto;">
                <module class="module module-social-links" data-mw-title="Social Links" id="socials" data-type="social_links" parent-module-id="module-layouts-1" parent-module="layouts"></module>
</div>
        </div>
    </div>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('99','2017-12-14 12:17:19','2017-12-14 12:17:19','1','1','module','1','layout-skin-32-module-layouts-1--1','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2 text-center allow-drop" style="height: auto;">
                <h3 data-gramm_id="46de8a90-5aa5-f49f-4324-cd301b4096b9" data-gramm="true" spellcheck="false" data-gramm_editor="true">Your Creative Collective</h3>
                <p class="lead" data-gramm_id="dda6cb70-c43f-82cb-fc5b-572e43736731" data-gramm="true" spellcheck="false" data-gramm_editor="true">
                    Our diverse team comprises talen<i class="mw-icon mw-icon-mw"></i>t from a range of design disciplines working together to deliver effective solutions
                </p>
            </div>
        </div>

    </div>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','home'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('100','2017-12-14 12:21:26','2017-12-14 12:21:26','1','1','content','8','dream_content','
    
    <module class="module  module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-8" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-8"></module>
<section class="masonry-contained element" id="element_1512128656367"><div class="container">
            <div class="row">
                <div class="masonry-shop element" id="element_1513253159157">
                    <module class="module module-categories" data-mw-title="Categories" id="module-categories-8" content-id="8" data-type="categories" parent-module="categories" parent-module-id="module-categories-8"></module>
<module class="module module-shop-products" data-mw-title="Products" id="module-shop-products-8" limit="18" description-length="70" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-8"></module>
</div>
            </div>
        </div>
    </section>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('101','2017-12-14 12:21:27','2017-12-14 12:21:27','1','1','module','8','layout-skin-68-module-layouts-8','
<div class="container pos-vertical-center">
        <div class="row allow-drop">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1 class="element allow-drop" id="element_1512128656517" data-gramm_id="e730225a-5ec1-b25e-54cb-f6af4ff8af34" data-gramm="true" spellcheck="false" data-gramm_editor="true">Shop 1</h1>
                <p class="lead" data-gramm_id="fe2d032c-0aa7-250b-c5bd-977f28b817b9" data-gramm="true" spellcheck="false" data-gramm_editor="true">Showcase blog posts in a classic<i class="mw-icon mw-icon-mw"></i> column arrangement</p>
            </div>
        </div>
    </div>


','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('102','2017-12-14 12:35:52','2017-12-14 12:35:52','1','1','content','29','title','Product name','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','dave-wool-beanie'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('103','2017-12-14 12:54:44','2017-12-14 12:54:44','1','1','content','29','product_sheets','
                            
                            <div class="item__subinfo cloneable element" id="element_1513254969421">
                                <span class="safe-element">Origin</span>
                                <span class="safe-element">Handmade in Aus</span>
                            </div>
<div class="item__subinfo cloneable element element-over" id="element_1513254969289">
                                <span class="safe-element">Fabric</span>
                                <span class="safe-element">100% Cotton</span>
                            </div>
                            <div class="item__subinfo cloneable element" id="element_1513254969483">
                                <span class="safe-element">Weight</span>
                                <span class="safe-element">280gm - 340gm</span>
                            </div>
                            <div class="item__subinfo cloneable element" id="element_1513254969469">
                                <span class="safe-element">Sizes</span>
                                <span class="safe-element">S,M,L,XL</span>
                            </div>
                        ','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','dave-wool-beanie'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('104','2017-12-14 12:54:45','2017-12-14 12:54:45','1','1','content','29','product_sheets','
                            
                            <div class="item__subinfo cloneable element" id="element_1513254969421">
                                <span class="safe-element">Origin</span>
                                <span class="safe-element">Handmade in Aus</span>
                            </div>
<div class="item__subinfo cloneable element element-over" id="element_1513254969289">
                                <span class="safe-element">Fabric</span>
                                <span class="safe-element">100% Cotton </span>
</div>
                            <div class="item__subinfo cloneable element" id="element_1513254969483">
                                <span class="safe-element">Weight</span>
                                <span class="safe-element">280gm - 340gm</span>
                            </div>
                            <div class="item__subinfo cloneable element" id="element_1513254969469">
                                <span class="safe-element">Sizes</span>
                                <span class="safe-element">S,M,L,XL</span>
                            </div>
                        ','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','dave-wool-beanie'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('105','2017-12-14 12:58:42','2017-12-14 12:58:42','1','1','content','17','dream_content','
            
            <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-17" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17"></module>
<module class="module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-17--1" template="skin-50" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--1"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-17--2" template="skin-47" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--2"></module>

','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','contacts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('106','2017-12-14 12:58:42','2017-12-14 12:58:42','1','1','module','17','layout-skin-50-module-layouts-17--1','
<div class="feature bg--white col-md-4 text-center allow-drop cloneable">
        <i class="icon icon--lg icon-Map-Marker2 safe-element"></i>
        <h4>Drop on in</h4>
        <p>
            Suite 203, Level 4
            <br> 124 Koornang Road
            <br> Carnegie, Victoria 3183
        </p>
    </div>
    <div class="feature bg--secondary col-md-4 text-center allow-drop cloneable">
        <i class="icon icon--lg icon-Phone-2 safe-element">‌ </i>
        <h4>Give us a call</h4>
        <p>
            Office: (03) 9283 2617
            <br> Fax: +61 3827 3590
        </p>
    </div>
    <div class="feature bg--dark col-md-4 text-center allow-drop cloneable">
        <i class="icon icon--lg icon-Computer safe-element"></i>
        <h4>Connect online</h4>
        <p>
            Email:
            <a href="#">hello@microweber.com</a>
            <br> Twitter:
            <a href="#">@microweber</a>
        </p>
    </div>
','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf','','contacts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('107','2017-12-14 13:23:44','2017-12-14 13:23:44','1','1','content','17','dream_content','
            
            <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-17" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-17--1" template="skin-50" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--1"></module>
<module class="module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-17--2" template="skin-47" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--2"></module>

','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('108','2017-12-14 13:23:45','2017-12-14 13:23:45','1','1','module','17','layout-skin-47-module-layouts-17--2','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form" id="module-layouts-17--2-contact-form--1" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-17--2" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('109','2017-12-14 13:23:50','2017-12-14 13:23:50','1','1','module','17','layout-skin-47-module-layouts-17--2','
<div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" style="height: auto;">
                <module class="module module-contact-form" id="module-layouts-17--2-contact-form--1" data-mw-title="Contact form" data-type="contact_form" parent-module-id="module-layouts-17--2" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','contacts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('110','2017-12-14 15:24:40','2017-12-14 15:24:40','1','1','content','32','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-32" data-mw-title="Layouts" template="skin-42" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-32"></module>
<section class="wide-grid masonry masonry-shop element"><module class="module module-categories" id="module-categories-32" data-mw-title="Categories" content_id="32" data-type="categories" parent-module="categories" parent-module-id="module-categories-32"></module>
<module class="module module-shop-products" id="module-shop-products-32" data-mw-title="Products" limit="18" description-length="70" template="skin-3" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-32"></module>
<div class="clearfix element"><p class="element"></p></div>
    </section>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','shop4-1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('111','2017-12-14 15:24:41','2017-12-14 15:24:41','1','1','module','32','layout-skin-42-module-layouts-32','
<div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/header_ttd_shopping_bbac913b-c0ee-4569-84a6-2d44857c018a.jpg&rsquo;); background-position: initial; opacity: 1;"></div>

    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-12 text-center allow-drop" style="height: auto;">
                <h1>Image Showcase</h1>
                <p class="lead">Showcase a gallery of images with lightbox capability</p>
            </div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','shop4-1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('112','2017-12-14 16:38:19','2017-12-14 16:38:19','1','1','content','1','dream_content','
    <module class="module module-layouts" id="module-layouts-1" data-mw-title="Layouts" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts module-over" id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module module-layouts mwfadeout" id="module-layouts-1--3" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--3"></module>
<module class="module module-layouts" id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class=" module module-layouts " id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class=" module module-layouts " id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class=" module module-layouts " id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class=" module module-layouts " id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class=" module module-layouts " id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class=" module module-layouts " id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('113','2017-12-14 16:42:46','2017-12-14 16:42:46','1','1','content','2','dream_content','
    <module class="module module-layouts" id="module-layouts-2" data-mw-title="Layouts" template="skin-10" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-2"></module>
<module class="module module-layouts" id="module-layouts-2--1" data-mw-title="Layouts" template="skin-11" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-2--1"></module>
<module class="module module-layouts module-over" id="module-layouts-2--2" data-mw-title="Layouts" template="skin-12" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-2--2"></module>
<module class=" module module-layouts " id="module-layouts-2--3" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-2--3"></module>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','home-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('114','2017-12-14 16:42:46','2017-12-14 16:42:46','1','1','module','2','layout-skin-12-module-layouts-2--2','
<div class="imageblock__content col-md-6 col-sm-4 pos-right">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero29.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-8 allow-drop" style="height: auto;">
                <h3>Assemble pages with over a lot of content blocks</h3>
                <p>
                    Dream combines smart, modern styling with all the features you’ll need to launch websites of alialmost any kind. Achieve results faster than ever with the included Microweber CMS &amp; Website Builder.
                </p>

                <module class=" module module-btn " id="module-layouts-2--2-btn" data-mw-title="Button" template="bootstrap" text="Click Here" button_style="btn-simple" data-type="btn" parent-module-id="module-layouts-2--2" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','home-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('115','2017-12-14 16:42:50','2017-12-14 16:42:50','1','1','module','2','layout-skin-12-module-layouts-2--2','
<div class="imageblock__content col-md-6 col-sm-4 pos-right">
        <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/dream/assets/img/hero29.jpg&rsquo;); background-position: initial; opacity: 1;"></div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-8 allow-drop" style="height: auto;">
                <h3>Assemble pages with over a lot of content blocks</h3>
                <p>
                    Dream combines smart, modern styling with all the features you’ll need to launch websites of ali almost any kind. Achieve results faster than ever with the included Microweber CMS &amp; Website Builder.
                </p>

                <module class=" module module-btn " id="module-layouts-2--2-btn" data-mw-title="Button" template="bootstrap" text="Click Here" button_style="btn-simple" data-type="btn" parent-module-id="module-layouts-2--2" parent-module="layouts"></module>
</div>
        </div>
    </div>
','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','home-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('116','2017-12-15 11:48:08','2017-12-15 11:48:08','1','1','content','8','dream_content','
    
    <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-8" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-8"></module>
<section class="masonry-contained element element-over" id="element_1512128656367"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class=" module module-categories " data-mw-title="Categories" id="module-categories-8" content-id="8" data-type="categories" parent-module="categories" parent-module-id="module-categories-8"></module>
<module class="module module-shop-products" data-mw-title="Products" id="module-shop-products-8" limit="18" description-length="70" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-8"></module>
</div>
            </div>
        </div>
    </section>
','Bo45kHkVP4s3fGaeD6FtVrG4VyINt79GVvjD4GlA','','shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields_drafts (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value,session_id,is_temp,url) VALUES('117','2017-12-15 12:00:26','2017-12-15 12:00:26','2','2','content','31','product_sheets','
                            <div class="item__subinfo cloneable element" id="element_1513339198929">
                                <span class="safe-element">Fabric</span>
                                <span class="safe-element">100% Cotton</span>
                            </div>
                            <div class="item__subinfo cloneable element" id="element_1513339198785">
                                <span class="safe-element">Origin</span>
                                <span class="safe-element">Handmade in Aus</span>
                            </div>
                            <div class="item__subinfo cloneable element" id="element_1513339198670">
                                <span class="safe-element">Weight</span>
                                <span class="safe-element">280gm - 340gm</span>
                            </div>
                            
                        ','VyL9Ls2wBvdWCTOPiyMxy6GX2q0BIEBJRdVyWT5y','','charles-leather-bag'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */media" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "session_id" varchar null, "rel_type" varchar null, "rel_id" varchar null, "media_type" text null, "position" integer null, "title" text null, "description" text null, "embed_code" text null, "filename" text null, "image_options" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('1','2017-11-28 15:34:09','2017-11-28 15:34:09','1','1','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','modules','module-layouts-3--7-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner6.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('2','2017-11-28 15:34:10','2017-11-28 15:34:10','1','1','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','modules','module-layouts-3--7-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner7.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('3','2017-11-28 15:34:10','2017-11-28 15:34:10','1','1','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','modules','module-layouts-3--7-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner4.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('4','2017-11-28 15:34:08','2017-11-28 15:34:08','1','1','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','modules','module-layouts-3--7-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('5','2017-11-28 15:34:10','2017-11-28 15:34:10','1','1','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','modules','module-layouts-3--7-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner5.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('6','2017-11-28 15:34:11','2017-11-28 15:34:11','1','1','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','modules','module-layouts-3--7-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner3.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('7','2017-11-28 15:34:11','2017-11-28 15:34:11','1','1','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p','modules','module-layouts-3--7-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('8','2017-12-01 11:19:38','2017-12-01 11:19:38','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-1--10-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner1_1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('9','2017-12-01 11:19:44','2017-12-01 11:19:44','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-1--10-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner2_1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('10','2017-12-01 11:19:45','2017-12-01 11:19:45','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-1--10-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner3_1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('11','2017-12-01 11:19:49','2017-12-01 11:19:49','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-1--10-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner4_1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('12','2017-12-01 11:19:51','2017-12-01 11:19:51','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-1--10-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner5_1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('13','2017-12-01 11:19:54','2017-12-01 11:19:54','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-1--10-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner6_1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('14','2017-12-01 11:19:54','2017-12-01 11:19:54','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-1--10-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner7_1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('18','2017-12-01 11:29:07','2017-12-01 11:29:07','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','19','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/31-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('19','2017-12-01 11:29:08','2017-12-01 11:29:08','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','19','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/32-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('20','2017-12-01 11:29:12','2017-12-01 11:29:12','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','19','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/33-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('21','2017-12-01 11:29:13','2017-12-01 11:29:13','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','19','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/34-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('22','2017-12-01 11:35:49','2017-12-01 11:35:49','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','20','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/25-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('28','2017-12-01 11:38:55','2017-12-01 11:38:55','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','23','picture','','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/25-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('29','2017-12-01 11:39:21','2017-12-01 11:39:21','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','21','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/1-min_2.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('30','2017-12-01 11:39:23','2017-12-01 11:39:23','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','21','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/2-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('31','2017-12-01 11:40:08','2017-12-01 11:40:08','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','22','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/14-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('32','2017-12-01 11:40:09','2017-12-01 11:40:09','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','22','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/21-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('33','2017-12-01 11:40:12','2017-12-01 11:40:12','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','22','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/28-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('34','2017-12-01 11:40:50','2017-12-01 11:40:50','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','23','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/6-min_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('35','2017-12-01 11:40:52','2017-12-01 11:40:52','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','23','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/10-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('36','2017-12-01 11:40:54','2017-12-01 11:40:54','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','23','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/22-min.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('37','2017-12-01 11:51:07','2017-12-01 11:51:07','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-2--3-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner2_2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('38','2017-12-01 11:51:08','2017-12-01 11:51:08','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-2--3-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner3_2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('39','2017-12-01 11:51:12','2017-12-01 11:51:12','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-2--3-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner5_2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('40','2017-12-01 11:51:13','2017-12-01 11:51:13','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-2--3-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner7_2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('41','2017-12-01 11:50:59','2017-12-01 11:50:59','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-2--3-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner1_2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('42','2017-12-01 11:51:12','2017-12-01 11:51:12','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-2--3-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner4_2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('43','2017-12-01 11:51:16','2017-12-01 11:51:16','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','modules','module-layouts-2--3-pictures','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner6_2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('44','2017-12-01 12:50:40','2017-12-01 12:50:40','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','24','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-large-11.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('45','2017-12-01 12:51:01','2017-12-01 12:51:01','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','edit-post-gallery-main','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-large-3.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('46','2017-12-01 12:52:03','2017-12-01 12:52:03','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','25','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-large-9.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('47','2017-12-01 12:53:37','2017-12-01 12:53:37','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-large-12.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('48','2017-12-01 12:53:37','2017-12-01 12:53:37','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-large-6.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('49','2017-12-01 12:53:40','2017-12-01 12:53:40','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','26','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-small-2.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('50','2017-12-01 12:54:19','2017-12-01 12:54:19','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-large-7.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('51','2017-12-01 12:54:45','2017-12-01 12:54:45','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','27','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-large-7_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('52','2017-12-01 12:55:46','2017-12-01 12:55:46','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','28','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-large-4.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('53','2017-12-01 12:57:28','2017-12-01 12:57:28','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','29','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-small-1.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('54','2017-12-01 12:58:36','2017-12-01 12:58:36','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-single-1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('55','2017-12-01 12:58:38','2017-12-01 12:58:38','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-single-3.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('56','2017-12-01 12:58:39','2017-12-01 12:58:39','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','content','30','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/product-single-2.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('60','2017-12-14 11:16:50','2017-12-14 11:16:50','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','content','31','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/tn-b71c0e79817c56b30702a99e78cca594_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('61','2017-12-14 11:17:56','2017-12-14 11:17:56','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','content','31','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/tn-0c1825e1a65aa3303d04a2c87a7cd292.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('72','2017-12-14 16:48:56','2017-12-14 16:48:56','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','modules','module-layouts-1--10-pictures--1','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner3_5.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('73','2017-12-14 16:48:59','2017-12-14 16:48:59','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','modules','module-layouts-1--10-pictures--1','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner5_5.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('74','2017-12-14 16:48:59','2017-12-14 16:48:59','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','modules','module-layouts-1--10-pictures--1','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner2_5.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('75','2017-12-14 16:48:59','2017-12-14 16:48:59','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','modules','module-layouts-1--10-pictures--1','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner7_5.png',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('76','2017-12-14 16:48:59','2017-12-14 16:48:59','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','modules','module-layouts-1--10-pictures--1','picture','9999999','','','','{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/partner6_5.png',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */custom_fields" ("id" integer not null primary key autoincrement, "rel_type" varchar null, "rel_id" text null, "position" integer null, "type" varchar null, "name" text null, "name_key" text null, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "session_id" varchar null, "options" text null, "is_active" integer null, "required" integer null, "copy_of_field" integer null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('1','content','24','','price','price','price','2017-12-01 12:50:00','2017-12-01 12:49:53','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('2','content','25','','price','price','price','2017-12-01 12:51:53','2017-12-01 12:51:44','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('3','content','26','','price','price','price','2017-12-01 12:52:42','2017-12-01 12:52:37','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('4','content','27','','price','price','price','2017-12-01 12:53:44','2017-12-01 12:53:39','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('5','content','28','','price','price','price','2017-12-01 12:55:33','2017-12-01 12:55:22','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('6','content','29','','price','price','price','2017-12-01 12:56:53','2017-12-01 12:56:43','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('7','content','30','','price','price','price','2017-12-01 12:58:20','2017-12-01 12:58:11','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('8','content','31','','price','price','price','2017-12-01 12:59:52','2017-12-01 12:59:25','1','1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('9','module','module-layouts-18--1-contact-form','','text','text3','text3','2017-12-14 11:48:24','2017-12-14 11:48:15','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('10','module','module-layouts-18--1-contact-form','','dropdown','AZazaZ','azazaz','2017-12-14 11:48:44','2017-12-14 11:48:30','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('11','content','30','','dropdown','Selector','selector','2017-12-14 12:03:34','2017-12-14 12:01:58','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('12','content','30','','checkbox','checkbox','checkbox','2017-12-14 12:02:28','2017-12-14 12:02:17','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('13','content','30','','radio','radio','radio','2017-12-14 12:03:08','2017-12-14 12:02:48','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('14','content','31','','text','text','text','2017-12-15 12:01:23','2017-12-14 13:03:37','1','2','VyL9Ls2wBvdWCTOPiyMxy6GX2q0BIEBJRdVyWT5y','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('15','content','31','','radio','radio','radio','2017-12-14 13:04:00','2017-12-14 13:03:48','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('16','content','31','','dropdown','dropdown','dropdown','2017-12-14 13:04:12','2017-12-14 13:04:02','1','1','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('17','content','27','','text','Size','size','2017-12-15 11:48:54','2017-12-15 11:48:44','1','1','Bo45kHkVP4s3fGaeD6FtVrG4VyINt79GVvjD4GlA','','1','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */custom_fields_values" ("id" integer not null primary key autoincrement, "custom_field_id" integer null, "value" text null, "position" integer null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('1','1','34','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('2','2','87','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('3','3','11','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('4','4','57','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('5','5','55','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('6','6','12','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('7','7','39','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('8','8','78','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('9','10','1','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('10','10','1','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('11','11','1','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('12','11','2','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('13','11','3','2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('14','12','s','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('15','12','m','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('16','13','YER','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('17','13','NO','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('18','14','Leave a comment','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('19','15','2','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('20','15','3','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('21','15','4','2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('22','16','3','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('23','16','1','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('24','16','43','2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('25','17','46','0'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */menus" ("id" integer not null primary key autoincrement, "title" text null, "item_type" varchar null, "parent_id" integer null, "content_id" integer null, "categories_id" integer null, "position" integer null, "updated_at" datetime null, "created_at" datetime null, "is_active" integer null, "auto_populate" varchar null, "description" text null, "url" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('1','header_menu','menu','','','','','2017-11-28 08:39:26','2017-11-28 08:39:26','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('2','','menu_item','1','1','','0','2017-11-28 08:39:26','2017-11-28 08:39:26','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('3','footer_menu','menu','','','','','2017-11-28 08:39:26','2017-11-28 08:39:26','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('5','Home Corporate','menu_item','2','2','','2','2017-11-28 14:39:26','2017-11-28 14:38:02','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('6','Home Agency','menu_item','2','3','','3','2017-11-28 14:39:46','2017-11-28 14:38:05','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('7','Home Split Cover','menu_item','2','4','','4','2017-11-28 14:40:01','2017-11-28 14:38:07','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('8','Home Classic','menu_item','2','1','','1','2017-11-28 14:39:05','2017-11-28 14:38:09','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('9','','menu_item','1','','','99999','2017-11-28 14:38:20','2017-11-28 14:38:20','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('10','','menu_item','1','','','99999','2017-11-28 14:38:24','2017-11-28 14:38:24','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('11','','menu_item','1','5','','5','2017-12-01 10:52:10','2017-12-01 10:52:10','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('12','Blog Simple','menu_item','11','6','','7','2017-12-01 11:44:08','2017-12-01 10:52:14','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('13','Blog Cards','menu_item','11','7','','8','2017-12-01 11:00:23','2017-12-01 10:52:18','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('14','','menu_item','1','','','99999','2017-12-01 10:52:25','2017-12-01 10:52:25','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('16','','menu_item','1','','','99999','2017-12-01 10:52:53','2017-12-01 10:52:53','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('17','','menu_item','1','8','','9','2017-12-01 10:53:18','2017-12-01 10:53:18','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('18','','menu_item','17','9','','11','2017-12-01 10:53:22','2017-12-01 10:53:22','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('19','','menu_item','17','10','','12','2017-12-01 10:53:27','2017-12-01 10:53:27','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('20','','menu_item','17','11','','13','2017-12-01 10:53:31','2017-12-01 10:53:31','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('21','','menu_item','1','','','99999','2017-12-01 10:53:41','2017-12-01 10:53:41','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('22','','menu_item','1','','','99999','2017-12-01 10:54:18','2017-12-01 10:54:18','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('23','','menu_item','1','','','99999','2017-12-01 10:54:30','2017-12-01 10:54:30','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('24','Blog Sidebar','menu_item','11','5','','6','2017-12-01 10:59:59','2017-12-01 10:56:18','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('25','Shop 1','menu_item','17','8','','10','2017-12-01 10:57:27','2017-12-01 10:56:18','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('26','','menu_item','1','12','','14','2017-12-01 10:57:47','2017-12-01 10:57:47','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('27','Services Boxes','menu_item','26','13','','16','2017-12-01 11:01:38','2017-12-01 10:57:52','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('28','','menu_item','1','','','99999','2017-12-01 10:57:55','2017-12-01 10:57:55','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('29','Services Cards','menu_item','26','12','','15','2017-12-01 11:01:32','2017-12-01 10:58:24','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('30','','menu_item','1','14','','17','2017-12-01 11:13:27','2017-12-01 11:13:27','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('31','','menu_item','1','15','','18','2017-12-01 11:13:30','2017-12-01 11:13:30','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('32','','menu_item','1','16','','19','2017-12-01 11:13:32','2017-12-01 11:13:32','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('33','Contacts Sample','menu_item','36','17','','21','2017-12-01 11:14:24','2017-12-01 11:13:36','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('34','Contacts with Map','menu_item','36','18','','22','2017-12-01 11:14:12','2017-12-01 11:13:39','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('35','','menu_item','1','','','99999','2017-12-01 11:13:42','2017-12-01 11:13:42','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('36','','menu_item','1','17','','20','2017-12-01 11:14:45','2017-12-01 11:14:45','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('37','Home 1','menu_item','3','1','','0','2017-12-01 11:57:48','2017-12-01 11:57:20','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('38','','menu_item','3','2','','1','2017-12-01 11:57:23','2017-12-01 11:57:23','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('39','','menu_item','3','4','','2','2017-12-01 11:57:23','2017-12-01 11:57:23','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('40','','menu_item','3','6','','4','2017-12-01 11:57:31','2017-12-01 11:57:31','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('41','Blog 1','menu_item','3','5','','3','2017-12-01 11:57:44','2017-12-01 11:57:31','','','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */categories" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "data_type" varchar null, "title" text null, "url" text null, "parent_id" integer null, "description" text null, "content" text null, "rel_type" varchar null, "rel_id" integer null, "position" integer null, "is_deleted" integer null default '0', "is_hidden" integer null default '0', "users_can_create_subcategories" integer null, "users_can_create_content" integer null, "users_can_create_content_allowed_usergroups" varchar null, "category_subtype" varchar null, "category_subtype_settings" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('1','2017-12-01 11:24:55','2017-12-01 11:23:24','1','1','category','B1 Category 1','category-1','0','','','content','5','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('2','2017-12-01 11:25:01','2017-12-01 11:23:37','1','1','category','B1 Category 2','category-2','0','','','content','5','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('3','2017-12-01 11:25:05','2017-12-01 11:23:45','1','1','category','B1 Category 3','category-3','0','','','content','5','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('4','2017-12-01 11:25:13','2017-12-01 11:23:54','1','1','category','B2 Category 1','category-1-20171201112354','0','','','content','6','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('5','2017-12-01 11:25:18','2017-12-01 11:24:03','1','1','category','B2 Category 2','category-2-20171201112403','0','','','content','6','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('6','2017-12-01 11:25:23','2017-12-01 11:24:15','1','1','category','B2 Category 3','category-3-20171201112415','0','','','content','6','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('7','2017-12-01 11:25:32','2017-12-01 11:24:23','1','1','category','B3 Category 1','category-1-20171201112423','0','','','content','7','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('8','2017-12-01 11:25:38','2017-12-01 11:24:30','1','1','category','B3 Category 2','category-2-20171201112430','0','','','content','7','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('9','2017-12-01 11:25:45','2017-12-01 11:24:37','1','1','category','B3 Category 3','category-3-20171201112437','0','','','content','7','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('10','2017-12-01 11:29:42','2017-12-01 11:29:42','1','1','category','S1 Cat 1','s1-cat-1','0','','','content','8','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('11','2017-12-01 11:29:51','2017-12-01 11:29:51','1','1','category','S1 Cat 2','s1-cat-2','0','','','content','8','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('12','2017-12-01 11:30:00','2017-12-01 11:30:00','1','1','category','S2 Cat 1','s2-cat-1','0','','','content','9','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('13','2017-12-01 11:30:08','2017-12-01 11:30:08','1','1','category','S2 Cat 2','s2-cat-2','0','','','content','9','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('14','2017-12-01 11:30:26','2017-12-01 11:30:26','1','1','category','S3 Cat 1','s3-cat-1','0','','','content','10','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('15','2017-12-01 11:30:33','2017-12-01 11:30:33','1','1','category','S3 Cat 2','s3-cat-2','0','','','content','10','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('16','2017-12-01 11:30:41','2017-12-01 11:30:41','1','1','category','S4 Cat 1','s4-cat-1','0','','','content','11','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_subtype,category_subtype_settings) VALUES('17','2017-12-01 11:30:48','2017-12-01 11:30:48','1','1','category','S4 Cat 2','s4-cat-2','0','','','content','11','0','0','0','','0','','default',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */categories_items" ("id" integer not null primary key autoincrement, "parent_id" integer null, "rel_type" varchar null, "rel_id" integer null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('1','1','content','19'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('2','3','content','19'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('3','4','content','19'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('4','6','content','19'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('5','7','content','19'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('6','9','content','19'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('7','2','content','20'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('8','5','content','20'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('9','8','content','20'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('10','2','content','21'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('11','5','content','21'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('12','8','content','21'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('13','1','content','22'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('14','3','content','22'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('15','4','content','22'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('16','6','content','22'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('17','7','content','22'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('18','9','content','22'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('19','2','content','23'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('20','5','content','23'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('21','8','content','23'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('22','10','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('23','12','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('24','14','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('25','16','content','24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('26','11','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('27','13','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('28','15','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('29','17','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('30','10','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('31','11','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('32','12','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('33','13','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('34','14','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('35','15','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('36','16','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('37','17','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('38','11','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('39','13','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('40','15','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('41','17','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('42','17','content','28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('43','10','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('44','13','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('45','14','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('46','17','content','29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('47','11','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('48','12','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('49','15','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('50','16','content','30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('51','10','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('52','13','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('53','14','content','31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('54','17','content','31'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */forms_data" ("id" integer not null primary key autoincrement, "created_at" datetime null, "created_by" integer null, "rel_type" varchar null, "rel_id" varchar null, "list_id" integer null, "form_values" text null, "module_name" varchar null, "url" varchar null, "user_ip" varchar null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */forms_data (id,created_at,created_by,rel_type,rel_id,list_id,form_values,module_name,url,user_ip) VALUES('1','2017-12-14 11:49:39','1','contact_form','contact_form','0','{"for":"contact_form","for_id":"contact_form","first_name":"SDVSDCVS","email":"SDCSDCSD@DSDS.COM","phone":"SDCSDCSDC","message":"SDCSDCSD","module_name":"contact_form"}','contact_form','','94.26.57.98'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */forms_lists" ("id" integer not null primary key autoincrement, "created_at" datetime null, "created_by" integer null, "title" varchar null, "description" text null, "custom_data" text null, "module_name" varchar null, "last_export" datetime null, "last_sent" datetime null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */options" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "option_key" varchar null, "option_value" text null, "option_key2" varchar null, "option_value2" text null, "position" integer null, "option_group" varchar null, "name" varchar null, "help" varchar null, "field_type" varchar null, "field_values" varchar null, "module" varchar null, "is_system" integer null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('1','2017-11-28 08:39:25','2017-11-28 08:39:25','current_template','dream','','','','template','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('2','2017-11-28 08:39:27','2017-11-28 08:39:27','website_title','Microweber','','','','website','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('3','','','enable_comments','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('4','','','shipping_gw_shop/shipping/gateways/country','y','','','','shipping','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('5','','','payment_gw_shop/payments/gateways/paypal','1','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('6','','','currency','USD','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('7','2017-11-28 14:14:55','2017-11-28 14:14:55','logotype','text','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('8','2017-11-28 14:14:56','2017-11-28 14:14:56','text','Dream','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('9','2017-11-28 14:40:59','2017-11-28 14:40:53','settings','{"0":{"primaryText":"My bxSlider","secondaryText":"Your slogan here","seemoreText":"See more","url":"","skin":"default","images":"{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/1-min.jpg"},"1":{"primaryText":"","secondaryText":"","seemoreText":"","url":"","skin":"","images":"{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/15-min.jpg"}}','','','','module-bxslider-3','','','','','bxslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('10','2017-11-28 15:07:15','2017-11-28 14:53:41','file','[{"skill":"Design","percent":"78","style":"primary"},{"skill":"PHP / MySQL","percent":"45","style":"warning"},{"skill":"CSS / HTML","percent":"21","style":"danger"},{"skill":"JAVASCRIPT","percent":"84","style":"info"}]','','','','module-layouts-3--1-skills','','','','','skills',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('11','2017-11-28 15:33:17','2017-11-28 15:09:48','padding','space-bottom--sm','','','','module-layouts-3--1','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('12','2017-11-28 15:12:40','2017-11-28 15:11:48','settings','{"0":{"name":"Melissa Doe","role":"Marketing","bio":"","file":"{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/1-min_1.jpg"},"1":{"name":"Jessica Doe","role":"Designer","bio":"","file":"{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/12-min.jpg"},"2":{"name":"John Doe","role":"CEO","bio":"","file":"{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/a-min.jpg"},"3":{"name":"Larissa Doe","role":"Developer","bio":"","file":"{SITE_URL}userfiles/media/dream-template-microweber-com/uploaded/6-min.jpg"}}','','','','module-layouts-3--2-teamcard','','','','','teamcard',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('13','2017-11-28 15:12:52','2017-11-28 15:12:52','facebook_enabled','y','','','','team_card_module-layouts-3--2-teamcard_ea99f3d9bcb975e64977a672eb8665fd','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('14','2017-11-28 15:12:53','2017-11-28 15:12:53','googleplus_enabled','y','','','','team_card_module-layouts-3--2-teamcard_ea99f3d9bcb975e64977a672eb8665fd','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('15','2017-11-28 15:12:54','2017-11-28 15:12:54','twitter_enabled','y','','','','team_card_module-layouts-3--2-teamcard_ea99f3d9bcb975e64977a672eb8665fd','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('16','2017-11-28 15:12:55','2017-11-28 15:12:55','pinterest_enabled','y','','','','team_card_module-layouts-3--2-teamcard_ea99f3d9bcb975e64977a672eb8665fd','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('17','2017-11-28 15:13:05','2017-11-28 15:13:05','instagram_enabled','y','','','','team_card_module-layouts-3--2-teamcard_7a655d60f1aa756a3f8e88144f364849','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('18','2017-11-28 15:13:06','2017-11-28 15:13:06','linkedin_enabled','y','','','','team_card_module-layouts-3--2-teamcard_7a655d60f1aa756a3f8e88144f364849','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('19','2017-11-28 15:13:07','2017-11-28 15:13:07','youtube_enabled','y','','','','team_card_module-layouts-3--2-teamcard_7a655d60f1aa756a3f8e88144f364849','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('20','2017-11-28 15:13:12','2017-11-28 15:13:12','googleplus_enabled','y','','','','team_card_module-layouts-3--2-teamcard_4c2a904bafba06591225113ad17b5cec','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('21','2017-11-28 15:13:12','2017-11-28 15:13:12','pinterest_enabled','y','','','','team_card_module-layouts-3--2-teamcard_4c2a904bafba06591225113ad17b5cec','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('22','2017-11-28 15:13:16','2017-11-28 15:13:16','youtube_enabled','y','','','','team_card_module-layouts-3--2-teamcard_4c2a904bafba06591225113ad17b5cec','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('23','2017-11-28 15:13:22','2017-11-28 15:13:22','facebook_enabled','y','','','','team_card_module-layouts-3--2-teamcard_142dbf7f26cc32b3e0ddf95dd7a6b6eb','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('24','2017-11-28 15:13:22','2017-11-28 15:13:22','twitter_enabled','y','','','','team_card_module-layouts-3--2-teamcard_142dbf7f26cc32b3e0ddf95dd7a6b6eb','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('25','2017-11-28 15:13:24','2017-11-28 15:13:24','pinterest_enabled','y','','','','team_card_module-layouts-3--2-teamcard_142dbf7f26cc32b3e0ddf95dd7a6b6eb','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('26','2017-11-28 15:13:25','2017-11-28 15:13:25','googleplus_enabled','y','','','','team_card_module-layouts-3--2-teamcard_142dbf7f26cc32b3e0ddf95dd7a6b6eb','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('27','2017-11-28 15:13:38','2017-11-28 15:13:38','linkedin_enabled','y','','','','team_card_module-layouts-3--2-teamcard_4c2a904bafba06591225113ad17b5cec','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('28','2017-12-01 11:52:13','2017-11-28 15:35:17','padding','space--sm','','','','module-layouts-3--7','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('29','2017-11-28 15:35:38','2017-11-28 15:35:28','padding','space--sm','','','','module-layouts-3--8','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('30','2017-11-28 15:51:23','2017-11-28 15:37:49','overlay','','','','','module-layouts-1','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('31','2017-11-30 12:25:42','2017-11-30 12:25:19','youtube','qRaYWfxWq9M','','','','layouts-201711301224595a1ff89b0d72b','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('32','2017-12-01 11:26:35','2017-12-01 11:26:35','facebook_enabled','y','','','','share-post','','','','','sharer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('33','2017-12-01 11:26:36','2017-12-01 11:26:35','twitter_enabled','y','','','','share-post','','','','','sharer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('34','2017-12-01 11:26:59','2017-12-01 11:26:37','googleplus_enabled','y','','','','share-post','','','','','sharer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('35','2017-12-01 11:26:46','2017-12-01 11:26:38','pinterest_enabled','','','','','share-post','','','','','sharer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('36','2017-12-01 11:51:35','2017-12-01 11:51:35','height','20','','','','module-layouts-3','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('37','2017-12-01 11:51:55','2017-12-01 11:51:51','height','20','','','','module-layouts-3--4','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('38','2017-12-01 11:52:44','2017-12-01 11:52:44','facebook_enabled','y','','','','module-layouts-4-social-links','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('39','2017-12-01 11:52:46','2017-12-01 11:52:44','twitter_enabled','y','','','','module-layouts-4-social-links','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('40','2017-12-01 11:52:47','2017-12-01 11:52:47','googleplus_enabled','y','','','','module-layouts-4-social-links','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('41','2017-12-01 11:52:48','2017-12-01 11:52:48','pinterest_enabled','y','','','','module-layouts-4-social-links','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('42','2017-12-01 11:53:07','2017-12-01 11:53:07','facebook_enabled','y','','','','socials','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('43','2017-12-01 11:53:08','2017-12-01 11:53:08','twitter_enabled','y','','','','socials','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('44','2017-12-01 11:53:08','2017-12-01 11:53:08','googleplus_enabled','y','','','','socials','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('45','2017-12-01 11:53:20','2017-12-01 11:53:20','height','30','','','','module-layouts-1--1','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('46','2017-12-01 11:53:37','2017-12-01 11:53:37','height','30','','','','module-layouts-1--5','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('47','2017-12-01 11:53:52','2017-12-01 11:53:52','height','30','','','','module-layouts-1--8','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('48','2017-12-01 11:57:01','2017-12-01 11:57:01','shopping-cart','true','','','','mw-template-dream','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('49','2017-12-01 11:57:02','2017-12-01 11:57:02','search-field','true','','','','mw-template-dream','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('50','2017-12-01 11:59:26','2017-12-01 11:59:26','logotype','text','','','','footer-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('51','2017-12-01 11:59:28','2017-12-01 11:59:28','text','Dream','','','','footer-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('52','2017-12-01 11:59:35','2017-12-01 11:59:35','font_size','39','','','','footer-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('53','2017-12-01 12:00:16','2017-12-01 12:00:16','pinterest_enabled','y','','','','socials','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('54','2017-12-01 12:00:20','2017-12-01 12:00:20','youtube_enabled','y','','','','socials','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('55','2017-12-01 13:16:21','2017-12-01 13:16:21','facebook_enabled','y','','','','product-sharer','','','','','sharer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('56','2017-12-01 13:27:04','2017-12-01 13:16:26','twitter_enabled','y','','','','product-sharer','','','','','sharer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('57','2017-12-01 13:27:04','2017-12-01 13:16:27','googleplus_enabled','y','','','','product-sharer','','','','','sharer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('58','2017-12-13 14:52:21','2017-12-13 14:52:13','is_parallax','no','','','','module-layouts-12','','','','','layouts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('59','2017-12-14 14:57:50','2017-12-14 14:57:50','data-max-depth','1','','','','module-categories-11','','','','','categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('60','2017-12-14 14:57:56','2017-12-14 14:57:56','data-content-id','11','','','','module-categories-11','','','','','categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('61','2017-12-14 15:33:26','2017-12-14 15:33:26','data-content-id','11','','','','module-categories-32','','','','','categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('62','2017-12-14 15:33:31','2017-12-14 15:33:31','data-category-id','16','','','','module-categories-32','','','','','categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('63','2017-12-14 15:33:36','2017-12-14 15:33:36','data-max-depth','1','','','','module-categories-32','','','','','categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('64','2017-12-15 11:37:19','2017-12-15 11:37:17','data-template','default','','','','module-categories-8','','','','','categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('65','2017-12-18 10:11:49','2017-12-15 14:26:45','color-scheme','orounda-blue','','','','mw-template-dream','','','','','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */cart" ("id" integer not null primary key autoincrement, "title" text null, "is_active" varchar null, "rel_id" integer null, "rel_type" varchar null, "updated_at" datetime null, "created_at" datetime null, "price" float null, "currency" varchar null, "session_id" varchar null, "qty" integer null, "other_info" text null, "order_completed" integer null, "order_id" varchar null, "skip_promo_code" varchar null, "created_by" integer null, "custom_fields_data" text null, "custom_fields_json" text null, "item_image" varchar null, "link" varchar null, "description" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('1','Charles Leather Bag','','31','content','2017-12-14 11:10:05','2017-12-14 11:10:05','78.0','','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI','1','','0','','','1','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('4','Charles Leather Bag','','31','content','2017-12-15 12:03:14','2017-12-15 12:03:14','78.0','','VyL9Ls2wBvdWCTOPiyMxy6GX2q0BIEBJRdVyWT5y','1','','1','1','','2','eyJyYWRpbyI6IjMiLCJkcm9wZG93biI6IjQzIiwidGV4dCI6IlRoYW5rIHlvdSEgOikifQ==','{"radio":"3","dropdown":"43","text":"Thank you! :)"}','','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */cart_orders" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "order_id" varchar null, "amount" float null, "transaction_id" text null, "shipping_service" text null, "shipping" float null, "currency" varchar null, "currency_code" varchar null, "first_name" text null, "last_name" text null, "email" text null, "country" varchar null, "city" text null, "state" varchar null, "zip" varchar null, "address" text null, "address2" text null, "phone" text null, "created_by" integer null, "edited_by" integer null, "session_id" varchar null, "order_completed" integer null, "is_paid" integer null, "url" text null, "user_ip" varchar null, "items_count" integer null, "custom_fields_data" text null, "payment_gw" varchar null, "payment_verify_token" varchar null, "payment_amount" float null, "payment_currency" varchar null, "payment_status" varchar null, "payment_email" text null, "payment_receiver_email" text null, "payment_name" text null, "payment_country" text null, "payment_address" text null, "payment_city" text null, "payment_state" varchar null, "payment_zip" varchar null, "payment_phone" varchar null, "payer_id" text null, "payer_status" text null, "payment_type" text null, "order_status" varchar null, "payment_shipping" float null, "is_active" integer null, "rel_id" integer null, "rel_type" varchar null, "price" float null, "other_info" text null, "promo_code" text null, "skip_promo_code" integer null, "taxes_amount" float null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders (id,updated_at,created_at,order_id,amount,transaction_id,shipping_service,shipping,currency,currency_code,first_name,last_name,email,country,city,state,zip,address,address2,phone,created_by,edited_by,session_id,order_completed,is_paid,url,user_ip,items_count,custom_fields_data,payment_gw,payment_verify_token,payment_amount,payment_currency,payment_status,payment_email,payment_receiver_email,payment_name,payment_country,payment_address,payment_city,payment_state,payment_zip,payment_phone,payer_id,payer_status,payment_type,order_status,payment_shipping,is_active,rel_id,rel_type,price,other_info,promo_code,skip_promo_code,taxes_amount) VALUES('1','2017-12-15 12:25:50','2017-12-15 12:05:28','','78.0','','shop/shipping/gateways/country','0.0','USD','','Boris','Sokolov','boris@microweber.com','Bulgaria','Sofia','Sofia','1140','Sofia, Cherni Vruh 47','','1234567890','2','2','VyL9Ls2wBvdWCTOPiyMxy6GX2q0BIEBJRdVyWT5y','1','1','{SITE_URL}checkout?step=2','94.26.57.98','1','','shop/payments/gateways/paypal','b4d6898f856a2ceb82d07a969ffb798c','78.0','USD','','','','','','','','','','','','','','completed','0.0','','','','','second exit','','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */cart_taxes" ("id" integer not null primary key autoincrement, "tax_name" text null, "amount" float null, "tax_modifier" varchar null, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "tax_rules_json" text null, "position" integer null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */cart_shipping" ("id" integer not null primary key autoincrement, "updated_at" datetime null, "created_at" datetime null, "is_active" varchar null, "shipping_cost" float null, "shipping_cost_max" float null, "shipping_cost_above" float null, "shipping_country" text null, "position" integer null, "shipping_type" text null, "shipping_price_per_size" float null, "shipping_price_per_weight" float null, "shipping_price_per_item" float null, "shipping_price_custom" float null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_shipping (id,updated_at,created_at,is_active,shipping_cost,shipping_cost_max,shipping_cost_above,shipping_country,position,shipping_type,shipping_price_per_size,shipping_price_per_weight,shipping_price_per_item,shipping_price_custom) VALUES('1','','','1','0.0','','','Worldwide','','fixed','','','',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */tagging_tagged" ("id" integer not null primary key autoincrement, "taggable_id" integer not null, "taggable_type" varchar not null, "tag_name" varchar not null, "tag_slug" varchar not null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('4','20','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('5','20','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('6','20','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('12','19','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('13','24','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('14','24','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('15','24','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('16','24','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('17','25','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('18','25','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('19','25','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('20','25','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('21','26','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('22','26','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('23','26','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('24','26','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('25','27','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('26','27','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('27','27','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('28','27','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('29','28','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('30','28','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('31','28','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('32','28','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('33','29','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('34','29','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('35','29','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('36','29','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('37','30','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('38','30','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('39','30','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('40','30','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('41','31','Content','Guid','guid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('42','31','Content','Image','image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('43','31','Content','Post2','post2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug) VALUES('44','31','Content','Resize','resize'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */tagging_tags" ("id" integer not null primary key autoincrement, "slug" varchar not null, "name" varchar not null, "suggest" tinyint(1) not null default '0', "count" integer not null default '0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,suggest,count) VALUES('1','post2','Post2','0','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,suggest,count) VALUES('2','resize','Resize','0','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,suggest,count) VALUES('3','image','Image','0','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,suggest,count) VALUES('4','guid','Guid','0','9'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */tagging_tag_groups" ("id" integer not null primary key autoincrement, "slug" varchar not null, "name" varchar not null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */jobs" ("id" integer not null primary key autoincrement, "queue" varchar not null, "payload" text not null, "attempts" integer not null, "reserved" integer not null, "reserved_at" integer null, "available_at" integer not null, "created_at" integer not null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */failed_jobs" ("id" integer not null primary key autoincrement, "connection" text not null, "queue" text not null, "payload" text not null, "failed_at" datetime not null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */password_resets" ("email" varchar not null, "token" varchar not null, "created_at" datetime null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */content_revisions_history" ("id" integer not null primary key autoincrement, "rel_type" varchar null, "rel_id" varchar null, "field" text null, "value" text null, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "user_ip" varchar null, "checksum" varchar null, "session_id" varchar null, "url" text null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('1','content','19','content','
                            <div class="element">
                                <p align="justify" class="element element-over" id="element_1512127253081"><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&rsquo;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  <br></p>
                            </div>
                        ','2017-12-01 11:21:46','2017-12-01 11:21:46','1','1','94.26.57.98','b8831e815420942edb4c7a8d4fc223d3','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('2','content','5','dream_content','

        <module class="module module-layouts module-over" id="module-layouts-5" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-5"></module>
<section class="element" id="element_1512127958747"><div class="container">
                <div class="row">
                    <div class="col-md-8" style="height: auto;">
                        <module class="module module-posts" data-mw-title="Posts List" data-type="posts" template="skin-2" id="blog-posts-5" parent-module="posts" parent-module-id="blog-posts-5"></module>
</div>
                    <div class="col-md-3 col-md-offset-1 hidden-sm hidden-xs" style="height: auto;">
                        <div class="edit" field="dream_blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>
                    </div>
                </div>
            </div>
        </section>
','2017-12-01 11:33:42','2017-12-01 11:33:42','1','1','94.26.57.98','8398a478c149a11009efe88871a13f7f','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('3','content','20','content','
                            <div class="element">
                                <p align="justify" class="element element-over" id="element_1512128086907">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it
                                    anywhere on
                                    the
                                    site. Get creative, Make Web.</p>
                            </div>
                        ','2017-12-01 11:35:34','2017-12-01 11:35:34','1','1','94.26.57.98','75b130e7fd61d8f4ba493583ae58ece2','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('4','content','6','dream_content','
        <module class="module module-layouts module-over" id="module-layouts-6" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6"></module>
<module class="module module-posts" data-mw-title="Posts List" data-type="posts" template="skin-3" id="blog-2-posts-6" parent-module="posts" parent-module-id="blog-2-posts-6"></module>
','2017-12-01 11:41:42','2017-12-01 11:41:42','1','1','94.26.57.98','d2c94a592bff741a7dd7ae78d833fcb1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('5','content','5','dream_content','

        <module class="module module-layouts module-over" id="module-layouts-5" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-5"></module>
<section class=" element"><div class="container">
                <div class="row">
                    <div class="col-md-8" style="height: auto;">
                        <module class=" module module-posts " data-mw-title="Posts List" data-type="posts" template="skin-2" id="blog-posts-5" parent-module="posts" parent-module-id="blog-posts-5"></module>
</div>
                    <div class="col-md-3 col-md-offset-1 hidden-sm hidden-xs" style="height: auto;">
                        <div class="edit" field="dream_blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>
                    </div>
                </div>
            </div>
        </section>
','2017-12-01 11:42:02','2017-12-01 11:42:02','1','1','94.26.57.98','6c7fe6ba7e85d33f3e0a907b5f4ff6f1','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('6','content','7','dream_content','
        <module class="module module-layouts module-over" id="module-layouts-7" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7"></module>
<module class="module module-posts" data-mw-title="Posts List" data-type="posts" template="skin-4" id="blog-3-posts-7" parent-module="posts" parent-module-id="blog-3-posts-7"></module>
','2017-12-01 11:43:16','2017-12-01 11:43:16','1','1','94.26.57.98','304a29d3f35a1df41a7e1f3c4bbc13f4','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('7','content','8','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-8" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-8"></module>
<section class="masonry-contained element" id="element_1512128656367"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class=" module module-categories " id="module-categories-8" data-mw-title="Categories" content-id="8" data-type="categories" parent-module="categories" parent-module-id="module-categories-8"></module>
<module class=" module module-shop-products " id="module-shop-products-8" data-mw-title="Products" limit="18" description-length="70" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-8"></module>
</div>
            </div>
        </div>
    </section>
','2017-12-01 11:44:28','2017-12-01 11:44:28','1','1','94.26.57.98','14bb3d672e28dcc75d861b69b7efb65d','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('8','content','9','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-9" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-9"></module>
<section class="masonry-contained element" id="element_1512128674249"><div class="container">
            <div class="row">
                <div class="masonry-shop element">
                    <module class=" module module-categories " id="module-categories-9" data-mw-title="Categories" content-id="9" data-type="categories" parent-module="categories" parent-module-id="module-categories-9"></module>
<module class=" module module-shop-products " id="module-shop-products-9" data-mw-title="Products" limit="18" description-length="70" template="skin-1" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-9"></module>
</div>
            </div>
        </div>
    </section>
','2017-12-01 11:44:42','2017-12-01 11:44:42','1','1','94.26.57.98','add3df01c49c3f4a5be557c664e57fd2','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('9','content','10','dream_content','
    <module class="module module-layouts" id="module-layouts-10" data-mw-title="Layouts" template="skin-68" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-10"></module>
<section class="masonry-contained element element-over" id="element_1512128689313"><div class="container">
            <div class="row">
                <div class="col-md-9" style="height: auto;">
                    <div class="masonry-shop element">
                        <module class=" module module-shop-products " id="module-shop-products-10" data-mw-title="Products" limit="18" description-length="70" template="skin-2" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-10"></module>
</div>
                </div>

                <div class="col-md-3 hidden-sm hidden-xs" style="height: auto;">
                    <div class="edit" field="blog_sidebar" rel="inherit">
<inner-edit-tag>mw_saved_inner_edit_from_parent_edit_field</inner-edit-tag><div></div>
</div>


                </div>
            </div>
        </div>
    </section>
','2017-12-01 11:44:59','2017-12-01 11:44:59','1','1','94.26.57.98','2c2fa93ea23fd07d31f016dd2342a8b5','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('10','content','11','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-11" data-mw-title="Layouts" template="skin-42" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-11"></module>
<section class="wide-grid masonry masonry-shop element"><module class="module module-categories" id="module-categories-11" data-mw-title="Categories" content_id="11" data-type="categories" parent-module="categories" parent-module-id="module-categories-11"></module>
<module class="module module-shop-products" id="module-shop-products-11" data-mw-title="Products" limit="18" description-length="70" template="skin-3" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-11"></module>
<div class="clearfix element"><p class="element"></p></div>
    </section>
','2017-12-01 11:45:17','2017-12-01 11:45:17','1','1','94.26.57.98','2ded555c703824416d0f0850abc1c421','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('11','content','12','dream_content','
        <module class="height-70 module module-layouts module-over" id="module-layouts-12" data-mw-title="Layouts" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12"></module>
<module class="section--overlap module module-layouts " id="module-layouts-12--1" data-mw-title="Layouts" template="skin-55" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--1"></module>
<module class=" module module-layouts " id="module-layouts-12--2" data-mw-title="Layouts" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-12--2"></module>
','2017-12-01 11:45:33','2017-12-01 11:45:33','1','1','94.26.57.98','b096404dd29feed6acb8a3cd342b600f','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('12','content','13','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-13" data-mw-title="Layouts" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13"></module>
<module class="module module-layouts" id="module-layouts-13--1" data-mw-title="Layouts" template="skin-53" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--1"></module>
<module class="module module-layouts" id="module-layouts-13--2" data-mw-title="Layouts" template="skin-54" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--2"></module>
<module class=" module module-layouts " id="module-layouts-13--3" data-mw-title="Layouts" template="skin-53" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-13--3"></module>
','2017-12-01 11:46:01','2017-12-01 11:46:01','1','1','94.26.57.98','86b0e78e707a8db1aebb8e59315cbadf','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('13','content','14','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-14" data-mw-title="Layouts" template="skin-40" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14"></module>
<module class=" module module-layouts " id="module-layouts-14--1" data-mw-title="Layouts" template="skin-17" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--1"></module>
<module class=" module module-layouts " id="module-layouts-14--2" data-mw-title="Layouts" template="skin-18" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--2"></module>
<module class=" module module-layouts " id="module-layouts-14--3" data-mw-title="Layouts" template="skin-19" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--3"></module>
<module class=" module module-layouts " id="module-layouts-14--4" data-mw-title="Layouts" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--4"></module>
','2017-12-01 11:46:24','2017-12-01 11:46:24','1','1','94.26.57.98','488794339cad7faeac496af2288849f8','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('14','content','15','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-15" data-mw-title="Layouts" template="skin-57" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-15"></module>
<module class=" module module-layouts " id="module-layouts-15--1" data-mw-title="Layouts" template="skin-56" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-15--1"></module>
','2017-12-01 11:46:45','2017-12-01 11:46:45','1','1','94.26.57.98','59ec781700cee7506673c63b04046dda','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('15','content','16','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-16" data-mw-title="Layouts" template="skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-16"></module>
<module class=" module module-layouts " id="module-layouts-16--1" data-mw-title="Layouts" template="skin-52" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-16--1"></module>
','2017-12-01 11:48:40','2017-12-01 11:48:40','1','1','94.26.57.98','9314ae2dec87dac968e5c352d1b4773b','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('16','content','4','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-4" data-mw-title="Layouts" template="skin-23" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-4"></module>
','2017-12-01 11:56:29','2017-12-01 11:56:29','1','1','94.26.57.98','ed7829c658346e1758ec9b4302294524','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('17','content','29','content_body','
                            <p class="element element-over" id="element_1512133040928">
                                A sturdy, handwoven fabric makes this American Apparel indigo-T a dependable addition to your casual wardrobe. This is a no bullshit plain ol’ t-shirt.
                            </p>
                        ','2017-12-01 12:57:43','2017-12-01 12:57:43','1','1','94.26.57.98','d0446e362fbf0ab83586501dad161acf','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('18','content','12','dream_content','','2017-12-13 14:58:16','2017-12-13 14:58:16','1','1','94.26.57.98','d41d8cd98f00b204e9800998ecf8427e','2fsvpbTraoW3B85VpvOciSlDc32t2j9ELwkgPStS',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('19','content','1','dream_content','
    <module class="module module-layouts" id="module-layouts-1" data-mw-title="Layouts" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts" id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module module-layouts module-over" id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class="module module-layouts" id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class="module module-layouts" id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class="module module-layouts" id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class="module module-layouts" id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class="module module-layouts" id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class="module module-layouts" id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
','2017-12-14 11:09:23','2017-12-14 11:09:23','1','1','94.26.57.98','d963f11566f35d70e8a8146420555b55','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('20','content','14','dream_content','
    
    <module class="module  module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-14" template="skin-40" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--1" template="skin-17" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--1"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--2" template="skin-18" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--2"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--3" template="skin-19" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--3"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--4" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--4"></module>

','2017-12-14 11:40:22','2017-12-14 11:40:22','1','1','94.26.57.98','003d32e11778b1711be996ca4f4920ff','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('21','content','14','dream_content','
    
    <module class="module  module module-layouts" data-mw-title="Layouts" id="module-layouts-14" template="skin-40" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--1" template="skin-17" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--1"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--2" template="skin-18" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--2"></module>
<module class="module module-layouts module-over" data-mw-title="Layouts" id="module-layouts-14--3" template="skin-19" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--3"></module>
<module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-14--4" template="skin-20" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-14--4"></module>

','2017-12-14 11:41:14','2017-12-14 11:41:14','1','1','94.26.57.98','6eb56a21c381ded9d153b3fa79acf3f6','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('22','content','17','dream_content','
            <module class="module module-layouts module-over" id="module-layouts-17" data-mw-title="Layouts" template="skin-41" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17"></module>
<module class=" module module-layouts " id="module-layouts-17--1" data-mw-title="Layouts" template="skin-50" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--1"></module>
<module class=" module module-layouts " id="module-layouts-17--2" data-mw-title="Layouts" template="skin-47" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-17--2"></module>
','2017-12-14 11:47:11','2017-12-14 11:47:11','1','1','94.26.57.98','d80ce768f01328363957c7f7cc3ef3f8','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('23','content','32','dream_content','
    <module class="module module-layouts module-over" id="module-layouts-32" data-mw-title="Layouts" template="skin-42" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-32"></module>
<section class="wide-grid masonry masonry-shop element"><module class="module module-categories" id="module-categories-32" data-mw-title="Categories" content_id="32" data-type="categories" parent-module="categories" parent-module-id="module-categories-32"></module>
<module class="module module-shop-products" id="module-shop-products-32" data-mw-title="Products" limit="18" description-length="70" template="skin-3" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-32"></module>
<div class="clearfix element"><p class="element"></p></div>
    </section>
','2017-12-14 15:24:43','2017-12-14 15:24:43','1','1','94.26.57.98','014b6319e88882651f8c8f5b8ae22aca','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('24','content','1','dream_content','
    <module class="module module-layouts" id="module-layouts-1" data-mw-title="Layouts" template="skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
<module class="module module-layouts" id="module-layouts-1--1" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
<module class=" module module-layouts " id="module-layouts-1--2" data-mw-title="Layouts" template="skin-58" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
<module class="module module-layouts" id="module-layouts-1--4" data-mw-title="Layouts" template="skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
<module class=" module module-layouts " id="module-layouts-1--5" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
<module class=" module module-layouts " id="module-layouts-1--6" data-mw-title="Layouts" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
<module class=" module module-layouts " id="module-layouts-1--7" data-mw-title="Layouts" template="skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
<module class=" module module-layouts " id="module-layouts-1--8" data-mw-title="Layouts" template="skin-32" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
<module class=" module module-layouts " id="module-layouts-1--9" data-mw-title="Layouts" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
<module class=" module module-layouts " id="module-layouts-1--10" data-mw-title="Layouts" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
<module class=" module module-layouts " id="module-layouts-1--11" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
','2017-12-14 16:38:21','2017-12-14 16:38:21','1','1','94.26.57.98','eb1cee31d1ae2041d2d7a4dd8c3db8e4','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_revisions_history (id,rel_type,rel_id,field,value,updated_at,created_at,created_by,edited_by,user_ip,checksum,session_id,url) VALUES('25','content','11','dream_content','','2017-12-15 11:57:02','2017-12-15 11:57:02','1','1','94.26.57.98','d41d8cd98f00b204e9800998ecf8427e','Bo45kHkVP4s3fGaeD6FtVrG4VyINt79GVvjD4GlA',''); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */calendar" ("id" integer not null primary key autoincrement, "content_id" integer null, "title" varchar null, "startdate" varchar null, "enddate" varchar null, "allDay" varchar null, "description" text null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */newsletter_subscribers" ("id" integer not null primary key autoincrement, "name" text null, "email" text null, "created_at" datetime null, "confirmation_code" text null, "is_subscribed" integer null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */newsletter_campaigns" ("id" integer not null primary key autoincrement, "name" text null, "subject" text null, "from_name" text null, "from_email" text null, "created_at" datetime null, "list_id" integer null, "is_done" integer null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */newsletter_campaigns_send_log" ("id" integer not null primary key autoincrement, "campaign_id" integer null, "subscriber_id" integer null, "created_at" datetime null, "is_done" integer null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */testimonials" ("id" integer not null primary key autoincrement, "name" text null, "content" text null, "read_more_url" text null, "created_on" datetime null, "project_name" text null, "client_company" text null, "client_role" text null, "client_picture" text null, "client_website" text null, "position" integer null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */rating" ("id" integer not null primary key autoincrement, "rel_type" varchar null, "rel_id" varchar null, "rating" integer null, "comment" text null, "updated_at" datetime null, "created_at" datetime null, "created_by" integer null, "edited_by" integer null, "session_id" varchar null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */stats_users_online" ("id" integer not null primary key autoincrement, "created_by" integer null, "view_count" integer null default '1', "user_ip" varchar null, "visit_date" date null, "visit_time" time null, "last_page" varchar null, "session_id" varchar null); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('1','','27','94.26.57.98','2017-11-28','16:11:18','{SITE_URL}home','FCzuSjnAJAzjx7TwxVkIP3DH6rmxoR344mGlRx4p'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('2','','3','94.26.57.98','2017-11-29','08:43:57','{SITE_URL}home','UDo8ZdzaJSW2s3lTj6r58QDQY9FMmyquR6OvV7z8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('3','','3','94.26.57.98','2017-11-30','12:39:43','{SITE_URL}','lzgJjno0HzRvt0xbAgkaWj1MFONi250QXEg7nRXf'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('4','','134','94.26.57.98','2017-12-01','14:43:41','{SITE_URL}home','fL65cm4rQtRtqCBMQ2vlgX8gi0ACiCaa7RL1MuEQ'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('5','','1','23.101.61.176','2017-12-01','13:13:57','{SITE_URL}shop','ZO0eDt61V6J52M6eVPdeRi7p8U6WwjOu1GWcvJdm'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('6','','2','104.45.18.178','2017-12-01','16:26:19','{SITE_URL}shop-2','dSCTB9HWhqf6KToTy5OH9T1DVko0W61rzt3U5ul8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('7','','5','90.154.249.209','2017-12-01','16:00:28','{SITE_URL}shop','sSPr729KcjUYRrExyFoq4XQGZOu0kzyaqEhuEnWW'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('8','','1','54.165.90.203','2017-12-02','22:44:35','{SITE_URL}home-4','dVzV7Hv19Bcsv1Kv2XOqKf659vDWThsYo045LZ4h'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('9','','5','54.165.90.203','2017-12-04','13:21:36','{SITE_URL}blog-3','rSODTt1b5t2gJKf5qaj8UX2I7PxfMjNFqwz9uw4H'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('10','','1','23.101.61.176','2017-12-04','11:16:55','{SITE_URL}shop','9CtaBokCiJ3bWjBlhNt2VuzgJ942IjlAs566Gg4C'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('11','','4','94.26.57.98','2017-12-04','12:12:21','{SITE_URL}shop-2','HjKWhkorGjiMniTNrI2TT8BIDdPd5D9mSVml7DRn'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('12','','23','94.26.57.98','2017-12-05','15:12:46','{SITE_URL}blog','pAcfe7b4kFDemObOiQNFjn2jSrAniN0Uy8sG9bUV'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('13','','1','104.209.188.207','2017-12-05','08:45:19','{SITE_URL}contacts-2','vnH0UoR6KRIv7KUzXBuErl3MefClXTn1l5Ih8bTR'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('14','','1','23.101.61.176','2017-12-05','08:45:21','{SITE_URL}contacts-2','7ncCnRpcjxEUs3xEsPDxyT2DnfFa1wzukJJqaOAh'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('15','','8','178.169.182.99','2017-12-05','22:56:36','{SITE_URL}contacts-2','OZ1XP8dlENEuxwbiKic0C9vtdCIheySRve2ArYhB'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('16','','2','104.45.18.178','2017-12-05','20:43:18','{SITE_URL}shop-2','DlEaN58Gv2zGSCSKvLTht9VFkMRk5buuwX2WJ85m'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('17','','1','104.45.18.178','2017-12-06','19:50:45','{SITE_URL}contacts-2','ahSdhT6oxn8sAjpr98jYI58jtphoAmmCJLa090gg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('18','','2','138.246.253.19','2017-12-07','16:50:45','{SITE_URL}','XLe2CPkHvLYLmVOmWaeo7QiFxrZhJlg6whYoG2ai'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('19','','1','104.209.188.207','2017-12-07','10:17:07','{SITE_URL}contacts-2','39KhVQeAqLS2E5YgddSmlXM71oYJE2xhselkXDB7'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('20','','1','54.165.90.203','2017-12-07','21:52:51','{SITE_URL}','Ih2Sn2r0OkVf1q3vesPWCdICDGVbNhnoSaX4kp4p'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('21','','3','54.165.90.203','2017-12-08','06:54:54','{SITE_URL}blog-2','XveUlKiV9YYQj7FuOFeotLRrkZslyxAyONhXR8NU'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('22','','1','159.203.141.98','2017-12-09','16:20:22','{SITE_URL}','HpiqYAYRIwlOa2IprF6t6quZwF9rItmbpI2LnmUC'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('23','','1','45.55.220.177','2017-12-09','16:27:13','{SITE_URL}','IhhUgeANMD94aHWeMq3vbGvBQRw815rSwLlmD1ZD'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('24','','1','138.197.107.184','2017-12-10','02:42:42','{SITE_URL}','bJOXblcyDTM51zWUwlcWpNLcPPxZwKVIb2yS4726'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('25','','1','138.197.124.163','2017-12-10','02:43:03','{SITE_URL}','ZOq7RoQrpMV9Cnvwdv5ugpvigmHZbzOpETpKFw0G'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('26','','1','94.26.57.98','2017-12-12','16:17:54','{SITE_URL}','CEDdU7ZfaV7kAh2XIMCGtUfr0s8tkGvmeZYB7AB9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('27','','1','94.26.57.98','2017-12-12','16:17:54','{SITE_URL}','80P6lRlaUPBT9l3ix0kjBpSxyIYWzxTVyjBv6jVO'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('28','','9','94.26.57.98','2017-12-13','14:57:48','{SITE_URL}services','2fsvpbTraoW3B85VpvOciSlDc32t2j9ELwkgPStS'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('29','','64','94.26.57.98','2017-12-14','17:26:34','{SITE_URL}','vKDFrqSA3hDA9jj4GGSlIl48ufcnw0E1mEHmijiI'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('30','','3','23.101.61.176','2017-12-14','12:54:45','{SITE_URL}contacts','YdDT0A40fgXaMUnddkO6OgEzV1ZBAUcqciHrPZH5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('31','','2','104.45.18.178','2017-12-14','18:42:12','{SITE_URL}contacts','C83nxFmSq4uM2gVDGNjG26UwQMl9pOLfkDZk52Ej'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('32','','23','178.169.182.99','2017-12-14','13:43:09','{SITE_URL}charles-leather-bag','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('33','','1','212.5.158.193','2017-12-14','13:08:07','{SITE_URL}charles-leather-bag','z7VPuUsY1AcSs75r0GSDGsUxNpuAevHBFtz7fRIc'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('34','','57','94.26.57.98','2017-12-15','12:36:05','{SITE_URL}home','Bo45kHkVP4s3fGaeD6FtVrG4VyINt79GVvjD4GlA'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('35','','4','23.101.61.176','2017-12-15','19:40:00','{SITE_URL}dave-wool-beanie-1','Y1zCdtA47LMh4fQIr5Kd60YLuPVI8gOwQONz8AcX'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('36','','1','104.45.18.178','2017-12-15','11:51:45','{SITE_URL}shop-4','lb8P9738fyegoO2Usm5L2tvXaOe7X0rSY6cATj2E'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('37','1','1','178.169.182.99','2017-12-15','16:12:27','{SITE_URL}shop','nxQABqWZPjGGYQw4zMPEHMpvfOPOV1pyy8FWanYf'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('38','','2','54.165.90.203','2017-12-16','09:37:01','{SITE_URL}about','uqOgPfnkuBB1tIWPv5r3baEi8Ncd0dNl4yqL62qg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('39','','1','104.45.18.178','2017-12-17','19:16:05','{SITE_URL}dave-wool-beanie-1','JpBJnmUvU66PGCkUYMUSk66VROLBRqUep6CqtuS6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('40','','4','54.165.90.203','2017-12-18','08:37:09','{SITE_URL}shop-3','cffb5swjTeAh2i8ee4ofJ6wqY3qGwfHlEu7oNdWT'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('41','2','7','94.26.57.98','2017-12-18','10:13:23','{SITE_URL}','7LQLii4C4BDyyeCaVo3ogBhlkLfn3F7rcZKgvcJK'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('42','','1','104.45.18.178','2017-12-18','10:12:47','{SITE_URL}','L3iBWjYW1eTzTGT0FbKZtKboEWqEBfxnK4IERpNZ'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('43','','1','40.78.146.128','2017-12-18','10:14:08','{SITE_URL}','lgQlbIRQR9HxooJOLpSM3plrJ1QYhUuQL5s6dm1h'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_users_online (id,created_by,view_count,user_ip,visit_date,visit_time,last_page,session_id) VALUES('44','','1','178.169.182.99','2017-12-18','10:14:21','{SITE_URL}','K76IkS4FCUzEOaIrnqdxr7TyqFqkf6CgOW655RwZ'); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */stats_pageviews" ("id" integer not null primary key autoincrement, "view_count" integer null default '1', "page_id" integer null, "main_page_id" integer null, "parent_page_id" integer null, "category_id" integer null, "updated_at" datetime null); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS "/* MW_PREFIX_PLACEHOLDER */backers_list" ("id" integer not null primary key autoincrement, "backer_name" text null, "backer_email" text null, "backer_amount" integer null, "backer_visible" integer null default '1', "created_at" datetime null); /* MW_QUERY_SEPERATOR */





