<?php
echo 'This is a php file.';
?>
