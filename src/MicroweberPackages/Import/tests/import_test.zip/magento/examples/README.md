# Examples & Use Cases

You can find some additional examples in this section which focus on specific
scenarios to give you an idea of how to provide various data to Klevu.

> :warning: **Please note that these examples contain partial data**, focusing only 
on the particular scenario being highlighted. For example some of them do not include required
fields such as &lt;id/&gt;, so please cross-reference them with the XSD Schema.
