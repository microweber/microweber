/* Microweber database backup exported on: Thursday 23rd of May 2013 09:50:06 AM */ 
/* MW_TABLE_PREFIX: mw_25591 */ 

 


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("1","My T-shirt Product","y","5","content","2013-05-23 09:23:16","2013-05-23 09:23:16","35","","j7i9l0qe881ghsjhffkjcbv226","1","","y","1","n","0","W10="); /* MW_QUERY_SEPERATOR */


 
REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders VALUES("1","2013-05-23 09:23:46","2013-05-23 09:23:46","Bulgaria","","35","","shop/shipping/gateways/country","15","USD","","Boris","Sokolov","sokolov.boris@gmail.com","Sofia","","1172","sv. pimen zografski 14","","4951424","0","0","j7i9l0qe881ghsjhffkjcbv226","y","n","{SITE_URL}checkout","::1","1","shop/payments/gateways/paypal","9d259a104c8b990ceb726356209c4bd8","35","USD","","","","","","","","","","","","","","pending","15","y","","","","","","n"); /* MW_QUERY_SEPERATOR */
 

 

REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_shipping VALUES("1","2013-05-23 09:11:03","2013-05-23 09:10:38","y","10","5","300","Worldwide","999","","","","",""); /* MW_QUERY_SEPERATOR */

 
 

REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("22","2013-05-23 08:56:11","2013-05-23 08:56:11","1","1","category","Blog","0","","","","content","2","","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("23","2013-05-23 08:56:35","2013-05-23 08:56:35","1","1","category","My Shop","0","","","","content","3","","n","n","n","","",""); /* MW_QUERY_SEPERATOR */

 

REPLACE INTO /* MW_PREFIX_PLACEHOLDER */comments VALUES("1","content","4","2013-05-23 09:22:43","2013-05-23 09:22:43","0","0","Boris","Very nice first post. I love it!\nThis is my first comment on this website. ","sokolov.boris@gmail.com","www.microweber.com","y","{SITE_URL}my-first-post","","y","n","j7i9l0qe881ghsjhffkjcbv226"); /* MW_QUERY_SEPERATOR */

 

REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("1","2013-05-23 09:21:00","2013-05-23 08:54:23","","1","1","page","home","","Home","0","","","","1","","y","y","n","n","n","","n","static","","","","","","default","mg5b3keckgqp6jusnb4f64f4t6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("2","2013-05-23 08:56:11","2013-05-23 08:56:11","","1","1","page","blog","","Blog","0","","","","0","","y","n","n","n","n","","n","dynamic","","","layouts/blog.php","","","default","mg5b3keckgqp6jusnb4f64f4t6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("3","2013-05-23 08:56:35","2013-05-23 08:56:35","","1","1","page","my-shop","","My Shop","0","","","","0","","y","n","n","y","n","","n","dynamic","","","layouts/shop.php","","","default","mg5b3keckgqp6jusnb4f64f4t6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("4","2013-05-23 09:19:08","2013-05-23 08:57:32","","1","1","post","my-first-post","","My first post","2","","","","2","","y","n","n","n","n","","n","post","","","","","","","mg5b3keckgqp6jusnb4f64f4t6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("5","2013-05-23 09:20:18","2013-05-23 09:05:39","","1","1","post","my-t-shirt-product","","My T-shirt Product","3","","","","3","","y","n","n","n","n","","n","product","","","","","","","mg5b3keckgqp6jusnb4f64f4t6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("6","2013-05-23 09:05:46","2013-05-23 09:05:46","","1","1","post","my-t-shirt-product-20130523090545","","My T-shirt Product","3","","","","4","","y","n","n","n","y","","n","product","","","","","","","mg5b3keckgqp6jusnb4f64f4t6"); /* MW_QUERY_SEPERATOR */

 

REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("1","content","5","mg5b3keckgqp6jusnb4f64f4t6","0","2013-05-23 09:19:31","2013-05-23 08:59:17","1","1","Price","price","35","price","","35","","","","","y","n",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("2","content","5","mg5b3keckgqp6jusnb4f64f4t6","0","2013-05-23 09:00:13","2013-05-23 08:59:31","1","1","Size","size","Array","radio","YTo1OntpOjA7czoxOiJTIjtpOjE7czoxOiJNIjtpOjI7czoxOiJMIjtpOjM7czoyOiJYTCI7aTo0O3M6MzoiWFhMIjt9","S, M, L, XL, XXL","","","","","y","n",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("15","content","5","mg5b3keckgqp6jusnb4f64f4t6","0","2013-05-23 09:05:45","2013-05-23 09:00:32","1","1","Color","color","Array","dropdown","YTozOntpOjA7czo0OiJCbHVlIjtpOjE7czo2OiJPcmFuZ2UiO2k6MjtzOjU6IkJsYWNrIjt9","Blue, Orange, Black","","","","","y","n",""); /* MW_QUERY_SEPERATOR */



 

REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("1","2013-05-23 08:55:11","2013-05-23 08:55:12","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","1","picture","1","","","","{SITE_URL}userfiles/media/content/He_can.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("2","2013-05-23 08:55:13","2013-05-23 08:55:14","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","1","picture","2","","","","{SITE_URL}userfiles/media/content/Rafting.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("3","2013-05-23 08:55:15","2013-05-23 08:55:16","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","1","picture","0","","","","{SITE_URL}userfiles/media/content/You_can.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("4","2013-05-23 08:57:08","2013-05-23 08:57:09","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","4","picture","1","","","","{SITE_URL}userfiles/media/content/2.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("5","2013-05-23 08:57:11","2013-05-23 08:57:12","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","4","picture","2","","","","{SITE_URL}userfiles/media/content/3.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("6","2013-05-23 08:57:13","2013-05-23 08:57:14","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","4","picture","3","","","","{SITE_URL}userfiles/media/content/post1.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("7","2013-05-23 08:57:15","2013-05-23 08:57:16","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","4","picture","0","","","","{SITE_URL}userfiles/media/content/post2.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("8","2013-05-23 08:57:17","2013-05-23 08:57:18","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","4","picture","4","","","","{SITE_URL}userfiles/media/content/post3.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("9","2013-05-23 09:05:18","2013-05-23 09:05:19","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","5","picture","1","","","","{SITE_URL}userfiles/media/content/T_shirt_microweber.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("10","2013-05-23 09:05:20","2013-05-23 09:05:21","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","5","picture","2","","","","{SITE_URL}userfiles/media/content/T_shirt_microweber_make_web.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("11","2013-05-23 09:05:22","2013-05-23 09:05:23","1","1","mg5b3keckgqp6jusnb4f64f4t6","content","5","picture","0","","","","{SITE_URL}userfiles/media/content/T_shirt_SpideR.jpg"); /* MW_QUERY_SEPERATOR */




 

REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("1","header_menu","menu","","","","","2013-05-23 08:54:38","2013-05-23 08:54:38","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("2","footer_menu","menu","","","","","2013-05-23 08:54:39","2013-05-23 08:54:39","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("3","","menu_item","1","1","","0","2013-05-23 08:57:49","2013-05-23 08:57:50","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("4","","menu_item","1","2","","2","2013-05-23 08:57:54","2013-05-23 08:57:55","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("5","","menu_item","1","3","","1","2013-05-23 08:58:02","2013-05-23 08:58:03","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("6","","menu_item","2","1","","99999","2013-05-23 08:58:22","2013-05-23 08:58:23","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("7","","menu_item","2","2","","99999","2013-05-23 08:58:29","2013-05-23 08:58:30","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("8","","menu_item","2","3","","99999","2013-05-23 08:58:36","2013-05-23 08:58:37","y","",""); /* MW_QUERY_SEPERATOR */



 
 


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications VALUES("1","2013-05-23 09:22:43","2013-05-23 09:22:43","0","0","","You have new comment","New comment is posted on {SITE_URL}my-first-post","Very nice first post. I love it!\nThis is my first comment on this website. ","comments","content","4","1","n"); /* MW_QUERY_SEPERATOR */
 

REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("1","2013-05-23 08:53:49","2013-05-23 08:53:49","website_title","Microweber","","","1","website","Website name","This is very important for the search engines. Your website will be categorized by many criterias and the name is one of it.","text","","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("2","2013-05-23 08:53:49","2013-05-23 08:53:49","website_description","My website\'s description","","","2","website","Website description","Create Free Online Shop, Free Website and Free Blog with Microweber (MW)","textarea","","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("3","2013-05-23 08:53:49","2013-05-23 08:53:49","website_keywords","free website, free shop, free blog, make web, mw, microweber","","","3","website","Website keywords","Write keywords for your site.","textarea","","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("4","2013-05-23 08:53:49","2013-05-23 08:53:49","current_template","default","","","5","template","Website template","This is your current template. You can easy change it anytime.","website_template","","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("5","2013-05-23 08:53:49","2013-05-23 08:53:49","items_per_page","30","","","6","website","Items per page","Select how many items you want to have per page? example 10,25,50...","dropdown","YTo1OntpOjEwO3M6MjoiMTAiO2k6MzA7czoyOiIzMCI7aTo1MDtzOjI6IjUwIjtpOjEwMDtzOjM6IjEwMCI7aToyMDA7czozOiIyMDAiO30=","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("6","2013-05-23 08:53:49","2013-05-23 08:53:49","enable_user_registration","y","","","10","users","Enable user registration","You can enable or disable the registration for new users","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("7","2013-05-23 08:53:49","2013-05-23 08:53:49","currency","USD","","","1","payments","Currency","The website currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("8","2013-05-23 08:53:49","2013-05-23 08:53:49","payment_currency","USD","","","2","payments","Payment currency","Payment process in currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("9","2013-05-23 08:53:49","2013-05-23 08:53:49","payment_currency_rate","1.2","","","3","payments","Payment currency rate","Payment currency convert rate to site currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("10","2013-05-23 09:11:13","2013-05-23 09:11:13","shipping_gw_shop/shipping/gateways/country","y","","","","module-shop-shipping-checkout-1046873423","","","","","shop/shipping/admin","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("11","2013-05-23 09:11:14","2013-05-23 09:11:14","shipping_gw_shop/shipping/gateways/country","y","","","","shipping","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("12","2013-05-23 09:13:11","2013-05-23 09:13:11","payment_gw_shop/payments/gateways/paypal","y","","","","module-shop-payments-checkout853024203","","","","","shop/payments/admin","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("13","2013-05-23 09:13:12","2013-05-23 09:13:12","payment_gw_shop/payments/gateways/paypal","y","","","","payments","","","","","","0"); /* MW_QUERY_SEPERATOR */




REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("15","2013-05-23 09:13:21","2013-05-23 09:13:21","paypalexpress_username","sokolov.boris@gmail.com","","","","payments","","","","","","0"); /* MW_QUERY_SEPERATOR */



REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("17","2013-05-23 09:13:44","2013-05-23 09:13:44","order_email_content","&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br><div><font size=\"4\">Thank you for your order,&nbsp; <b><br>{first_name}&nbsp;</b><b>{last_name}</b></font></div><div><br></div><div>Your&nbsp;<b>Order ID</b>&nbsp;is: {id}</div><div><br></div><div>Order&nbsp;<b>amount</b>&nbsp;of: {amount} {currency} <br></div><div><br></div><div>You made this order with email:&nbsp;<b>{email} <br></b></div><div><br></div><div>Your&nbsp;<b>delivery&nbsp;address is</b>: <br>{country}<br>{city}<br>{state}<br>{zip}<br>{address}<br>{phone}<br></div><div><br></div><div><b><font size=\"5\">Thank You!</font></b></div>","","","","orders","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("18","2013-05-23 09:13:53","2013-05-23 09:13:53","order_email_subject","Thank you for your order!","","","","module-shop-payments-checkout853024203","","","","","shop/payments/admin","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("19","2013-05-23 09:13:54","2013-05-23 09:13:54","order_email_subject","Thank you for your order!","","","","orders","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("20","2013-05-23 09:13:59","2013-05-23 09:13:59","order_email_cc","sokolov.boris@gmail.com","","","","module-shop-payments-checkout853024203","","","","","shop/payments/admin","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("21","2013-05-23 09:14:00","2013-05-23 09:14:00","order_email_cc","sokolov.boris@gmail.com","","","","orders","","","","","","0"); /* MW_QUERY_SEPERATOR */



REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("27","2013-05-23 09:14:58","2013-05-23 09:14:58","test_email_to","test@microweber.com","","","","email","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("28","2013-05-23 09:15:33","2013-05-23 09:15:33","test_email_subject","Test Mail from default installation","","","","email","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("30","2013-05-23 09:17:26","2013-05-23 09:17:26","enable_comments","y","","","","comments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("31","2013-05-23 09:17:33","2013-05-23 09:17:33","avatar_enabled","y","","","","comments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("32","2013-05-23 09:17:34","2013-05-23 09:17:34","avatar_style","4","","","","comments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("33","2013-05-23 09:17:44","2013-05-23 09:17:44","avatartype_custom","{SITE_URL}userfiles/media/FB_SMALL.jpg","","","","comments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("34","2013-05-23 09:17:47","2013-05-23 09:17:47","paging","20","","","","comments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("35","2013-05-23 09:18:52","2013-05-23 09:18:52","data-use-from-post","y","","","","module-pictures--699875932","","","","","pictures/admin","0"); /* MW_QUERY_SEPERATOR */

 

 



